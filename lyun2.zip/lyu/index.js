// SC ampas kena kretek ujung" nya😹
// tele ku ada di @aboutsahril2nd semua
// Modded Baileys — Interactive Messages, AI Rich Responses, Albums & More (ourin-baileys)

/**
 * ============================================================================
 * LYU BOT AI - CORE ENGINE
 * Powered by ourin-baileys (Modded Baileys v7/v9 Architecture)
 * 
 * Features:
 * - Native interactiveMessage & Dugong flow buttons
 * - Multi-image / video albumMessage support
 * - Meta AI Rich Responses: sendTable, sendTableV2, sendCodeBlock, sendCodeBlockV2
 * - Inline Link citation embeds: sendLink, sendLinkV2
 * - Rich SubMessages: sendRichMessage
 * - Channel / Newsletter full utilities
 * - VoIP Voice Calls Engine built-in
 * - Decryption Retry & Auto Session Recreation
 * ============================================================================
 */

(async function startingBot() {
  // pairingCode startingBot
  const { initBaileys } = require("./lib/baileys");
  const baileysBridge = await initBaileys();

  require("./settings");
  global.bypassCheck = true;
  global.licenseTicket = global.internalValidationKey;

  const fs = require("fs");
  const pino = require("pino");
  const path = require("path");
  const axios = require("axios");
  const chalk = require("chalk");
  const readline = require("readline");
  const fileType = require("file-type");
  const { exec } = require("child_process");
  const { say } = require("cfonts");
  const { Boom } = require("@hapi/boom");
  const NodeCache = require("node-cache");
  const fetch = require("node-fetch");
  const {
    default: makeWASocket,
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    useMultiFileAuthState,
    Browsers,
    DisconnectReason,
    makeInMemoryStore,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion,
    proto,
    PHONENUMBER_MCC,
    getAggregateVotesInPollMessage,
    delay
  } = require("@whiskeysockets/baileys");

  const Database = require("./source/database");
  const dbInstance = new Database();
  const { MessagesUpset, SolvingHendler } = require("./source/message");
  const { initializerHandler } = require("./handler.js");
  const {
    isUrl,
    generateMessageTeg,
    getBuffer,
    getSizeMedia,
    fetchJson,
    sleep
  } = require("./library/function");

  const isPairingCode = global.pairing_code || process.argv.includes("--pairing-code");
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  const question = (query) => new Promise((resolve) => rl.question(query, resolve));

  // Error handling global
  process.on("uncaughtException", (err, origin) => {
    console.error(chalk.red("[ERROR FATAL TIDAK TERDUGA]"), err, origin);
  });

  process.on("unhandledRejection", (reason, promise) => {
    console.error(chalk.red("[PROMISE ERROR TIDAK TERDUGA]"), reason, promise);
  });

  // Inisialisasi Database Lokal Bot
  try {
    const data = await dbInstance.read();
    global.db = {
      users: {},
      groups: {},
      database: {},
      settings: {},
      ...(data || {})
    };
    if (Object.keys(data || {}).length === 0) {
      await dbInstance.write(global.db);
    }

    let isWriting = false;
    let pendingWrite = false;
    const saveDatabase = async () => {
      if (isWriting) {
        pendingWrite = true;
        return;
      }
      isWriting = true;
      try {
        await dbInstance.write(global.db);
      } catch (e) {
        console.error(chalk.red("Error simpan database:"), e.message);
      } finally {
        isWriting = false;
        if (pendingWrite) {
          pendingWrite = false;
          setTimeout(saveDatabase, 1000);
        }
      }
    };
    setInterval(saveDatabase, 30000);
  } catch (e) {
    console.error(chalk.red("Gagal inisialisasi database:"), e.message);
    process.exit(1);
  }

  let isReconnecting = false;
  let reconnectAttempts = 0;
  const INITIAL_RECONNECT_DELAY = 5000;

  async function startBot() {
    const store = makeInMemoryStore({
      logger: pino().child({ level: "silent", stream: "store" })
    });

    const { state, saveCreds } = await useMultiFileAuthState("session");
    let version = [2, 3000, 1035194821];
    try {
      const v = await fetchLatestBaileysVersion();
      if (v?.version) version = v.version;
    } catch {}

    const sock = makeWASocket({
      version,
      logger: pino({ level: "silent" }),
      auth: state,
      browser: Browsers.ubuntu("Chrome"),
      generateHighQualityLinkPreview: true,
      getMessage: async (key) => store.loadMessage(key.remoteJid, key.id, undefined)?.message,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 30000,
      maxIdleTimeMs: 60000,
      emitOwnEvents: true,
      defaultQueryTimeoutMs: 60000,
      retryRequestDelayMs: 2000,
      syncFullHistory: false,
      markOnlineOnConnect: true,
      fireInitQueries: true,
      enableRecentMessageCache: true,
      enableAutoSessionRecreation: true,
      shouldIgnoreJid: (jid) => jid?.includes("broadcast"),
      patchMessageBeforeSending: (message) => {
        const isInteractive = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
        if (isInteractive) {
          return {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadataVersion: 2,
                  deviceListMetadata: {}
                },
                ...message
              }
            }
          };
        }
        return message;
      }
    });

    // Pasang AI Rich & helper classes
    sock.AIRich = baileysBridge.AIRich;
    sock.ORich = baileysBridge.ORich;
    sock.Dugong = baileysBridge.Dugong;
    sock.VoipClient = baileysBridge.VoipClient;

    const groupMetaCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
    const msgDuplicateCache = new NodeCache({ stdTTL: 60, checkperiod: 30 });
    const miscCache = new NodeCache({ stdTTL: 120, checkperiod: 60 });

    sock.safeGroupMetadata = async (jid) => {
      if (groupMetaCache.has(jid)) return groupMetaCache.get(jid);
      try {
        const meta = await Promise.race([
          sock.groupMetadata(jid),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout meta")), 10000))
        ]);
        groupMetaCache.set(jid, meta);
        return meta;
      } catch (err) {
        console.error(chalk.red(` Error ambil metadata grup ${jid}:`), err.message);
        return { id: jid, subject: "Unknown", participants: [] };
      }
    };

    // Alur Input Nomor & Pairing Code
    if (isPairingCode && !sock.authState?.creds?.registered) {
      console.clear();
      console.log(chalk.cyanBright.bold("PENGATURAN NOMOR WHATSAPP BOT\n"));

      let phoneNumber = "";
      while (!phoneNumber) {
        phoneNumber = await question(
          chalk.cyanBright.bold("# Masukkan Nomor WhatsApp Bot\nContoh : 62812XXX\n") +
          chalk.white("➤ ")
        );
        phoneNumber = phoneNumber.replace(/[^0-9]/g, "");
        if (!phoneNumber) {
          console.log(chalk.red("Nomor tidak boleh kosong!\n"));
        }
      }

      const pairingCodeCustom = global.custompairing && global.custompairing.length === 8 ? global.custompairing : undefined;
      let pairingCode = await sock.requestPairingCode(phoneNumber, pairingCodeCustom);
      pairingCode = pairingCode.match(/.{1,4}/g)?.join(" - ") || pairingCode;
      console.log(chalk.green.bold("\nPairing code berhasil dibuat: ") + chalk.white.bold(pairingCode) + "\n");
    }

    // Handle Event Koneksi
    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;
      if (qr && !isPairingCode) {
        console.log(chalk.yellow("📱 Scan QR Code untuk melanjutkan..."));
        try {
          const qrcodeTerminal = require("qrcode-terminal");
          qrcodeTerminal.generate(qr, { small: true });
        } catch {
          try {
            const qrcode = require("qrcode");
            qrcode.toString(qr, { type: "terminal", small: true }, (err, text) => {
              if (!err) console.log(text);
            });
          } catch {}
        }
      }
      if (connection === "close") {
        const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
        if (statusCode === DisconnectReason.loggedOut) {
          console.log(chalk.red("PERANGKAT KELUAR, SILAKAN HAPUS FOLDER SESSION DAN PAIRING ULANG!"));
          process.exit(0);
        }
        if (!isReconnecting) {
          isReconnecting = true;
          reconnectAttempts++;
          const delayMs = Math.min(INITIAL_RECONNECT_DELAY * Math.pow(1.5, reconnectAttempts), 60000) + Math.random() * 2000;
          setTimeout(async () => {
            try {
              await startBot();
            } catch (e) {
              console.error("Reconnect gagal:", e.message);
            } finally {
              isReconnecting = false;
            }
          }, delayMs);
        }
      }
      if (connection === "open") {
        reconnectAttempts = 0;
        console.log(chalk.cyanBright.bold("BOT BERHASIL TERHUBUNG"));
      }
    });

    await store.bind(sock.ev);
    await SolvingHendler(sock, store);
    initializerHandler(sock, store);

    // Message Upsert Handler & Queue
    const queueMap = new Map();
    const activeQueues = new Set();

    const processQueue = async () => {
      for (const [key, tasks] of queueMap.entries()) {
        if (tasks.length === 0) {
          queueMap.delete(key);
          continue;
        }
        if (activeQueues.has(key)) continue;

        activeQueues.add(key);
        const currentTask = tasks.shift();
        try {
          await currentTask();
        } catch (e) {
          console.error(chalk.red("[Queue Task Error]:"), e);
        }
        activeQueues.delete(key);
      }
      setTimeout(processQueue, 50);
    };
    processQueue();

    const enqueueMessage = (key, task) => {
      if (!queueMap.has(key)) queueMap.set(key, []);
      queueMap.get(key).push(task);
    };

    sock.ev.on("messages.upsert", async (chatUpdate) => {
      const msg = chatUpdate.messages?.[0];
      const msgId = msg?.key?.id || Date.now().toString();
      if (msgDuplicateCache.has(msgId)) return;
      msgDuplicateCache.set(msgId, true);

      enqueueMessage(msg?.key?.remoteJid || "global", async () => {
        try {
          await MessagesUpset(sock, chatUpdate, store);
        } catch (err) {
          console.error(chalk.red("Error di messages.upsert:"), err);
        }
      });
    });

    // Antrian & Rate Limit SendMessage
    const sendPromises = {};
    const lastSendTimes = new Map();
    const rateLimits = new Map();
    const originalSendMessage = sock.sendMessage.bind(sock);

    sock.sendMessage = async (jid, content, options) => {
      if (!sendPromises[jid]) sendPromises[jid] = Promise.resolve();

      return (sendPromises[jid] = sendPromises[jid].then(async () => {
        const now = Date.now();
        const lastSend = lastSendTimes.get(jid) || 0;
        const rate = rateLimits.get(jid) || { count: 0, resetTime: now + 60000 };

        if (now > rate.resetTime) {
          rate.count = 0;
          rate.resetTime = now + 60000;
        }
        rate.count++;
        rateLimits.set(jid, rate);

        const throttleDelay = rate.count > 30 ? 2000 : rate.count > 15 ? 1000 : 800;
        if (now - lastSend < throttleDelay) {
          await delay(throttleDelay - (now - lastSend));
        }

        let retry = 0;
        while (retry < 3) {
          try {
            const res = await Promise.race([
              originalSendMessage(jid, content, options),
              new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout sendMessage")), 20000))
            ]);
            lastSendTimes.set(jid, Date.now());
            return res;
          } catch (err) {
            const msg = err.message || "";
            if (
              msg.includes("rate-overlimit") ||
              msg.includes("ConnectionClosed") ||
              msg.includes("close") ||
              msg.includes("ECONNRESET") ||
              msg.includes("ETIMEDOUT")
            ) {
              if (++retry < 3) {
                await delay(Math.min(Math.pow(2, retry) * 3000, 15000));
                continue;
              }
              return null;
            }
            if (msg.includes("not-authorized") || msg.includes("401") || msg.includes("403")) {
              return null;
            }
            break;
          }
        }
        return null;
      }).catch(() => null));
    };

    sock.safeSendText = async (jid, text, options = {}) => {
      return sock.sendMessage(jid, { text: text.toString().substring(0, 4096) }, options);
    };

    sock.safeSendImage = async (jid, image, caption = "", options = {}) => {
      if (!image) return null;
      try {
        return sock.sendMessage(jid, { image, caption: caption.substring(0, 4096) }, options);
      } catch (e) {
        return null;
      }
    };

    // Cache Flusher tiap 5 Menit
    setInterval(() => {
      const now = Date.now();
      for (const [jid, time] of lastSendTimes.entries()) {
        if (now - time > 300000) lastSendTimes.delete(jid);
      }
      for (const [jid, data] of rateLimits.entries()) {
        if (now > data.resetTime) rateLimits.delete(jid);
      }
      groupMetaCache.flushAll();
      msgDuplicateCache.flushAll();
      miscCache.flushAll();
    }, 300000);

    // Watcher reload otomatis file saat diedit
    const currentFile = require.resolve(__filename);
    fs.watchFile(currentFile, () => {
      fs.unwatchFile(currentFile);
      console.log(chalk.redBright(`Update ${__filename}`));
      delete require.cache[currentFile];
      require(currentFile);
    });

    return sock;
  }

  startBot().catch((err) => {
    console.error(chalk.red("Gagal memulai bot:"), err);
    setTimeout(startBot, 10000);
  });
})();

/**
 * ============================================================================
 * DOCUMENTATION REFERENCE FOR OURIN-BAILEYS
 * 
 * Interactive Messages:
 * sock.sendMessage(jid, {
 *   interactiveMessage: {
 *     title: "Title",
 *     footer: "Footer",
 *     buttons: [{ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Text", id: "id" }) }]
 *   }
 * })
 * 
 * Album Messages:
 * sock.sendMessage(jid, {
 *   albumMessage: [
 *     { image: { url: "./1.jpg" }, caption: "Pic 1" },
 *     { image: { url: "./2.jpg" }, caption: "Pic 2" }
 *   ]
 * })
 * 
 * Rich Responses:
 * sock.sendTable(jid, title, headers, rows, quoted, options)
 * sock.sendTableV2(jid, table, quoted, options)
 * sock.sendCodeBlock(jid, code, quoted, options)
 * sock.sendCodeBlockV2(jid, code, quoted, options)
 * sock.sendLink(jid, text, links, quoted, options)
 * sock.sendLinkV2(jid, text, links, quoted, options)
 * sock.sendRichMessage(jid, submessages, quoted)
 * sock.sendStatusMention(content, jids)
 * 
 * ORich Usage:
 * const ourin = new sock.ORich(sock).addText("Hello").addSuggest(["A", "B"]);
 * await ourin.send(jid);
 * ============================================================================
 */
