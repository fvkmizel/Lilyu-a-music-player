module.exports = require('./alipai-cmd.js');
