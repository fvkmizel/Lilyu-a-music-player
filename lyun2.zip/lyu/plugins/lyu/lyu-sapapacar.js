/**
 * PLUGIN SAPA PACAR LYU STORE
 * BY LYU STORE
 * Jangan hapus credit.
 *
 * FLOW BARU:
 * - .sapapacar on / off / status
 * - .setsapapacar
 *   1. bot minta reply nomor pacar
 *   2. bot minta reply nama pacar
 *   3. bot kirim pilihan mode button + fallback text
 * - nomor 08 otomatis jadi 628
 * - nomor ada spasi/simbol otomatis dibersihkan
 * - cooldown global 30 menit, jadi tidak spam antar grup
 */

const fs = require("fs")
const path = require("path")

const DB_DIR = path.join(process.cwd(), "library/database")
const DB_FILE = path.join(DB_DIR, "sapa_pacar.json")

const COOLDOWN_MS = 30 * 60 * 1000
const DEFAULT_MODE = "bucin"
const PREFIX = global.prefix && typeof global.prefix === "string" ? global.prefix : "."

// =========================
// DB
// =========================
function defaultDB() {
  return {
    enabled: false,
    pacarPhone: "",
    pacarJid: "",
    pacarName: "",
    mode: DEFAULT_MODE,
    lastSapaAt: 0,
    lastSapaChat: "",
    setup: {
      active: false,
      step: "",
      owner: "",
      chat: "",
      tempPhone: "",
      updatedAt: 0
    }
  }
}

function ensureDB() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true })
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(defaultDB(), null, 2), "utf8")
}

function loadDB() {
  ensureDB()
  try {
    const raw = fs.readFileSync(DB_FILE, "utf8")
    const db = raw ? JSON.parse(raw) : defaultDB()
    const base = defaultDB()

    return {
      ...base,
      ...db,
      setup: {
        ...base.setup,
        ...(db.setup || {})
      }
    }
  } catch {
    return defaultDB()
  }
}

function saveDB(db) {
  ensureDB()
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf8")
}

// =========================
// UTIL
// =========================
function cleanPhone(input = "") {
  let n = String(input || "").replace(/[^\d]/g, "")

  if (n.startsWith("00")) n = n.slice(2)
  if (n.startsWith("0")) n = "62" + n.slice(1)

  return n
}

function phoneToJid(phone = "") {
  return `${cleanPhone(phone)}@s.whatsapp.net`
}

function normalizeJid(jid = "") {
  return String(jid || "").replace(/:.*@/, "@")
}

function jidToPhone(jid = "") {
  return cleanPhone(String(jid || "").split("@")[0])
}

function mentionTag(jid = "") {
  return `@${String(jid || "").split("@")[0]}`
}

function ownerName() {
  return global.namaOwner || global.ownername || global.namaCreator || "owner"
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

function msToMinute(ms) {
  return Math.ceil(ms / 60000)
}

function getBody(m) {
  return (
    m.text ||
    m.body ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    ""
  ).trim()
}

function isCommand(text = "") {
  return /^[.!#\/\\]/.test(String(text || "").trim())
}

async function replySafe(alip, m, Reply, text, extra = {}) {
  try {
    if (typeof Reply === "function") return Reply(text)
    return alip.sendMessage(m.chat, { text, ...extra }, { quoted: m })
  } catch (e) {
    console.error("[SAPA PACAR REPLY ERROR]", e?.message || e)
  }
}

function getModeList() {
  return ["bucin", "normal", "manja", "cool", "alay"]
}

function getSelectedButtonId(m) {
  const basic =
    m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.templateButtonReplyMessage?.selectedId ||
    ""

  if (basic) return basic

  const paramsJson =
    m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
    ""

  if (paramsJson) {
    try {
      const parsed = JSON.parse(paramsJson)
      return parsed.id || parsed.selectedId || ""
    } catch {}
  }

  return ""
}

// =========================
// LID SAFE RESOLVER
// =========================
async function getMetadataSafe(alip, chat) {
  try {
    if (!chat || !String(chat).endsWith("@g.us")) return null
    return await alip.groupMetadata(chat)
  } catch {
    return null
  }
}

function getParticipantsFromMessage(m) {
  return (
    m?.metadata?.participants ||
    m?.groupMetadata?.participants ||
    m?.msg?.contextInfo?.participants ||
    []
  )
}

function pickRealJidFromParticipant(p) {
  if (!p) return null

  const candidates = [p.jid, p.id, p.phoneNumber, p.lid].filter(Boolean)

  for (const c of candidates) {
    const jid = normalizeJid(c)
    if (jid.endsWith("@s.whatsapp.net")) return jid
  }

  return null
}

async function resolveRealJid(alip, m, jid) {
  jid = normalizeJid(jid)
  if (!jid) return jid
  if (!jid.endsWith("@lid")) return jid

  let participants = getParticipantsFromMessage(m)

  if (!Array.isArray(participants) || !participants.length) {
    const meta = await getMetadataSafe(alip, m.chat)
    participants = meta?.participants || []
  }

  const found = participants.find(p => {
    return (
      normalizeJid(p?.id) === jid ||
      normalizeJid(p?.jid) === jid ||
      normalizeJid(p?.lid) === jid ||
      normalizeJid(p?.phoneNumber) === jid
    )
  })

  return pickRealJidFromParticipant(found) || jid
}

async function getSenderRealJid(alip, m) {
  const sender =
    m?.sender ||
    m?.participant ||
    m?.key?.participant ||
    ""

  return resolveRealJid(alip, m, sender)
}

async function getSenderPhone(alip, m) {
  const jid = await getSenderRealJid(alip, m)
  return jidToPhone(jid)
}

// =========================
// RANDOM TEXT
// =========================

const TEXTS = {
  bucin: [
    `*wah ayang {owner} online nih!*\n\nhai kak {tag} 🥰`,
    `*cieee {name} muncul, auto senyum deh {owner} 😭💕*\n\n*halo kak {tag} 💋*`,
    `*anjay ayangnya {owner} nongol, grup jadi adem 😋*\n\nhai {tag}`,
    `*woy woy minggir dulu, ayang {owner} online 😭💗*\n\nhai kak {tag}`,
    `*{name} hadir nih, hati {owner} langsung loading cinta 💞*\n\nhai {tag}`,
    `*akhirnya {tag} online juga, dari tadi ditungguin {owner} tuh 😭*`,
    `*izin info, ayang {owner} baru aja muncul di grup 😋*\n\nhalo {tag}`,
    `*wah ada {name}, mood {owner} naik 100% nih 🥰*\n\nhai {tag}`,
    `*eh eh {tag} online, siap-siap {owner} salting 😭💕*`,
    `*grup jadi cerah gara-gara {name} muncul 😋*\n\nhai kak {tag}`,
    `*ayang {owner} detected online 😭💗*\n\nhai kak {tag}`,
    `*{tag} online nih, {owner} jangan pura-pura gak liat ya 😭*`,
    `*cie yang bikin {owner} senyum udah online 🥰*\n\nhalo {tag}`,
    `*ada {name}, ada cinta, ada {owner} yang auto bahagia 😋*`,
    `*wah pacarnya {owner} muncul, langsung beda auranya grup ini 💗*\n\nhai {tag}`,
    `*notif cinta masuk: {name} online 😭💕*\n\nhai kak {tag}`,
    `*permisi, ayang {owner} lewat dulu 😋*\n\nhalo {tag}`,
    `*{tag} baru chat dikit aja, {owner} udah senyum-senyum sendiri tuh 😭*`,
    `*wah {name} online, semesta auto dukung {owner} 🥰*`,
    `*hai {tag}, ayangnya {owner} yang paling ditunggu akhirnya muncul 😭💗*`
  ],

  normal: [
    `*wah {name} online nih.*\n\nhai kak {tag}`,
    `*halo kak {tag}, selamat datang lagi di grup 👋*`,
    `*{name} baru aktif nih, hai kak {tag}*`,
    `*hai kak {tag}, semoga harinya lancar ya*`,
    `*wah ada {name}, halo kak {tag}*`,
    `*hai {tag}, lagi online juga ternyata*`,
    `*selamat datang kak {tag}, jangan lupa ramein grup ya*`,
    `*halo {name}, semoga betah ngobrol di grup ini*`,
    `*hai kak {tag}, ada yang bisa dibantu?*`,
    `*{name} muncul, grup jadi rame lagi nih*`,
    `*halo kak {tag}, apa kabar?*`,
    `*wah kak {tag} online, selamat bergabung lagi*`,
    `*hai {name}, semoga mood-nya bagus hari ini*`,
    `*halo {tag}, semangat terus ya*`,
    `*kak {tag} online nih, halo halo*`,
    `*hai kak {tag}, jangan lupa senyum hari ini*`,
    `*{name} hadir, welcome back kak*`,
    `*halo kak {tag}, semoga nyaman di grup*`,
    `*wah {name} nongol juga, hai kak {tag}*`,
    `*hai {tag}, semoga chat-nya seru hari ini*`
  ],

  manja: [
    `*ayang {owner} online nihh 😚*\n\nhai kak {tag}`,
    `*ih ada {name}, gemes banget baru muncul 😭💗*\n\nhai {tag}`,
    `*{tag} online, {owner} pasti langsung manja nih 😚*`,
    `*haii kak {tag}, jangan cuekin {owner} yaa 😭*`,
    `*wah {name} hadir, sini disambut dulu 😋*`,
    `*ayangnya {owner} muncul, auto pengen disapa balik 😚*`,
    `*hai {tag}, {owner} nungguin kamu dari tadi tauu 😭*`,
    `*{name} online nih, jangan kabur dulu yaa 💗*`,
    `*ih kak {tag} muncul, grup jadi lucu 😋*`,
    `*hai ayangnya {owner}, jangan lupa senyum yaa 😚*`,
    `*cie {name}, bikin {owner} kangen aja 😭💞*`,
    `*halo kak {tag}, sini ngobrol bentar jangan diem aja 😋*`,
    `*{tag} online, {owner} auto mode clingy 😭*`,
    `*hai {name}, lucu banget baru nongol sekarang 😚*`,
    `*ayang {owner} hadir, semua wajib sopan 😭💗*`,
    `*halo {tag}, jangan cuek-cuek amat dong 😋*`,
    `*wah {name} muncul, pengen disapa terus ya? 😚*`,
    `*hai kak {tag}, {owner} pasti seneng banget nih*`,
    `*ih ada pacarnya {owner}, gemes 😭💕*`,
    `*halo {name}, sini ramein grup bentar 😋*`
  ],

  cool: [
    `*{name} online.*\n\nhai {tag}`,
    `*target spesial terdeteksi: {tag}*`,
    `*wah {name} muncul, halo.*`,
    `*online juga akhirnya, {tag}*`,
    `*noted: {name} aktif di grup.*`,
    `*hai {tag}, welcome back.*`,
    `*{tag} hadir. grup aman.*`,
    `*ada {name}. lanjutkan aktivitas.*`,
    `*halo {tag}, stay cool.*`,
    `*wah ayang {owner} online nih.*\n\nhai {tag}`,
    `*pacar owner detected: {name}*`,
    `*{tag} sudah online, sistem menyambut.*`,
    `*hai {name}, mode santai aktif.*`,
    `*online check: {tag} ✅*`,
    `*welcome back, {name}.*`,
    `*grup kedatangan {tag}.*`,
    `*hai {tag}, jangan lupa enjoy.*`,
    `*{name} aktif, cooldown sapa dimulai.*`,
    `*halo {tag}, good to see you.*`,
    `*status: {name} online.*`
  ],

  alay: [
    `*waduuuhh si {name} ol niihh 😭🔥*\n\nhaiii {tag}`,
    `*anjayy pacar {owner} muncuull 😭💗*\n\nhalo {tag}`,
    `*cie cie cieee {tag} onlineee 😋*`,
    `*buset {name} hadir, auto rame ini mah 😭*`,
    `*haii {tag}, jangan sombong yahh 😋*`,
    `*wahh ada ayangnya {owner} nihh, eaaa 😭💞*`,
    `*info penting: {name} online ges 😭*`,
    `*halo {tag}, jangan ghosting {owner} yaa 😭*`,
    `*anjay {name} nongol, grup auto wangi 😋*`,
    `*sistem mendeteksi ayang owner: {tag} 😭🔥*`,
    `*ciee yang ditunggu-tunggu hadir nihh {tag}*`,
    `*wahh {owner} pasti senyum-senyum nih, {name} online 😭*`,
    `*eh eh ada {tag}, jangan pada ganggu ya 😋*`,
    `*halo {name}, welcome back bestie eh pacar owner 😭*`,
    `*mode bucin grup aktif gara-gara {tag} muncul 💗*`,
    `*anjir {name} online, {owner} mana nih 😭*`,
    `*hai {tag}, semoga gak cuek hari ini 😋*`,
    `*{name} detected, hati {owner} auto jedag jedug 😭*`,
    `*woy {tag} online, siap-siap disayang owner 😋*`,
    `*halo kak {tag}, aura pacar ownernya kuat bet 😭*`
  ]
}

function renderText(template, db, jid) {
  return String(template || "")
    .replaceAll("{owner}", ownerName())
    .replaceAll("{name}", db.pacarName || "ayang")
    .replaceAll("{tag}", mentionTag(jid))
}

// =========================
// MODE PICKER
// =========================
async function sendModePicker(alip, m, db) {
  const rows = getModeList().map(mode => ({
    title: mode.toUpperCase(),
    description: `Pakai mode sapaan ${mode}`,
    id: `${PREFIX}sapapacarmode ${mode}`
  }))

  return alip.sendMessage(
    m.chat,
    {
      text:
        `✅ *Nomor & nama pacar sudah tersimpan!*\n\n` +
        `👤 Nama: *${db.pacarName}*\n` +
        `📱 Nomor: *${db.pacarPhone}*\n\n` +
        `Sekarang pilih mode sapaan.\n` +
        `Kalau button gak muncul, ketik manual:\n` +
        `${PREFIX}modesapapacar bucin\n` +
        `${PREFIX}modesapapacar normal\n` +
        `${PREFIX}modesapapacar manja\n` +
        `${PREFIX}modesapapacar cool\n` +
        `${PREFIX}modesapapacar alay`,
      footer: "LYU STORE",
      buttons: [
        {
          buttonId: "pilih_mode_sapa_pacar",
          buttonText: { displayText: "💗 Pilih Mode Sapa" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "Pilih Mode Sapa Pacar",
              sections: [
                {
                  title: "Mode Tersedia",
                  rows
                }
              ]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true
    },
    { quoted: m }
  )
}

// =========================
// MAIN HANDLER
// =========================
let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  try {
    ensureDB()

    const cmd = String(command || "").toLowerCase()
    const arg = String(text || "").trim().toLowerCase()

    if (cmd === "sapapacar") {
      if (!isCreator) return replySafe(alip, m, Reply, "❌ Khusus owner.")

      const db = loadDB()

      if (arg === "on") {
        db.enabled = true
        saveDB(db)

        return replySafe(
          alip,
          m,
          Reply,
          `✅ *Sapa pacar diaktifkan!*\n\n` +
            `Lanjut set data pacar:\n` +
            `${PREFIX}setsapapacar`
        )
      }

      if (arg === "off") {
        db.enabled = false
        saveDB(db)
        return replySafe(alip, m, Reply, "✅ Sapa pacar dimatikan.")
      }

      if (!arg || arg === "status") {
        const now = Date.now()
        const last = Number(db.lastSapaAt || 0)
        const sisa = COOLDOWN_MS - (now - last)

        return replySafe(
          alip,
          m,
          Reply,
          `📌 *STATUS SAPA PACAR*\n\n` +
            `Status: *${db.enabled ? "ON" : "OFF"}*\n` +
            `Nama: *${db.pacarName || "-"}*\n` +
            `Nomor: *${db.pacarPhone || "-"}*\n` +
            `Mode: *${db.mode || DEFAULT_MODE}*\n` +
            `Cooldown: *30 menit global*\n` +
            `Sisa cooldown: *${sisa > 0 ? `${msToMinute(sisa)} menit` : "siap sapa"}*\n\n` +
            `Command:\n` +
            `• ${PREFIX}sapapacar on\n` +
            `• ${PREFIX}sapapacar off\n` +
            `• ${PREFIX}setsapapacar\n` +
            `• ${PREFIX}modesapapacar bucin/normal/manja/cool/alay\n` +
            `• ${PREFIX}delsapapacar`
        )
      }

      return replySafe(alip, m, Reply, `Format:\n${PREFIX}sapapacar on\n${PREFIX}sapapacar off\n${PREFIX}sapapacar status`)
    }

    if (cmd === "setsapapacar") {
      if (!isCreator) return replySafe(alip, m, Reply, "❌ Khusus owner.")

      const db = loadDB()
      db.setup = {
        active: true,
        step: "phone",
        owner: normalizeJid(m.sender),
        chat: m.chat,
        tempPhone: "",
        updatedAt: Date.now()
      }

      saveDB(db)

      return replySafe(
        alip,
        m,
        Reply,
        `💗 *SET SAPA PACAR*\n\n` +
          `Reply pesan ini dengan *nomor WA pacar*.\n\n` +
          `Contoh:\n` +
          `628123456789\n` +
          `0812 3456 7890\n` +
          `+62 812-3456-7890\n\n` +
          `Tenang, nomor 08 / spasi / simbol bakal otomatis dibenerin.`
      )
    }

    if (cmd === "modesapapacar") {
      if (!isCreator) return replySafe(alip, m, Reply, "❌ Khusus owner.")

      const mode = String(text || "").trim().toLowerCase()
      const modes = getModeList()

      if (!modes.includes(mode)) {
        return replySafe(
          alip,
          m,
          Reply,
          `Mode tidak valid.\n\nMode tersedia:\n${modes.map(v => `• ${PREFIX}modesapapacar ${v}`).join("\n")}`
        )
      }

      const db = loadDB()
      if (!db.pacarPhone) {
        return replySafe(alip, m, Reply, `❌ Data pacar belum diset.\nPakai: ${PREFIX}setsapapacar`)
      }

      db.mode = mode
      db.enabled = true
      db.setup = {
        active: false,
        step: "",
        owner: "",
        chat: "",
        tempPhone: "",
        updatedAt: 0
      }

      saveDB(db)

      return replySafe(
        alip,
        m,
        Reply,
        `✅ *Done!*\n\n` +
          `Sapa pacar aktif.\n` +
          `👤 Nama: *${db.pacarName}*\n` +
          `📱 Nomor: *${db.pacarPhone}*\n` +
          `🎭 Mode: *${mode}*\n` +
          `⏳ Cooldown: *30 menit global*`
      )
    }

    if (cmd === "delsapapacar") {
      if (!isCreator) return replySafe(alip, m, Reply, "❌ Khusus owner.")

      saveDB(defaultDB())

      return replySafe(alip, m, Reply, "✅ Data sapa pacar sudah dihapus.")
    }
  } catch (e) {
    console.error("[SAPA PACAR MAIN ERROR]", e)
    return replySafe(alip, m, Reply, `❌ Error sapa pacar:\n${e.message || e}`)
  }
}

// =========================
// BEFORE HANDLER
// =========================
handler.before = async function (m, { alip, isCreator }) {
  try {
    ensureDB()

    const db = loadDB()
    const body = getBody(m)
    const selectedId = getSelectedButtonId(m)

    // ===== MODE BUTTON =====
    if (selectedId.startsWith(`${PREFIX}sapapacarmode `)) {
      if (!isCreator) return true

      const mode = selectedId.split(" ").slice(1).join(" ").trim().toLowerCase()

      if (!getModeList().includes(mode)) {
        await alip.sendMessage(m.chat, { text: "Mode tidak valid." }, { quoted: m })
        return true
      }

      db.mode = mode
      db.enabled = true
      db.setup = {
        active: false,
        step: "",
        owner: "",
        chat: "",
        tempPhone: "",
        updatedAt: 0
      }

      saveDB(db)

      await alip.sendMessage(
        m.chat,
        {
          text:
            `✅ *Done!*\n\n` +
            `Sapa pacar aktif.\n` +
            `👤 Nama: *${db.pacarName}*\n` +
            `📱 Nomor: *${db.pacarPhone}*\n` +
            `🎭 Mode: *${mode}*\n` +
            `⏳ Cooldown: *30 menit global*`
        },
        { quoted: m }
      )

      return true
    }

    // ===== SETUP FLOW TEXT =====
    if (
      db.setup?.active &&
      isCreator &&
      normalizeJid(m.sender) === normalizeJid(db.setup.owner) &&
      m.chat === db.setup.chat &&
      body &&
      !isCommand(body)
    ) {
      if (Date.now() - Number(db.setup.updatedAt || 0) > 10 * 60 * 1000) {
        db.setup = defaultDB().setup
        saveDB(db)
        await alip.sendMessage(m.chat, { text: `⏰ Setup sapa pacar expired. Ulangi: ${PREFIX}setsapapacar` }, { quoted: m })
        return true
      }

      if (db.setup.step === "phone") {
        const phone = cleanPhone(body)

        if (!phone || phone.length < 8) {
          await alip.sendMessage(
            m.chat,
            {
              text:
                `❌ Nomor tidak valid.\n\n` +
                `Reply lagi pakai nomor WA pacar.\n` +
                `Contoh: 0812 3456 7890 atau 628123456789`
            },
            { quoted: m }
          )
          return true
        }

        db.setup.tempPhone = phone
        db.setup.step = "name"
        db.setup.updatedAt = Date.now()
        saveDB(db)

        await alip.sendMessage(
          m.chat,
          {
            text:
              `✅ Nomor kebaca: *${phone}*\n\n` +
              `Sekarang reply pesan ini dengan *nama pacar*.\n\n` +
              `Contoh:\n` +
              `Naya\n` +
              `Ayang Lyu\n` +
              `Cintaku`
          },
          { quoted: m }
        )

        return true
      }

      if (db.setup.step === "name") {
        const name = String(body || "").trim()

        if (!name || name.length < 2 || name.length > 40) {
          await alip.sendMessage(
            m.chat,
            {
              text: `❌ Nama tidak valid.\nReply lagi pakai nama pacar, minimal 2 karakter dan maksimal 40 karakter.`
            },
            { quoted: m }
          )
          return true
        }

        db.pacarPhone = db.setup.tempPhone
        db.pacarJid = phoneToJid(db.setup.tempPhone)
        db.pacarName = name
        db.enabled = true
        db.mode = db.mode || DEFAULT_MODE
        db.setup.step = "mode"
        db.setup.updatedAt = Date.now()
        saveDB(db)

        await sendModePicker(alip, m, db)
        return true
      }

      if (db.setup.step === "mode") {
        const mode = body.toLowerCase().trim()

        if (!getModeList().includes(mode)) {
          await alip.sendMessage(
            m.chat,
            {
              text:
                `❌ Mode tidak valid.\n\n` +
                `Ketik salah satu:\n` +
                `${getModeList().join(" / ")}`
            },
            { quoted: m }
          )
          return true
        }

        db.mode = mode
        db.enabled = true
        db.setup = defaultDB().setup
        saveDB(db)

        await alip.sendMessage(
          m.chat,
          {
            text:
              `✅ *Done!*\n\n` +
              `Sapa pacar aktif.\n` +
              `👤 Nama: *${db.pacarName}*\n` +
              `📱 Nomor: *${db.pacarPhone}*\n` +
              `🎭 Mode: *${mode}*\n` +
              `⏳ Cooldown: *30 menit global*`
          },
          { quoted: m }
        )

        return true
      }
    }

    // ===== AUTO SAPA =====
    if (!m.isGroup) return false
    if (m.fromMe) return false
    if (!db.enabled) return false
    if (!db.pacarPhone) return false

    const senderPhone = await getSenderPhone(alip, m)
    if (!senderPhone) return false

    if (String(senderPhone) !== String(db.pacarPhone)) return false

    const now = Date.now()
    const last = Number(db.lastSapaAt || 0)

    if (now - last < COOLDOWN_MS) return false

    const senderJid = await getSenderRealJid(alip, m)
    const mode = TEXTS[db.mode] ? db.mode : DEFAULT_MODE
    const template = pick(TEXTS[mode])
    const finalText = renderText(template, db, senderJid)

    await alip.sendMessage(
      m.chat,
      {
        text: finalText,
        mentions: [senderJid]
      },
      { quoted: m }
    )

    db.lastSapaAt = now
    db.lastSapaChat = m.chat
    saveDB(db)

    return false
  } catch (e) {
    console.error("[SAPA PACAR BEFORE ERROR]", e)
    return false
  }
}

handler.command = [
  "sapapacar",
  "setsapapacar",
  "modesapapacar",
  "delsapapacar"
]

module.exports = handler