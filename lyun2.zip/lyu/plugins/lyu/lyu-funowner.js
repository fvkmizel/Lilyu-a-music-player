/**
 * PLUGIN DELBOT / STARTBOT - LYU STORE
 * BY LYU STORE ( NO HAPUS CREDIT! )
 */

const fs = require("fs");
const path = require("path");
const { createCanvas, loadImage } = require("canvas");
const fetch = require("node-fetch");

// ===== CONFIG =====
const SUPER_OWNER = "6283173403262";
const DB_DIR = path.join(process.cwd(), "library/database");
const DB_FILE = path.join(DB_DIR, "lyu-delbot.json");

// ===== DB =====
function ensureDB() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "{}", "utf8");
}

function loadDB() {
  ensureDB();
  try {
    const raw = fs.readFileSync(DB_FILE, "utf8");
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveDB(data) {
  ensureDB();
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("❌ Gagal simpan DB delbot:", e);
  }
}

// ===== UTIL =====
function normalizeNumber(x) {
  return String(x || "").replace(/\D/g, "");
}

function isSuperOwner(sender) {
  return normalizeNumber(sender) === normalizeNumber(SUPER_OWNER);
}

function getOwnerNumber() {
  let o = global.owner || "";
  if (Array.isArray(o)) o = o[0] || "";
  if (Array.isArray(o)) o = o[0] || "";
  return normalizeNumber(String(o));
}

function isBotOwner(sender) {
  const senderNum = normalizeNumber(sender);
  const ownerNum = getOwnerNumber();
  // Kalau owner bot = superowner, jangan dianggap "bot owner yang bisa diblok"
  if (senderNum === normalizeNumber(SUPER_OWNER)) return false;
  return senderNum === ownerNum;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ===== CANVAS BLOCKER IMAGE =====
async function makeBlockerImage(alip, ownerJid) {
  const size = 512;
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext("2d");

  // Background gelap
  ctx.fillStyle = "#1a1a1a";
  ctx.fillRect(0, 0, size, size);

  // Border merah
  ctx.strokeStyle = "#ff0000";
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, size - 8, size - 8);

  // Coba ambil PP owner
  let ppLoaded = false;
  try {
    const ppUrl = await alip.profilePictureUrl(ownerJid, "image").catch(() => null);
    if (ppUrl) {
      const res = await fetch(ppUrl);
      if (res.ok) {
        const buf = await res.buffer();
        const img = await loadImage(buf);

        // Gambar PP di tengah atas, bulat
        const ppSize = 160;
        const ppX = (size - ppSize) / 2;
        const ppY = 60;

        ctx.save();
        ctx.beginPath();
        ctx.arc(ppX + ppSize / 2, ppY + ppSize / 2, ppSize / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(img, ppX, ppY, ppSize, ppSize);
        ctx.restore();

        // Border lingkaran merah
        ctx.strokeStyle = "#ff0000";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(ppX + ppSize / 2, ppY + ppSize / 2, ppSize / 2, 0, Math.PI * 2);
        ctx.stroke();

        ppLoaded = true;
      }
    }
  } catch {}

  if (!ppLoaded) {
    // Placeholder kalau pp gagal
    const ppSize = 160;
    const ppX = (size - ppSize) / 2;
    const ppY = 60;
    ctx.fillStyle = "#333";
    ctx.beginPath();
    ctx.arc(ppX + ppSize / 2, ppY + ppSize / 2, ppSize / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ff0000";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(ppX + ppSize / 2, ppY + ppSize / 2, ppSize / 2, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = "#666";
    ctx.font = "bold 48px Sans";
    ctx.textAlign = "center";
    ctx.fillText("?", size / 2, ppY + ppSize / 2 + 16);
  }

  // Nama Owner
  const ownerName = global.namaOwner || getOwnerNumber() || "Owner";
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 24px Sans";
  ctx.textAlign = "center";
  ctx.fillText(ownerName, size / 2, 260);

  // Nama Bot
  const botName = global.botname || global.botname2 || "BOT";
  ctx.fillStyle = "#aaaaaa";
  ctx.font = "18px Sans";
  ctx.textAlign = "center";
  ctx.fillText(botName, size / 2, 290);

  // Garis pemisah
  ctx.strokeStyle = "#ff0000";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(40, 310);
  ctx.lineTo(size - 40, 310);
  ctx.stroke();

  // Watermark BLOCKED — besar, merah, miring
  ctx.save();
  ctx.translate(size / 2, size / 2 + 60);
  ctx.rotate(-0.35);
  ctx.font = "bold 90px Sans";
  ctx.fillStyle = "rgba(255, 0, 0, 0.18)";
  ctx.textAlign = "center";
  ctx.fillText("BLOCKED", 0, 0);
  ctx.restore();

  // Teks BLOCKED merah solid di tengah bawah
  ctx.fillStyle = "#ff0000";
  ctx.font = "bold 52px Sans";
  ctx.textAlign = "center";
  ctx.fillText("BLOCKED", size / 2, 380);

  // Sub teks
  ctx.fillStyle = "#888888";
  ctx.font = "14px Sans";
  ctx.textAlign = "center";
  ctx.fillText("by Lyu Dev", size / 2, 410);

  // Footer
  ctx.fillStyle = "#ff0000";
  ctx.font = "bold 13px Sans";
  ctx.textAlign = "center";
  ctx.fillText("⛔ AKSES DICABUT OLEH OWNER LYU STORE ⛔", size / 2, 480);

  return canvas.toBuffer("image/jpeg", { quality: 0.92 });
}

// ===== EDIT PROGRESS =====
async function editMsg(alip, chat, key, text) {
  try {
    await alip.sendMessage(chat, { text, edit: key });
  } catch {}
}

// ===== HANDLER =====
let handler = async (m, { alip, command, Reply }) => {
  const cmd = String(command || "").toLowerCase();
  const sender = m.sender || m.key?.participant || m.key?.remoteJid;

  // ===== .delbot =====
  if (cmd === "delbot") {
    if (!isSuperOwner(sender)) {
      return Reply("⛔ Hanya *Tuan Lyu* yang bisa menggunakan perintah ini.");
    }

    const db = loadDB();
    if (db.blocked) {
      return Reply("⚠️ Bot sudah dalam kondisi diblokir tuan. Ketik *.startbot* untuk mengaktifkan kembali.");
    }

    // Loading anim
    const loadingFrames = [
      "🙏 Baik tuan, saya laksanakan perintah *Tuan Lyu Store* 😊🙏",
      "🔒 Sebentar tuan, saya sedang *memblokir seluruh akses* nya tuan...",
      "🌐 Sedang *memblok seluruh jaringan* bot ini tuan...",
      "☠️ Menambahkan *malware khusus* dari tuan ke sistem mereka...",
      "🛑 Mengunci *semua fitur dan command* bot tuan...",
      "🔐 Mengenkripsi *database akses* owner tersebut tuan...",
      "⛔ Hampir selesai tuan, *finalisasi pemblokiran*...",
      `✅ Selesai tuan! Akses bot *${global.botname || "BOT"}* telah *dihentikan* 🙏`
    ];

    let loadingMsg;
    try {
      loadingMsg = await alip.sendMessage(
        m.chat,
        { text: loadingFrames[0] },
        { quoted: m }
      );
    } catch {
      return Reply("❌ Gagal kirim pesan loading.");
    }

    for (let i = 1; i < loadingFrames.length; i++) {
      await sleep(1000 + Math.floor(Math.random() * 400));
      await editMsg(alip, m.chat, loadingMsg.key, loadingFrames[i]);
    }

    await sleep(800);

    // Simpan status blocked
    db.blocked = true;
    db.blockedAt = Date.now();
    db.blockedBy = sender;
    saveDB(db);

    // Kirim gambar blocker
    try {
      const ownerNum = getOwnerNumber();
      const ownerJid = ownerNum ? `${ownerNum}@s.whatsapp.net` : m.chat;
      const imgBuffer = await makeBlockerImage(alip, ownerJid);

      await alip.sendMessage(
        m.chat,
        {
          image: imgBuffer,
          caption:
            `⛔ *Akses bot ${global.botname || "BOT"} di berhentikan oleh Tuan Lyu* 🙏\n\n` +
            `Semua permintaan dari owner bot ini akan ditolak sampai Tuan Lyu mengaktifkan kembali.`
        },
        { quoted: m }
      );
    } catch (e) {
      console.error("Gagal kirim gambar blocker:", e);
      await alip.sendMessage(
        m.chat,
        {
          text:
            `⛔ *Akses bot ${global.botname || "BOT"} di berhentikan oleh Tuan Lyu* 🙏\n\n` +
            `Semua permintaan dari owner bot ini akan ditolak sampai Tuan Lyu mengaktifkan kembali.`
        },
        { quoted: m }
      );
    }

    return;
  }

  // ===== .startbot =====
  if (cmd === "startbot") {
    if (!isSuperOwner(sender)) {
      return Reply("⛔ Hanya *Tuan Lyu* yang bisa mengaktifkan kembali bot ini.");
    }
// Cek kalau owner bot = nomor superowner sendiri
    const ownerNum = getOwnerNumber();
    if (normalizeNumber(ownerNum) === normalizeNumber(SUPER_OWNER)) {
      return Reply(
        `🥺 Maaf tuan, owner bot nya nomor *Tuan Lyu* sendiri...\n` +
        `Saya tidak berani melakukannya terhadap tuan 🙏`
      );
    }
    const db = loadDB();
    if (!db.blocked) {
      return Reply("✅ Bot sudah aktif tuan, tidak perlu distart ulang.");
    }

    db.blocked = false;
    db.unblockedAt = Date.now();
    saveDB(db);

    const ownerName = global.namaOwner || getOwnerNumber() || "Owner";
    const botName = global.botname || "BOT";

    return Reply(
      `✅ *Bot sudah bisa anda gunakan kembali kak ${ownerName}* 🙏\n\n` +
      `Bot *${botName}* telah diaktifkan kembali oleh Tuan Lyu.\n` +
      `Jangan menyinggung perasaan *Tuan Lyu* lagi ya 🙏`
    );
  }
};

// ===== BEFORE: TOLAK SEMUA PESAN OWNER KALAU BLOCKED =====
handler.before = async function (m, { alip, Reply }) {
  const db = loadDB();
  if (!db.blocked) return false;

  const sender = m.sender || m.key?.participant || m.key?.remoteJid;
  if (!sender) return false;

  // Superowner tetap bebas
  if (isSuperOwner(sender)) return false;

  // Cek apakah sender adalah owner bot
  if (!isBotOwner(sender)) return false;

  // Tolak semua pesan/command dari owner bot
  try {
    await alip.sendMessage(
      m.chat,
      {
        text:
          `🚫 Maaf, anda telah *menyinggung Tuan Lyu*.\n\n` +
          `Saya tidak akan pernah membantu anda kecuali *Tuan Lyu* memerintahkan nya 🙏`
      },
      { quoted: m }
    );
  } catch {}

  return true;
};

handler.command = ["delbot", "startbot"];

module.exports = handler;