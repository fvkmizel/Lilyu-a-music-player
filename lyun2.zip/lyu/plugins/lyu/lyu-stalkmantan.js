// STALK MANTAN - LYU STORE

// Dibuat oleh LYU STORE

// Jangan hapus credit.

function sleep(ms) {

  return new Promise(resolve => setTimeout(resolve, ms))

}

function pickRandom(arr) {

  return arr[Math.floor(Math.random() * arr.length)]

}

function getTargetName(m, text) {

  if (m.quoted) {

    return m.quoted.pushName || m.quoted.name || m.quoted.senderName || "Mantan Misterius"

  }

  if (m.mentionedJid && m.mentionedJid.length) {

    const jid = m.mentionedJid[0]

    const num = String(jid).split("@")[0]

    return `Mantan ${num}`

  }

  if (text) return text.trim()

  return null

}

function getPersen(min, max) {

  return Math.floor(Math.random() * (max - min + 1)) + min

}

function buildResult(name) {

  const statusHubungan = [

    "udah punya yang baru 😭",

    "masih sendiri tapi sok bahagia 😌",

    "lagi dekat sama orang lain 👀",

    "katanya move on, tapi masih kepo 😏",

    "masih nyimpen kenangan diam-diam 🥀",

    "sibuk pamer hidup di story 📱",

    "masih suka buka chat lama 😶",

    "udah bahagia tanpa kamu katanya 😌"

  ]

  const levelMoveOn = [

    "0% - masih nyangkut parah",

    "15% - dikit-dikit inget kamu",

    "32% - pura-pura kuat",

    "48% - setengah ikhlas",

    "63% - mulai bisa senyum lagi",

    "79% - tinggal sedikit lagi",

    "92% - udah hampir lupa",

    "100% - kamu siapa ya? 💀"

  ]

  const peluangBalikan = [

    "tipis banget kek kuota jam 11 😭",

    "masih ada, tapi kecil",

    "50:50 tergantung kamu lucu apa nggak",

    "lumayan besar kalau kamu berubah",

    "besar, tapi gengsinya juga besar",

    "mustahil, kecuali admin semesta bantu",

    "jangan ngarep, move on aja 😔",

    "masih mungkin kalau dia gabut"

  ]

  const alasanPutus = [

    "beda tujuan",

    "kurang komunikasi",

    "terlalu banyak drama",

    "salah paham terus",

    "ada orang ketiga bayangan",

    "sama-sama egois",

    "kurang effort",

    "terlalu sering bilang terserah",

    "hubungan cuma rame di awal",

    "salah satunya kebanyakan menghilang"

  ]

  const redFlags = [

    "balas chat 7 jam sekali 🚩",

    "bilang 'terserah' padahal marah 🚩",

    "upload story buat nyindir 🚩",

    "ngambek tapi gak ngasih tau alasan 🚩",

    "masih nyimpen kontak mantan lain 🚩",

    "sering bilang 'gapapa' padahal kenapa-kenapa 🚩",

    "hilang pas kamu butuh 🚩",

    "suka bikin kamu nebak-nebak 🚩"

  ]

  const chatTerakhir = [

    "\"udah ya\"",

    "\"terserah kamu\"",

    "\"aku capek\"",

    "\"jaga diri baik-baik\"",

    "\"maaf ya\"",

    "\"mungkin kita cukup sampai sini\"",

    "\"aku butuh waktu\"",

    "\"jangan chat aku dulu\""

  ]

  const laguGalau = [

    "Hati-Hati di Jalan 🎵",

    "Sial 🎵",

    "Tak Ingin Usai 🎵",

    "Tanpa Cinta 🎵",

    "Rumah Singgah 🎵",

    "Komang 🎵",

    "Celengan Rindu 🎵",

    "Sampai Jadi Debu 🎵"

  ]

  const auraMantan = [

    "cold mode 🧊",

    "sok kuat 😎",

    "diam-diam kangen 🌙",

    "caption galau enjoyer 📖",

    "sad girl / sad boy vibes 🌧️",

    "misterius tapi online terus 👀",

    "udah move on katanya 😌",

    "toxic tapi bikin kangen 💀"

  ]

  const saran = [

    "jangan chat dulu, gengsi dijaga 😌",

    "move on pelan-pelan aja",

    "kalau masih sayang, perbaiki dulu diri sendiri",

    "jangan kepo story tiap malam 😭",

    "hapus chat kalau udah gak kuat",

    "fokus jadi versi terbaik kamu dulu",

    "kalau dia bahagia, ikhlasin",

    "kalau mau balikan, jangan cuma modal kangen"

  ]

  const moveOn = getPersen(1, 100)

  const kangen = getPersen(1, 100)

  const kepo = getPersen(1, 100)

  const peluang = getPersen(1, 100)

  return {

    name,

    statusHubungan: pickRandom(statusHubungan),

    levelMoveOn: pickRandom(levelMoveOn),

    peluangBalikan: pickRandom(peluangBalikan),

    alasanPutus: pickRandom(alasanPutus),

    redFlag: pickRandom(redFlags),

    chatTerakhir: pickRandom(chatTerakhir),

    laguGalau: pickRandom(laguGalau),

    auraMantan: pickRandom(auraMantan),

    saran: pickRandom(saran),

    moveOn,

    kangen,

    kepo,

    peluang

  }

}

function buildCaption(data) {

  return (

`*🔎 STALK MANTAN - LYU STORE*

*Nama:* ${data.name}

*Status sekarang:* ${data.statusHubungan}

*Aura mantan:* ${data.auraMantan}

*📊 HASIL DETEKSI*

• Move on meter: *${data.moveOn}%*

• Masih kangen: *${data.kangen}%*

• Masih kepo kamu: *${data.kepo}%*

• Peluang balikan: *${data.peluang}%*

*💔 ANALISIS HUBUNGAN*

• Alasan putus: *${data.alasanPutus}*

• Red flag terbesar: *${data.redFlag}*

• Chat terakhir vibes: *${data.chatTerakhir}*

• Prediksi balikan: *${data.peluangBalikan}*

*🎵 Lagu galau yang cocok:*

${data.laguGalau}

*🫠 Saran bot:*

${data.saran}

_*Hasil ini 100% hiburan, jangan dibawa ke KUA 😭*_

*By LYU STORE 🚀*`)

}

function getLoadingFrames(name) {

  return [

    `🔎 Sedang buka arsip mantan *${name}* .`,

    `📂 Mengaduk kenangan lama *${name}* ..`,

    `🫣 Mengecek tingkat masih-kangen ...`,

    `💔 Menghitung sisa rasa dan luka .`,

    `📡 Mendeteksi aura mantan toxic ..`,

    `😭 Hampir selesai, jangan nangis dulu ...`

  ]

}

let handler = async (m, { alip, text, Reply, prefix }) => {

  const target = getTargetName(m, text)

  if (!target) {

    return Reply(

      `*Contoh penggunaan:*\n` +

      `${prefix}stalkmantan Nadia\n` +

      `${prefix}stalkmantan @tag\n` +

      `atau reply chat target lalu ketik *${prefix}stalkmantan*`

    )

  }

  const frames = getLoadingFrames(target)

  let loadingMsg = null

  let canEdit = true

  try {

    loadingMsg = await alip.sendMessage(

      m.chat,

      { text: frames[0] },

      { quoted: m }

    )

  } catch {

    canEdit = false

  }

  if (loadingMsg?.key && canEdit) {

    for (let i = 1; i < frames.length; i++) {

      await sleep(900)

      try {

        await alip.sendMessage(m.chat, {

          text: frames[i],

          edit: loadingMsg.key

        })

      } catch {

        canEdit = false

        break

      }

    }

  }

  if (!canEdit) {

    for (let i = 1; i < frames.length; i++) {

      await sleep(900)

      await alip.sendMessage(m.chat, { text: frames[i] }, { quoted: m })

    }

  }

  const result = buildResult(target)

  const caption = buildCaption(result)

  await alip.sendMessage(m.chat, {

    text: caption,

    buttons: [

      {

        buttonId: `${prefix}stalkmantan ${target}`,

        buttonText: { displayText: "🔁 Stalk Lagi" },

        type: 1

      },

      {

        buttonId: `${prefix}moveon`,

        buttonText: { displayText: "💘 Cara Move On" },

        type: 1

      }

    ],

    headerType: 1

  }, { quoted: m })

}

handler.before = async function (m, { alip, prefix, command, Reply }) {

  const btnId =

    m.message?.buttonsResponseMessage?.selectedButtonId ||

    m.message?.templateButtonReplyMessage?.selectedId ||

    ""

  if (!btnId) return false

  if (btnId === `${prefix}moveon` || btnId === ".moveon") {

    const tips = [

      "Hapus chat lama, jangan dibaca pas malam 😭",

      "Jangan stalking terus, nanti susah sembuh 😔",

      "Cari kesibukan baru biar hati gak nganggur 😎",

      "Denger lagu boleh, nangis secukupnya aja 🥀",

      "Ingat, yang tulus gak selalu harus dimiliki ✨",

      "Kalau dia bahagia tanpa kamu, kamu juga harus bisa bahagia tanpa dia 💙",

      "Move on itu proses, bukan lomba 🚶‍♂️"

    ]

    await alip.sendMessage(m.chat, {

      text:

        `*💘 TIPS MOVE ON LYU STORE*\n\n` +

        `${pickRandom(tips)}\n\n` +

        `*Semangat ya, kamu pantas dapat yang lebih baik* 🫶`

    }, { quoted: m })

    return true

  }

  return false

}

handler.command = ["stalkmantan", "moveon"]

module.exports = handler