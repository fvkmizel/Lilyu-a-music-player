// AUTO REACT OWNER MODE — LYU STORE

const fs = require("fs")
const path = require("path")

const DB_DIR = path.join(process.cwd(), "library/database")
const DB_PATH = path.join(DB_DIR, "react_owner_mode.json")

function ensureDb() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true })
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({
      mode: "random"
    }, null, 2))
  }
}

function getSetting() {
  ensureDb()
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf8"))
  } catch {
    return { mode: "random" }
  }
}

function saveSetting(data) {
  ensureDb()
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))
}

function normalizeOwner(ownerValue) {
  let raw = Array.isArray(ownerValue) ? ownerValue[0] : ownerValue
  raw = String(raw || "").replace(/\D/g, "")
  if (!raw) return ""
  return raw + "@s.whatsapp.net"
}

function getOwnerJid() {
  return normalizeOwner(global.owner)
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

function getEmojiListByMode(mode) {
  const EMOJI_MAP = {
    love: [
      "♥️","❤️","🧡","💛","💚","🩵","💙","💜","🤎","🖤","🩶","🩷",
      "💘","💝","💖","💗","💓","💞","💕","💌","💟","❣️","❤️‍🩹","❤️‍🔥","💋","🫶","🌹"
    ],
    fun: [
      "😹","😂","🤣","😆","😁","😎","🤙","🤟","🥳","🤩","🫡","🔥","⚡","✨","💯","🎉","🚀"
    ],
    meme: [
      "🗿","🤡","😭","🥶","🤯","😈","👑","💸","🤑","✅","🧠","🫰","🤌","💥","😹","🤣"
    ],
    cute: [
      "🐱","🐶","🐼","🦊","🐸","🐣","🦋","🍀","🍓","🍭","🍜","🍔","☕","🧋","🌷","🌸"
    ],
    random: [
      "♥️","❤️","💖","🫶","🌹",
      "🗿","😂","🤣","😭","😎","🔥","⚡","✨","💥","🤝","👑","💸","💯",
      "🐱","🐶","🐼","🦋","🍓","☕"
    ]
  }

  return EMOJI_MAP[mode] || EMOJI_MAP.random
}

function getModeLabel(mode) {
  const labels = {
    love: "Love",
    fun: "Fun",
    meme: "Meme",
    cute: "Cute",
    random: "Random",
    off: "Off"
  }
  return labels[mode] || "Random"
}

async function sendModePicker(alip, m, prefix) {
  const currentMode = getSetting().mode || "random"

  const rows = [
    {
      title: "Love Mode",
      description: "React emoji romantis dan heart",
      id: `${prefix}reactownermode love`
    },
    {
      title: "Fun Mode",
      description: "React emoji seru dan rame",
      id: `${prefix}reactownermode fun`
    },
    {
      title: "Meme Mode",
      description: "React emoji meme dan absurd",
      id: `${prefix}reactownermode meme`
    },
    {
      title: "Cute Mode",
      description: "React emoji lucu dan manis",
      id: `${prefix}reactownermode cute`
    },
    {
      title: "Random Mode",
      description: "Campuran semua emoji terbaik",
      id: `${prefix}reactownermode random`
    },
    {
      title: "Off",
      description: "Matikan auto react owner",
      id: `${prefix}reactownermode off`
    }
  ]

  return await alip.sendMessage(m.chat, {
    text:
      `*SET REACT OWNER* ⚙️\n\n` +
      `Mode sekarang: *${getModeLabel(currentMode)}*\n` +
      `Silakan pilih mode react owner di bawah.\n\n` +
      `*By LYU STORE 🚀*`,
    footer: "LYU STORE",
    buttons: [
      {
        buttonId: "pilih_mode_react_owner",
        buttonText: { displayText: "Pilih Mode React" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Mode React Owner",
            sections: [
              {
                title: "Mode Tersedia",
                rows
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m })
}

let handler = async (m, { alip, command, text, Reply, prefix }) => {
  const cmd = String(command || "").toLowerCase()
  const p = prefix || "."
  const ownerJid = getOwnerJid()

  if (m.sender !== ownerJid) return Reply(global.mess?.owner || "Khusus owner.")

  if (cmd === "setreactowner") {
    return await sendModePicker(alip, m, p)
  }

  if (cmd === "reactownermode") {
    const mode = String(text || "").trim().toLowerCase()
    const validModes = ["love", "fun", "meme", "cute", "random", "off"]

    if (!validModes.includes(mode)) {
      return Reply(
        `Mode tidak valid.\n\n` +
        `Contoh:\n` +
        `${p}reactownermode love\n` +
        `${p}reactownermode fun\n` +
        `${p}reactownermode meme\n` +
        `${p}reactownermode cute\n` +
        `${p}reactownermode random\n` +
        `${p}reactownermode off`
      )
    }

    saveSetting({ mode })
    return Reply(`Berhasil ganti mode react owner ke *${getModeLabel(mode)}*`)
  }
}

// AUTO REACT HOOK
handler.before = async function (m, { alip }) {
  const ownerJid = getOwnerJid()
  if (!ownerJid) return false
  if (m.sender !== ownerJid) return false
  if (m.fromMe) return false

  const body =
    m.text ||
    m.caption ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    ""

  const isCommand =
    typeof body === "string" &&
    /^[./!#]/.test(body.trim())

  // biar command setting gak direact
  if (isCommand) return false

  const setting = getSetting()
  const mode = setting.mode || "random"

  if (mode === "off") return false

  const emojis = getEmojiListByMode(mode)
  const emo = pickRandom(emojis)

  try {
    await alip.sendMessage(m.chat, {
      react: {
        text: emo,
        key: m.key
      }
    })
  } catch {}

  return false
}

handler.command = ["setreactowner", "reactownermode"]

module.exports = handler