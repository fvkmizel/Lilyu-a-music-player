/**
 * PLUGIN HUKUMAN LYU STORE
 * BY LYU STORE ( NO HAPUS CREDIT! )
 */

const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const {
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} = require("@whiskeysockets/baileys");

const DB_DIR = path.join(process.cwd(), "library/database");
const DB_FILE = path.join(DB_DIR, "hukuman.json");
const THUMB_URL = "https://files.catbox.moe/hccykr.jpg";

// ===== DB =====
function ensureDB() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "{}", "utf8");
}

function loadDB() {
  ensureDB();
  try {
    const raw = fs.readFileSync(DB_FILE, "utf8");
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    console.error("❌ Gagal load DB hukuman:", e);
    return {};
  }
}

function saveDB(data) {
  ensureDB();
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("❌ Gagal simpan DB hukuman:", e);
  }
}

// ===== UTIL =====
function normalizePhone(n) {
  n = String(n || "").replace(/\D/g, "");
  if (n.startsWith("0")) n = "62" + n.slice(1);
  if (!n.startsWith("62")) n = "62" + n;
  return n;
}

function jidToNumber(jid) {
  return String(jid || "").split("@")[0].replace(/\D/g, "");
}

function ensureChatDB(db, chat) {
  if (!db[chat]) db[chat] = {};
  return db[chat];
}

function getOwnerNumbers() {
  let owners = global.owner || [];
  if (!Array.isArray(owners)) owners = [owners];

  return owners
    .map(v => Array.isArray(v) ? String(v[0] || "") : String(v || ""))
    .map(v => normalizePhone(v))
    .filter(Boolean);
}

function isOwnerJid(jid) {
  const num = normalizePhone(jidToNumber(jid));
  return getOwnerNumbers().includes(num);
}

function resolveMentionToJid(m, id) {
  if (!id) return null;
  if (id.endsWith("@s.whatsapp.net")) return id;

  if (id.endsWith("@lid")) {
    const p = m.metadata?.participants?.find(x => x.lid === id || x.id === id);
    return p?.jid || p?.id || null;
  }

  const p = m.metadata?.participants?.find(x => x.lid === id || x.id === id || x.jid === id);
  return p?.jid || p?.id || id;
}

function parseDurationID(text) {
  const t = String(text || "").toLowerCase().trim();
  const m = t.match(/(\d+)\s*(detik|dtk|jam|hari|hr|bulan|bln|bl)\b/i);
  if (!m) return null;

  const value = parseInt(m[1]);
  const unit = m[2].toLowerCase();
  if (!value || value < 1) return null;

  let ms = 0;
  let label = "";

  if (unit === "detik" || unit === "dtk") {
    ms = value * 1000;
    label = `${value} detik`;
  } else if (unit === "jam") {
    ms = value * 60 * 60 * 1000;
    label = `${value} jam`;
  } else if (unit === "hari" || unit === "hr") {
    ms = value * 24 * 60 * 60 * 1000;
    label = `${value} hari`;
  } else if (unit === "bulan" || unit === "bln" || unit === "bl") {
    ms = value * 30 * 24 * 60 * 60 * 1000;
    label = `${value} bulan`;
  } else {
    return null;
  }

  return { ms, label };
}

function parseHukumInput(m, text) {
  const raw = String(text || "").trim();
  if (!raw) return null;

  const parts = raw.split("|").map(v => v.trim()).filter(Boolean);
  if (parts.length < 3) return null;

  const targetRaw = parts[0];
  const durasiRaw = parts[1];
  const alasanRaw = parts.slice(2).join(" | ");

  let target = null;

  if (m.mentionedJid?.length) {
    target = resolveMentionToJid(m, m.mentionedJid[0]);
  }

  if (!target && m.quoted?.sender) {
    target = resolveMentionToJid(m, m.quoted.sender);
  }

  if (!target) {
    const numMatch = targetRaw.match(/\b(62\d{7,15}|08\d{7,14})\b/);
    if (numMatch) {
      const phone = normalizePhone(numMatch[1]);
      target = `${phone}@s.whatsapp.net`;
    }
  }

  return {
    target,
    durasi: parseDurationID(durasiRaw),
    alasan: String(alasanRaw || "").trim()
  };
}

function formatDate(ts) {
  if (!ts) return "-";
  return new Date(Number(ts)).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta"
  });
}

function msToFancy(ms) {
  ms = Number(ms || 0);
  if (ms <= 0) return "Sudah habis";

  const detik = Math.floor(ms / 1000);
  const hari = Math.floor(detik / 86400);
  const jam = Math.floor((detik % 86400) / 3600);
  const menit = Math.floor((detik % 3600) / 60);
  const sec = detik % 60;

  let out = [];
  if (hari) out.push(`${hari} hari`);
  if (jam) out.push(`${jam} jam`);
  if (menit) out.push(`${menit} menit`);
  if (sec && out.length < 2) out.push(`${sec} detik`);
  return out.join(" ") || "0 detik";
}

function getMsgBody(m) {
  return (
    m.text ||
    m.body ||
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.documentMessage?.caption ||
    ""
  ).trim();
}

function isCommandText(text) {
  return /^[.!#\/\\]/.test(String(text || "").trim());
}

function getDeleteWarning(count, isCmd) {
  const normalMap = {
    3: "ngetik apaan? ngetik yang bener 😭",
    5: "makanya jangan tengil, suruh unhukum dulu sama admin",
    8: "nangis sih kata gw nangis aja sih wkwkwk 🤣",
    10: "gak cape? 😭😭 kuat bet ngechat nya anjir, wkwk"
  };

  const cmdMap = {
    3: "mau pake fitur bot? gak akan bisa wkwk",
    5: "fitur bot juga kagak bakal nyaut, suruh admin .unhukum dulu sana",
    8: "masih nekat pake fitur bot? keren juga ya kamu 😭",
    10: "fitur bot bukan buat napi grup kek lu anjir wkwkwk 😭"
  };

  const map = isCmd ? cmdMap : normalMap;
  return map[count] || null;
}

async function getProfileBuffer(alip, jid) {
  try {
    const pp = await alip.profilePictureUrl(jid, "image").catch(() => null);
    if (!pp) return null;
    const res = await fetch(pp);
    if (!res.ok) return null;
    return await res.buffer();
  } catch {
    return null;
  }
}

// ===== STYLE MESSAGE =====
function buildContextInfo(title = "LYU STORE", body = "Moderasi Grup") {
  return {
    mentionedJid: [],
    externalAdReply: {
      title,
      body,
      mediaType: 1,
      previewType: 0,
      renderLargerThumbnail: true,
      thumbnailUrl: THUMB_URL,
      sourceUrl: ""
    }
  };
}

async function sendStyledText(alip, chat, text, extra = {}) {
  const {
    mentions = [],
    title = "LYU STORE",
    body = "Moderasi Grup",
    quoted
  } = extra;

  return alip.sendMessage(
    chat,
    {
      text,
      mentions,
      contextInfo: {
        ...buildContextInfo(title, body),
        mentionedJid: mentions
      }
    },
    quoted ? { quoted } : {}
  );
}

// ===== CAROUSEL =====
async function sendListhukumCarousel(alip, m, items) {
  const cards = [];

  for (const item of items) {
    const media = await prepareWAMessageMedia(
      { image: item.imageBuffer || { url: THUMB_URL } },
      { upload: alip.waUploadToServer }
    );

    cards.push({
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: item.title,
        subtitle: item.subtitle,
        hasMediaAttachment: true,
        imageMessage: media.imageMessage
      }),
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: item.body
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: "LYU • HUKUMAN SYSTEM"
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "unhukum",
              copy_code: item.copyText
            })
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: "🚨 *DAFTAR HUKUMAN*\n*Geser ke bawah/samping buat cek detail target satu per satu ⬇️*"
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
              text: `TOTAL TARGET: ${items.length}`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
              title: "HUKUMAN AKTIF",
              subtitle: "LYU • Moderasi Grup",
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards
            })
          })
        }
      }
    },
    {}
  );

  await alip.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

// ===== MAIN =====
let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  if (!m.isGroup) return Reply("⚠️ fitur ini cuma bisa dipakai di grup.");

  const cmd = String(command || "").toLowerCase();
  const db = loadDB();
  const chatDB = ensureChatDB(db, m.chat);
  const adminAccess = !!(isCreator || m.isAdmin);

  if (cmd === "hukum") {
    if (!adminAccess) {
      return Reply("❌ cuma admin sama owner yang bisa ngehukum.");
    }

    if (!text) {
      return Reply(`Contoh:
.hukum @tag | 30 jam | spam stiker
.hukum 628xxxx | 2 hari | toxic
.hukum @tag | 15 detik | test
.hukum @tag | 1 bulan | promosi terus`);
    }

    const parsed = parseHukumInput(m, text);
    if (!parsed || !parsed.target) {
      return Reply("⚠️ format salah.\nContoh:\n.hukum @tag | 1 jam | alasan");
    }

    if (!parsed.durasi) {
      return Reply("❌ format durasi salah.\nPakai: detik / jam / hari / bulan\nContoh: 30 jam");
    }

    if (!parsed.alasan) {
      return Reply("⚠️ alasan hukuman wajib diisi.\nContoh:\n.hukum @tag | 1 jam | spam stiker");
    }

    const target = parsed.target;
    const duration = parsed.durasi;
    const alasan = parsed.alasan;

    if (target === m.sender) {
      return Reply("❌ ngapain ngehukum diri sendiri anj tolol.");
    }

    if (isOwnerJid(target)) {
      return Reply("itu owner gw tolol, ngapain ngehukum owner gw? ownernya gw mah bebas tolol gak kek lu!");
    }

    const targetNum = normalizePhone(jidToNumber(target));

    chatDB[targetNum] = {
      jid: target,
      until: Date.now() + duration.ms,
      by: m.sender,
      reason: alasan,
      active: true,
      createdAt: Date.now(),
      deletedCount: 0,
      warnedAt: []
    };

    saveDB(db);

    return sendStyledText(
      alip,
      m.chat,
      `⛔ HUKUMAN DIJATUHKAN

👤 Target: @${targetNum}
⏳ Durasi: ${duration.label}
📝 Alasan: ${alasan}
🛑 Efek: semua chat bakal otomatis di hapus
👮 Dihukum oleh: @${m.sender.split("@")[0]}

Kalau mau bebas, suruh admin/owner ketik .unhukum @tag`,
      {
        mentions: [target, m.sender],
        title: "Hukuman Di Aktifkan",
        body: "LYU STORE • Moderasi Aktif",
        quoted: m
      }
    );
  }

  if (cmd === "unhukum") {
    if (!adminAccess) {
      return Reply("❌ cuma admin sama owner yang bisa cabut hukuman.");
    }

    let finalTarget =
      resolveMentionToJid(m, m.mentionedJid?.[0]) ||
      (m.quoted?.sender ? resolveMentionToJid(m, m.quoted.sender) : null);

    if (!finalTarget && text) {
      const numMatch = String(text).match(/\b(62\d{7,15}|08\d{7,14})\b/);
      if (numMatch) finalTarget = `${normalizePhone(numMatch[1])}@s.whatsapp.net`;
    }

    if (!finalTarget) {
      return Reply("⚠️ tag, reply, atau isi nomor target yang mau di-unhukum.");
    }

    const targetNum = normalizePhone(jidToNumber(finalTarget));
    if (!chatDB[targetNum]) {
      return Reply("✅ user itu gak lagi dihukum.");
    }

    delete chatDB[targetNum];
    saveDB(db);

    return sendStyledText(
      alip,
      m.chat,
      `✅ Hukuman untuk @${targetNum} udah dicabut.
Sekarang dia boleh ngebacot lagi.`,
      {
        mentions: [finalTarget],
        title: "Hukuman Dicabut",
        body: "LYU • Moderasi Grup",
        quoted: m
      }
    );
  }

  if (cmd === "listhukum") {
    if (!adminAccess) {
      return Reply("❌ cuma admin sama owner yang bisa lihat list hukuman.");
    }

    const now = Date.now();
    const activeEntries = Object.entries(chatDB)
      .filter(([_, v]) => v && Number(v.until || 0) > now)
      .sort((a, b) => Number(a[1].until || 0) - Number(b[1].until || 0));

    if (!activeEntries.length) {
      return Reply("✅ gak ada yang lagi kena hukuman di grup ini.");
    }

    const items = [];
    for (const [num, rec] of activeEntries.slice(0, 10)) {
      const targetJid = rec.jid || `${num}@s.whatsapp.net`;
      const byNum = normalizePhone(jidToNumber(rec.by || ""));
      const createdAt = Number(rec.createdAt || 0);
      const until = Number(rec.until || 0);
      const sisa = until - now;

      const body = `📱 Nomor: ${num}
📝 Alasan: ${rec.reason || "-"}
⏳ Sisa: ${msToFancy(sisa)}
🕓 Dihukum: ${formatDate(createdAt)}
⌛ Habis: ${formatDate(until)}
👮 Oleh: ${byNum || "-"}

🗑️ Chat Kehapus: ${Number(rec.deletedCount || 0)} kali`;

      items.push({
        title: `TARGET HUKUMAN`,
        subtitle: `Sisa: ${msToFancy(sisa)}`,
        body,
        copyText: `.unhukum ${num}`,
        imageBuffer: await getProfileBuffer(alip, targetJid)
      });
    }

    try {
      await sendListhukumCarousel(alip, m, items);
    } catch (e) {
      console.error("listhukum carousel error:", e);

      let txt = `*LIST HUKUMAN AKTIF*\n\n`;
      let no = 1;
      for (const [num, rec] of activeEntries) {
        txt += `${no++}. ${num}\n`;
        txt += `• Alasan: ${rec.reason || "-"}\n`;
        txt += `• Sisa: ${msToFancy(Number(rec.until || 0) - now)}\n`;
        txt += `• Oleh: ${normalizePhone(jidToNumber(rec.by || ""))}\n`;
        txt += `• Mulai: ${formatDate(rec.createdAt)}\n`;
        txt += `• Habis: ${formatDate(rec.until)}\n`;
        txt += `• Unhukum: .unhukum ${num}\n\n`;
      }
      await sendStyledText(alip, m.chat, txt.trim(), {
        title: "List Hukuman",
        body: "LYU • Data Hukuman",
        quoted: m
      });
    }

    return;
  }
};

handler.before = async function (m, { alip }) {
  if (!m.isGroup) return false;
  if (m.fromMe) return false;

  const db = loadDB();
  const chatDB = db[m.chat];
  if (!chatDB) return false;

  const senderNum = normalizePhone(jidToNumber(m.sender));
  const rec = chatDB[senderNum];
  if (!rec) return false;

  if (Date.now() > Number(rec.until || 0)) {
    delete chatDB[senderNum];
    saveDB(db);
    return false;
  }

  try {
    await alip.sendMessage(m.chat, { delete: m.key });
  } catch (e) {
    console.error("❌ Gagal hapus pesan hukuman:", e);
  }

  rec.deletedCount = Number(rec.deletedCount || 0) + 1;
  if (!Array.isArray(rec.warnedAt)) rec.warnedAt = [];

  const count = rec.deletedCount;
  const body = getMsgBody(m);
  const cmdMode = isCommandText(body);
  const warnText = getDeleteWarning(count, cmdMode);

  if ([3, 5, 8, 10].includes(count) && warnText && !rec.warnedAt.includes(count)) {
    rec.warnedAt.push(count);
    saveDB(db);

    try {
      await alip.sendMessage(m.chat, {
        text: warnText,
        mentions: [m.sender]
      });
    } catch (e) {
      console.error("❌ Gagal kirim warning:", e);
    }

    return true;
  }

  saveDB(db);
  return true;
};

handler.command = ["hukum", "unhukum", "listhukum"];

module.exports = handler;