const axios = require("axios")
const fs = require("fs")
const path = require("path")
const { createCanvas, loadImage } = require("canvas")
const {
  generateWAMessageFromContent,
  prepareWAMessageMedia
} = require("@whiskeysockets/baileys")

const HL_DEV_UID = "HEyllxAnFpMnEpBKrpoDyfrGj652"
const HL_API_KEY = "zvXG2jHW4Ow1pZPlhz85FnLwG4PC4L".trim()

const DEFAULT_AVATAR = "https://files.catbox.moe/izxo9u.jpg"

const DB_DIR = path.join(process.cwd(), "library/database")
const MODE_PATH = path.join(DB_DIR, "stalkff_mode.json")
const CACHE_PATH = path.join(DB_DIR, "stalkff_cache.json")

const REGION_LIST = [
  { code: "id", name: "🇮🇩 Indonesia" },
  { code: "sg", name: "🇸🇬 Singapore" },
  { code: "br", name: "🇧🇷 Brazil" },
  { code: "th", name: "🇹🇭 Thailand" },
  { code: "vn", name: "🇻🇳 Vietnam" },
  { code: "me", name: "🇦🇪 Middle East" },
  { code: "pk", name: "🇵🇰 Pakistan" },
  { code: "bd", name: "🇧🇩 Bangladesh" },
  { code: "cis", name: "🌍 CIS" },
  { code: "us", name: "🇺🇸 United States" },
  { code: "ru", name: "🇷🇺 Russia" },
  { code: "tw", name: "🇹🇼 Taiwan" },
  { code: "ind", name: "🇮🇳 India" }
]

function ensureDb() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true })
  if (!fs.existsSync(MODE_PATH)) {
    fs.writeFileSync(MODE_PATH, JSON.stringify({ mode: "canvas" }, null, 2))
  }
  if (!fs.existsSync(CACHE_PATH)) {
    fs.writeFileSync(CACHE_PATH, JSON.stringify({}, null, 2))
  }
}

function getMode() {
  ensureDb()
  try {
    const data = JSON.parse(fs.readFileSync(MODE_PATH, "utf8"))
    return data.mode === "text" ? "text" : "canvas"
  } catch {
    return "canvas"
  }
}

function setMode(mode) {
  ensureDb()
  fs.writeFileSync(MODE_PATH, JSON.stringify({ mode }, null, 2))
}

function saveLastCheck(sender, data) {
  ensureDb()
  let db = {}
  try {
    db = JSON.parse(fs.readFileSync(CACHE_PATH, "utf8"))
  } catch {}
  db[sender] = {
    uid: data.uid,
    region: data.regionCode || data.region || "id",
    nickname: data.nickname || "-",
    updatedAt: Date.now()
  }
  fs.writeFileSync(CACHE_PATH, JSON.stringify(db, null, 2))
}

function getLastCheck(sender) {
  ensureDb()
  try {
    const db = JSON.parse(fs.readFileSync(CACHE_PATH, "utf8"))
    return db[sender] || null
  } catch {
    return null
  }
}

function onlyNumber(text = "") {
  return String(text).replace(/[^\d]/g, "")
}

function clean(value, fallback = "-") {
  if (value === undefined || value === null || value === "") return fallback
  return String(value)
}

function regionLabel(code) {
  const map = {
    id: "Indonesia",
    sg: "Singapore",
    br: "Brazil",
    th: "Thailand",
    vn: "Vietnam",
    me: "Middle East",
    pk: "Pakistan",
    bd: "Bangladesh",
    cis: "CIS",
    us: "United States",
    ru: "Russia",
    tw: "Taiwan",
    ind: "India"
  }
  return map[String(code || "").toLowerCase()] || clean(code)
}

function formatUnix(ts) {
  const num = Number(ts)
  if (!num) return "-"
  const ms = String(num).length === 10 ? num * 1000 : num
  return new Date(ms).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta"
  })
}

async function safeImage(url) {
  try {
    return await loadImage(url || DEFAULT_AVATAR)
  } catch {
    return await loadImage(DEFAULT_AVATAR)
  }
}

function roundedRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + r)
  ctx.lineTo(x + w, y + h - r)
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
  ctx.lineTo(x + r, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - r)
  ctx.lineTo(x, y + r)
  ctx.quadraticCurveTo(x, y, x + r, y)
  ctx.closePath()
}

function wrapText(ctx, text, maxWidth) {
  const words = String(text || "").split(" ")
  const lines = []
  let line = ""

  for (const word of words) {
    const testLine = line ? line + " " + word : word
    const width = ctx.measureText(testLine).width
    if (width > maxWidth && line) {
      lines.push(line)
      line = word
    } else {
      line = testLine
    }
  }

  if (line) lines.push(line)
  return lines
}

function drawNeonBackground(ctx, width, height) {
  const grad = ctx.createLinearGradient(0, 0, width, height)
  grad.addColorStop(0, "#020817")
  grad.addColorStop(0.35, "#06152b")
  grad.addColorStop(0.7, "#03111f")
  grad.addColorStop(1, "#01050d")
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, width, height)

  for (let i = 0; i < 18; i++) {
    const x = Math.random() * width
    const y = Math.random() * height
    const r = 120 + Math.random() * 260
    const glow = ctx.createRadialGradient(x, y, 0, x, y, r)
    glow.addColorStop(0, "rgba(0,180,255,0.18)")
    glow.addColorStop(0.45, "rgba(0,255,255,0.10)")
    glow.addColorStop(1, "rgba(0,0,0,0)")
    ctx.fillStyle = glow
    ctx.beginPath()
    ctx.arc(x, y, r, 0, Math.PI * 2)
    ctx.fill()
  }

  ctx.save()
  ctx.font = "bold 52px Sans"
  ctx.fillStyle = "rgba(0,190,255,0.05)"
  ctx.rotate(-0.32)
  for (let y = -200; y < height + 600; y += 180) {
    for (let x = -300; x < width + 400; x += 360) {
      ctx.fillText("LYU STORE", x, y)
    }
  }
  ctx.restore()
}

function drawBorder(ctx, width, height) {
  ctx.save()
  ctx.shadowColor = "#1da1ff"
  ctx.shadowBlur = 18
  ctx.lineWidth = 3
  ctx.strokeStyle = "rgba(70,180,255,0.88)"
  roundedRect(ctx, 28, 28, width - 56, height - 56, 38)
  ctx.stroke()
  ctx.restore()
}

function card(ctx, x, y, w, h) {
  ctx.save()
  ctx.fillStyle = "rgba(8, 18, 32, 0.82)"
  ctx.strokeStyle = "rgba(80,180,255,0.38)"
  ctx.lineWidth = 2
  roundedRect(ctx, x, y, w, h, 28)
  ctx.fill()
  ctx.stroke()
  ctx.restore()
}

async function buildCanvas(data) {
  const width = 1400
  const height = 1850
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext("2d")

  drawNeonBackground(ctx, width, height)
  drawBorder(ctx, width, height)

  const heroImage = await safeImage(data.banner || data.avatar || DEFAULT_AVATAR)

  ctx.save()
  ctx.shadowColor = "#38b6ff"
  ctx.shadowBlur = 25
  ctx.fillStyle = "#eefaff"
  ctx.font = "bold 64px Sans"
  ctx.fillText("STALK FREE FIRE", 82, 110)
  ctx.restore()

  ctx.fillStyle = "#8fdcff"
  ctx.font = "28px Sans"
  ctx.fillText("Blue Neon Edition • By LYU STORE", 84, 152)

  card(ctx, 70, 190, 1260, 370)

  const bannerX = 95
  const bannerY = 215
  const bannerW = 1210
  const bannerH = 250

  const imgRatio = heroImage.width / heroImage.height
  let drawW = bannerW
  let drawH = drawW / imgRatio

  if (drawH < bannerH) {
    drawH = bannerH
    drawW = drawH * imgRatio
  }

  const drawX = bannerX + (bannerW - drawW) / 2
  const drawY = bannerY + (bannerH - drawH) / 2

  ctx.save()
  roundedRect(ctx, bannerX, bannerY, bannerW, bannerH, 24)
  ctx.clip()
  ctx.drawImage(heroImage, drawX, drawY, drawW, drawH)
  ctx.restore()

  ctx.save()
  const overlay = ctx.createLinearGradient(0, bannerY, 0, bannerY + bannerH)
  overlay.addColorStop(0, "rgba(0,0,0,0.10)")
  overlay.addColorStop(1, "rgba(0,0,0,0.45)")
  ctx.fillStyle = overlay
  roundedRect(ctx, bannerX, bannerY, bannerW, bannerH, 24)
  ctx.fill()
  ctx.restore()

  ctx.fillStyle = "#ffffff"
  ctx.font = "bold 42px Sans"
  const nick = clean(data.nickname)
  const nickWidth = ctx.measureText(nick).width
  ctx.fillText(nick, 110, 505)

  ctx.fillStyle = "#9ce7ff"
  ctx.font = "29px Sans"

  const info1 = `UID: ${clean(data.uid)}`
  const info2 = `Region: ${clean(data.region)}`
  const info3 = `Level: ${clean(data.level)}`
  const info4 = `Likes: ${clean(data.likes)}`

  let startX = 110 + nickWidth + 40
  if (startX < 430) startX = 430

  ctx.fillText(info1, startX, 500)
  ctx.fillText(info2, 760, 500)
  ctx.fillText(info3, startX, 540)
  ctx.fillText(info4, 760, 540)

  card(ctx, 70, 590, 1260, 150)
  ctx.fillStyle = "#7fd9ff"
  ctx.font = "bold 30px Sans"
  ctx.fillText("PROFILE INFO", 100, 640)

  ctx.fillStyle = "#f3fbff"
  ctx.font = "26px Sans"
  const bioLines = wrapText(ctx, clean(data.bio), 1140)
  let by = 683
  for (const line of bioLines.slice(0, 2)) {
    ctx.fillText(line, 100, by)
    by += 34
  }

  card(ctx, 70, 775, 610, 300)
  ctx.fillStyle = "#7fd9ff"
  ctx.font = "bold 30px Sans"
  ctx.fillText("ACCOUNT INFO", 100, 825)

  ctx.fillStyle = "#f6fcff"
  ctx.font = "28px Sans"
  const leftInfo = [
    `Akun Dibuat : ${clean(data.createdAt)}`,
    `Terakhir Aktif : ${clean(data.lastActive)}`,
    `Status : ${clean(data.accountStatus)}`,
    `BP Badges : ${clean(data.bpBadges)}`,
    `Diamond Cost : ${clean(data.diamondCost)}`
  ]
  let ly = 880
  for (const item of leftInfo) {
    ctx.fillText(item, 100, ly)
    ly += 46
  }

  card(ctx, 720, 775, 610, 300)
  ctx.fillStyle = "#7fd9ff"
  ctx.font = "bold 30px Sans"
  ctx.fillText("RANK INFO", 750, 825)

  ctx.fillStyle = "#f6fcff"
  ctx.font = "28px Sans"
  const rankInfo = [
    `BR Max Rank : ${clean(data.brRank)}`,
    `BR Points : ${clean(data.brPoints)}`,
    `CS Max Rank : ${clean(data.csRank)}`,
    `CS Points : ${clean(data.csPoints)}`
  ]
  let ry = 880
  for (const item of rankInfo) {
    ctx.fillText(item, 750, ry)
    ry += 52
  }

  card(ctx, 70, 1110, 1260, 280)
  ctx.fillStyle = "#7fd9ff"
  ctx.font = "bold 30px Sans"
  ctx.fillText("GUILD INFO", 100, 1160)

  ctx.fillStyle = "#f6fcff"
  ctx.font = "28px Sans"
  const guildInfo = [
    `Guild : ${clean(data.guildName)}`,
    `Guild ID : ${clean(data.guildId)}`,
    `Guild Level : ${clean(data.guildLevel)}`,
    `Captain : ${clean(data.guildCaptain)}`
  ]
  let gy = 1215
  for (const item of guildInfo) {
    ctx.fillText(item, 100, gy)
    gy += 52
  }

  card(ctx, 70, 1425, 1260, 170)
  ctx.fillStyle = "#7fd9ff"
  ctx.font = "bold 30px Sans"
  ctx.fillText("EXTRA INFO", 100, 1475)

  ctx.fillStyle = "#f6fcff"
  ctx.font = "28px Sans"
  ctx.fillText(`Pet Name : ${clean(data.petName)}`, 100, 1530)
  ctx.fillText(`Pet Level : ${clean(data.petLevel)}`, 700, 1530)

  card(ctx, 70, 1630, 1260, 150)
  ctx.fillStyle = "#eefaff"
  ctx.font = "bold 34px Sans"
  ctx.fillText("LYU STORE • DIGITAL STYLE", 100, 1690)

  ctx.fillStyle = "#9edfff"
  ctx.font = "26px Sans"
  ctx.fillText(`Source : ${clean(data.sourceUsed.join(", "), "-")}`, 100, 1735)

  ctx.save()
  ctx.shadowColor = "#38b6ff"
  ctx.shadowBlur = 8
  ctx.fillStyle = "#d9f5ff"
  ctx.font = "24px Sans"
  const credit = "LYU STORE"
  const cw = ctx.measureText(credit).width
  ctx.fillText(credit, width - cw - 90, 1735)
  ctx.restore()

  return canvas.toBuffer("image/png")
}

function buildTextCaption(data) {
  return [
    "🔥 *STALK FREE FIRE*",
    "",
    "🎮 *ACCOUNT INFO*",
    `🆔 *UID:* ${clean(data.uid)}`,
    `👤 *Nickname:* ${clean(data.nickname)}`,
    `🌍 *Region:* ${clean(data.region)}`,
    `⭐ *Level:* ${clean(data.level)}`,
    `❤️ *Likes:* ${clean(data.likes)}`,
    `📝 *Bio:* ${clean(data.bio)}`,
    `📅 *Akun Dibuat:* ${clean(data.createdAt)}`,
    `⏰ *Terakhir Aktif:* ${clean(data.lastActive)}`,
    `🚦 *Status:* ${clean(data.accountStatus)}`,
    "",
    "🏆 *RANK INFO*",
    `🥇 *BR Max Rank:* ${clean(data.brRank)}`,
    `🎯 *BR Points:* ${clean(data.brPoints)}`,
    `⚔️ *CS Max Rank:* ${clean(data.csRank)}`,
    `🎖️ *CS Points:* ${clean(data.csPoints)}`,
    "",
    "👥 *GUILD INFO*",
    `🏷️ *Guild:* ${clean(data.guildName)}`,
    `🆔 *Guild ID:* ${clean(data.guildId)}`,
    `📈 *Guild Level:* ${clean(data.guildLevel)}`,
    `👑 *Captain:* ${clean(data.guildCaptain)}`,
    "",
    "🐾 *EXTRA INFO*",
    `🐶 *Pet Name:* ${clean(data.petName)}`,
    `📊 *Pet Level:* ${clean(data.petLevel)}`,
    `🏅 *BP Badges:* ${clean(data.bpBadges)}`,
    `💎 *Diamond Cost:* ${clean(data.diamondCost)}`,
    "",
    "*BY LYU STORE 🚀*"
  ].join("\n")
}

function buildWishlistCaption(data) {
  const lines = [
    "🎁 *FREE FIRE WISHLIST CHECK*",
    "",
    `🆔 *UID:* ${clean(data.uid)}`,
    `🌍 *Region:* ${clean(data.region)}`,
    `📦 *Total Wishlist:* ${data.items.length}`,
    "",
    "`Geser kartu wishlist di bawah ya 👇`"
  ]
  return lines.join("\n")
}

async function fetchHL(uid, region) {
  const params = new URLSearchParams({
    sectionName: "AllData",
    PlayerUid: String(uid),
    region: String(region || "id"),
    useruid: HL_DEV_UID,
    api: HL_API_KEY
  })

  const url = `https://proapis.hlgamingofficial.com/main/games/freefire/account/api?${params.toString()}`
  const { data } = await axios.get(url, {
    timeout: 25000,
    headers: {
      accept: "application/json",
      "user-agent": "Mozilla/5.0"
    }
  })

  const result = data?.result || {}
  const acc = result?.AccountInfo || {}
  const guild = result?.GuildInfo || {}
  const captain = result?.captainBasicInfo || result?.CaptainBasicInfo || {}

  return {
    uid: uid,
    regionCode: String(region || "id").toLowerCase(),
    nickname: acc.AccountName,
    region: regionLabel(acc.AccountRegion || region),
    level: acc.AccountLevel,
    likes: acc.AccountLikes,
    bio: result?.socialinfo?.AccountSignature || result?.AccountSignature || "Tidak tersedia",
    createdAt: formatUnix(acc.AccountCreateTime),
    lastActive: formatUnix(acc.AccountLastLogin),
    avatar: acc.AccountAvatarImage || DEFAULT_AVATAR,
    banner: acc.AccountBannerImage || result?.AccountProfileInfo?.BannerImage || null,
    guildName: guild.GuildName || guild.Name || "-",
    guildId: guild.GuildID || guild.GuildId || "-",
    guildLevel: guild.GuildLevel || guild.Level || "-",
    guildCaptain: captain.nickname || captain.AccountName || guild.CaptainName || "-",
    brRank: acc.BrMaxRank,
    brPoints: acc.BrRankPoint,
    csRank: acc.CsMaxRank,
    csPoints: acc.CsRankPoint,
    petName: result?.petInfo?.name || result?.PetInfo?.Name || "-",
    petLevel: result?.petInfo?.level || result?.PetInfo?.Level || "-",
    accountStatus: acc.ReleaseVersion || "Active",
    bpBadges: acc.AccountBPBadges || "-",
    diamondCost: acc.DiamondCost || "-",
    sourceUsed: ["Lyu-Dev"]
  }
}

async function fetchWishlistFF(uid, region) {
  const params = new URLSearchParams({
    sectionName: "wishlist",
    useruid: HL_DEV_UID,
    api: HL_API_KEY,
    uid: String(uid),
    region: String(region || "id")
  })

  const url = `https://proapis.hlgamingofficial.com/main/games/freefire/wishlist/api?${params.toString()}`
  const { data } = await axios.get(url, {
    timeout: 25000,
    headers: {
      accept: "application/json",
      "user-agent": "Mozilla/5.0"
    }
  })

  const rawResult = data?.result || data?.data || {}
  const rawItems = rawResult?.wishlist || rawResult?.items || data?.wishlist || data?.items || []

  const items = (Array.isArray(rawItems) ? rawItems : []).map((item, i) => ({
    name:
      item?.name ||
      item?.itemName ||
      item?.title ||
      item?.item_name ||
      item?.bundleName ||
      `Item ${i + 1}`,
    image:
      item?.icon ||
      item?.iconUrl ||
      item?.image ||
      item?.img ||
      item?.banner ||
      item?.photo ||
      item?.imageUrl ||
      null
  }))

  return {
    uid,
    region: regionLabel(region),
    items,
    raw: data
  }
}

async function sendWishlistCarousel(alip, m, data) {
  const validItems = data.items.filter(v => v.image).slice(0, 10)

  if (!validItems.length) {
    return await alip.sendMessage(m.chat, {
      text: buildWishlistCaption(data) + "\n\nTidak ada gambar wishlist yang tersedia."
    }, { quoted: m })
  }

  const cards = []
  for (let i = 0; i < validItems.length; i++) {
    const item = validItems[i]

    const media = await prepareWAMessageMedia(
      { image: { url: item.image } },
      { upload: alip.waUploadToServer }
    )

    cards.push({
      header: { hasMediaAttachment: true, ...media },
      body: {
        text:
          `🎁 *Wishlist ${i + 1}*\n` +
          `🛍️ ${clean(item.name)}\n` +
          `🌍 Region: ${clean(data.region)}`
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Buka Gambar",
              url: item.image,
              merchant_url: item.image
            })
          }
        ]
      }
    })
  }

  const msg = await generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessageV2Extension: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            body: {
              text: buildWishlistCaption(data)
            },
            carouselMessage: {
              cards
            }
          }
        }
      }
    },
    { userJid: m.sender, quoted: m }
  )

  await alip.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

async function sendRegionPicker(alip, m, uid, prefix) {
  const rows = REGION_LIST.map(r => ({
    title: r.name,
    description: `Cek data Free Fire region ${r.name}`,
    id: `${prefix}stalkffcek ${uid}|${r.code}`
  }))

  return alip.sendMessage(m.chat, {
    text:
      `🔥 *STALK FREE FIRE - LYU*\n\n` +
      `🆔 UID: *${uid}*\n` +
      `📍 Pilih region dulu buat lanjut cek data`,
    footer: `Mode sekarang: ${getMode()}`,
    buttons: [
      {
        buttonId: "pilih_region_ff",
        buttonText: { displayText: "🌍 Pilih Region" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Region Free Fire",
            sections: [
              {
                title: "Daftar Region",
                rows
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m })
}

async function sendWishlistRegionPicker(alip, m, uid, prefix) {
  const rows = REGION_LIST.map(r => ({
    title: r.name,
    description: `Cek wishlist Free Fire region ${r.name}`,
    id: `${prefix}cekwishlistff ${uid}|${r.code}`
  }))

  return alip.sendMessage(m.chat, {
    text:
      `🎁 *FREE FIRE WISHLIST CHECK*\n\n` +
      `🆔 UID: *${uid}*\n` +
      `📍 Pilih region dulu buat cek wishlist`,
    footer: "LYU STORE",
    buttons: [
      {
        buttonId: "pilih_region_wishlist_ff",
        buttonText: { displayText: "🎁 Pilih Region Wishlist" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Region Wishlist FF",
            sections: [
              {
                title: "Daftar Region",
                rows
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m })
}

async function sendModePicker(alip, m, prefix) {
  const rows = [
    {
      title: "Canvas Mode",
      description: "Hasil stalkff dalam bentuk canvas neon",
      id: `${prefix}modestalkff canvas`
    },
    {
      title: "Text Mode",
      description: "Hasil stalkff teks biasa + foto/banner",
      id: `${prefix}modestalkff text`
    }
  ]

  return alip.sendMessage(m.chat, {
    text:
      `⚙️ *SET MODE STALKFF*\n\n` +
      `Mode sekarang: *${getMode()}*\n` +
      `Pilih mode yang kamu mau di bawah ini`,
    footer: "LYU STORE",
    buttons: [
      {
        buttonId: "pilih_mode_stalkff",
        buttonText: { displayText: "🎛️ Pilih Mode" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Pilih Mode StalkFF",
            sections: [
              {
                title: "Mode Tersedia",
                rows
              }
            ]
          })
        }
      }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m })
}

let handler = async (m, { alip, text, Reply, command, prefix, isCreator }) => {
  try {
    const cmd = String(command || "").toLowerCase()
    const p = prefix || "."

    if (cmd === "setmodestalkff") {
      if (!isCreator) return Reply(global.mess?.owner || "Khusus owner.")
      return await sendModePicker(alip, m, p)
    }

    if (cmd === "modestalkff") {
      if (!isCreator) return Reply(global.mess?.owner || "Khusus owner.")

      const mode = String(text || "").trim().toLowerCase()
      if (!["canvas", "text"].includes(mode)) {
        return Reply(`Mode tidak valid.\nGunakan:\n${p}modestalkff canvas\n${p}modestalkff text`)
      }

      setMode(mode)
      return Reply(`Berhasil ganti mode stalkff ke *${mode}*`)
    }

    if (cmd === "thankstalkff") {
      return Reply(`*Sama-sama kak ✨*`)
    }

    if (cmd === "cekwishlistff") {
      if (!text) {
        const cache = getLastCheck(m.sender)
        if (!cache) return Reply(`Contoh:\n${p}cekwishlistff 73150653|id`)
        text = `${cache.uid}|${cache.region}`
      }

      if (!text.includes("|")) {
        const uidOnly = onlyNumber(text)
        if (!uidOnly) return Reply(`Contoh:\n${p}cekwishlistff 73150653|id`)
        return await sendWishlistRegionPicker(alip, m, uidOnly, p)
      }

      const [uidRaw, regionRaw] = text.split("|")
      const uid = onlyNumber(uidRaw)
      const region = String(regionRaw || "").trim().toLowerCase()

      if (!uid) return Reply("UID tidak valid.")
      if (!region) return Reply("Region tidak valid.")

      await Reply("⏳ Lagi cek wishlist Free Fire...")

      let wishlist = null
      try {
        wishlist = await fetchWishlistFF(uid, region)
      } catch (e) {
        console.error("wishlist fetch error:", e?.response?.data || e?.message || e)
      }

      if (!wishlist) {
        return Reply("Wishlist tidak ditemukan atau API sedang sibuk..")
      }

      return await sendWishlistCarousel(alip, m, wishlist)
    }

    if (cmd === "stalkff" || cmd === "cekff" || cmd === "ffstalk" || cmd === "stalkfreefire") {
      if (!text) return Reply(`Contoh:\n${p}stalkff 1814767711`)

      const uid = onlyNumber(text)
      if (!uid) return Reply("UID tidak valid.")

      if (!HL_API_KEY || !HL_DEV_UID) {
        return Reply("API HL Gaming belum diisi di dalam plugin.")
      }

      return await sendRegionPicker(alip, m, uid, p)
    }

    if (cmd === "stalkffcek") {
      if (!text || !text.includes("|")) {
        return Reply(`Format salah.\nContoh:\n${p}stalkffcek 1814767711|id`)
      }

      const [uidRaw, regionRaw] = text.split("|")
      const uid = onlyNumber(uidRaw)
      const region = String(regionRaw || "").trim().toLowerCase()

      if (!uid) return Reply("UID tidak valid.")
      if (!region) return Reply("Region tidak valid.")

      await Reply("⏳ Lagi ambil data Free Fire...")

      let result = null
      try {
        result = await fetchHL(uid, region)
      } catch (e) {
        console.error("HL fetch error:", e?.response?.data || e?.message || e)
      }

      if (!result || !result.nickname) {
        return Reply("Data akun tidak ditemukan atau API sedang sibuk..")
      }

      saveLastCheck(m.sender, result)

      const mode = getMode()

      if (mode === "text") {
        const mediaUrl = result.banner || result.avatar || DEFAULT_AVATAR
        return await alip.sendMessage(m.chat, {
          image: { url: mediaUrl },
          caption: buildTextCaption(result),
          footer: "LYU STORE",
          buttons: [
            {
              buttonId: `${p}cekwishlistff ${uid}|${region}`,
              buttonText: { displayText: "Cek Wishlist Free Fire" },
              type: 1
            },
            {
              buttonId: `${p}thankstalkff`,
              buttonText: { displayText: `Thank's Bot ${global.botname || global.namaBot || "LYU AI"}` },
              type: 1
            }
          ],
          headerType: 4
        }, { quoted: m })
      }

      const canvasBuffer = await buildCanvas(result)
      return await alip.sendMessage(m.chat, {
        image: canvasBuffer,
        caption:
          `🔥 *STALK FF BERHASIL*\n` +
          `👤 Nick: *${clean(result.nickname)}*\n` +
          `🆔 UID: *${uid}*\n` +
          `🌍 Region: *${clean(result.region)}*\n` +
          `🎨 Mode: *${mode}*\n\n`
      }, { quoted: m })
    }
  } catch (e) {
    console.error("stalkff neon error:", e)
    return Reply(`Terjadi kesalahan:\n${e.message || e}`)
  }
}

handler.command = [
  "stalkff",
  "cekff",
  "ffstalk",
  "stalkfreefire",
  "stalkffcek",
  "setmodestalkff",
  "modestalkff",
  "cekwishlistff",
  "thankstalkff"
]

module.exports = handler