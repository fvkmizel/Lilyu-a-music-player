// plugins/lyu-autoabsen.js
// AUTOABSEN LYU AI — V4.5 FULL FIXED
// BY LYU STORE
// Jangan hapus credit.
//

const fs = require("fs")
const path = require("path")

// =========================
// CONFIG
// =========================
const DB_PATH = "./library/database/absen.json"
const AUTO_VIDEO = "https://files.catbox.moe/izmqen.mp4"
const PREFIX = "."
const WEBSITE = "https://lyustore.my.id"
const VERSION = "v4.5"

// =========================
// BASIC UTILS
// =========================
function norm(jid = "") {
  return jid ? String(jid).replace(/:.*@/, "@") : jid
}

function isValidJid(jid) {
  return Boolean(jid && typeof jid === "string" && jid.includes("@"))
}

function getSenderJid(m) {
  return norm(
    m?.sender ||
      m?.participant ||
      m?.key?.participant ||
      m?.message?.participant ||
      ""
  )
}

function mentionTag(jid) {
  if (!jid) return "@unknown"
  return "@" + String(jid).split("@")[0]
}

function ensureDBFile() {
  const dir = path.dirname(DB_PATH)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, "{}", "utf8")
}

function loadDB() {
  try {
    ensureDBFile()
    const raw = fs.readFileSync(DB_PATH, "utf8")
    return raw && raw.trim() ? JSON.parse(raw) : {}
  } catch (e) {
    console.error("[AUTOABSEN] Gagal load DB:", e)
    return {}
  }
}

function saveDB(db) {
  ensureDBFile()
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf8")
}

async function safeReply(alip, m, Reply, teks, extra = {}) {
  try {
    if (typeof Reply === "function") return Reply(teks)
    if (alip?.sendMessage) {
      return alip.sendMessage(
        m.chat,
        {
          text: teks,
          ...extra,
        },
        { quoted: m }
      )
    }
    if (typeof m.reply === "function") return m.reply(teks)
  } catch (e) {
    console.error("[AUTOABSEN safeReply]", e)
  }
}

function tanggalID() {
  return new Date().toLocaleDateString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "long",
    year: "numeric",
  })
}

function jamID() {
  return new Date()
    .toLocaleTimeString("id-ID", {
      timeZone: "Asia/Jakarta",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
    .replace(/:/g, ".")
}

// =========================
// DB COMPAT
// =========================
function ensureGroup(db, gid) {
  if (!db[gid]) {
    db[gid] = {
      setting: { auto: false },
      data: {},
    }
  }

  if (!db[gid].setting) db[gid].setting = { auto: false }
  if (typeof db[gid].setting.auto !== "boolean") db[gid].setting.auto = false

  if (typeof db[gid].setting.mode !== "string") db[gid].setting.mode = "text"
  if (!["text", "button"].includes(db[gid].setting.mode)) db[gid].setting.mode = "text"

  if (typeof db[gid].setting.listMode !== "string") db[gid].setting.listMode = "keren"
  if (!LIST_STYLE[db[gid].setting.listMode]) db[gid].setting.listMode = "keren"

  if (!db[gid].data) db[gid].data = {}

  if (!db[gid].roles) {
    db[gid].roles = {
      kapten: [],
      pengurus: [],
    }
  }

  if (!Array.isArray(db[gid].roles.kapten)) db[gid].roles.kapten = []
  if (!Array.isArray(db[gid].roles.pengurus)) db[gid].roles.pengurus = []

  db[gid].roles.kapten = [...new Set(db[gid].roles.kapten.map(norm).filter(isValidJid))]
  db[gid].roles.pengurus = [...new Set(db[gid].roles.pengurus.map(norm).filter(isValidJid))]

  return db[gid]
}

// =========================
// LIST STYLE
// =========================
const LIST_STYLE = {
  keren: {
    name: "Keren",
    top: "╔═══",
    mid: "╠═══",
    side: "║",
    end: "╚═══",
    ketua: "👑 *KETUA/KAPTEN*",
    pengurus: "⚔️ *PENGURUS/ADMIN*",
    member: "👥 *MEMBER*",
  },
  cute: {
    name: "Cute",
    top: "♡━━━━",
    mid: "┣━━━━",
    side: "┃",
    end: "♡━━━━",
    ketua: "🌸 *KETUA/KAPTEN*",
    pengurus: "🎀 *PENGURUS/ADMIN*",
    member: "🍓 *MEMBER*",
  },
  kalem: {
    name: "Kalem",
    top: "┌────",
    mid: "├────",
    side: "│",
    end: "└────",
    ketua: "🌙 *KETUA/KAPTEN*",
    pengurus: "☁️ *PENGURUS/ADMIN*",
    member: "🌿 *MEMBER*",
  },
  guild: {
    name: "Guild",
    top: "╭─〔",
    mid: "├─〔",
    side: "│",
    end: "╰─〔",
    ketua: "🏆 *KETUA/KAPTEN*",
    pengurus: "🎖️ *PENGURUS/ADMIN*",
    member: "⚔️ *MEMBER*",
  },
  neon: {
    name: "Neon",
    top: "▰▰▰",
    mid: "▱▱▱",
    side: "┃",
    end: "▰▰▰",
    ketua: "💠 *KETUA/KAPTEN*",
    pengurus: "🌀 *PENGURUS/ADMIN*",
    member: "🔹 *MEMBER*",
  },
  elegan: {
    name: "Elegan",
    top: "━━━━━━━━",
    mid: "────────",
    side: "┃",
    end: "━━━━━━━━",
    ketua: "👑 *KETUA/KAPTEN*",
    pengurus: "🛡️ *PENGURUS/ADMIN*",
    member: "👤 *MEMBER*",
  },
  simple: {
    name: "Simple",
    top: "====",
    mid: "----",
    side: "|",
    end: "====",
    ketua: "*KETUA/KAPTEN*",
    pengurus: "*PENGURUS/ADMIN*",
    member: "*MEMBER*",
  },
  dark: {
    name: "Dark",
    top: "╭━━━⬣",
    mid: "┣━━━⬣",
    side: "┃",
    end: "╰━━━⬣",
    ketua: "🕶️ *KETUA/KAPTEN*",
    pengurus: "🗡️ *PENGURUS/ADMIN*",
    member: "🖤 *MEMBER*",
  },
  royal: {
    name: "Royal",
    top: "♛━━━━",
    mid: "♜━━━━",
    side: "┃",
    end: "♚━━━━",
    ketua: "👑 *KETUA/KAPTEN*",
    pengurus: "🏰 *PENGURUS/ADMIN*",
    member: "⚜️ *MEMBER*",
  },
  aesthetic: {
    name: "Aesthetic",
    top: "・❥・",
    mid: "・✦・",
    side: "│",
    end: "・❥・",
    ketua: "🦋 *KETUA/KAPTEN*",
    pengurus: "🌷 *PENGURUS/ADMIN*",
    member: "✨ *MEMBER*",
  },
}

function getListStyle(group) {
  return LIST_STYLE[group?.setting?.listMode] || LIST_STYLE.keren
}

function getListModeRows() {
  return Object.entries(LIST_STYLE).map(([key, value]) => ({
    title: value.name,
    description: `Pakai tampilan list mode ${value.name}`,
    id: `${PREFIX}setlistabsen_mode ${key}`,
  }))
}

// =========================
// BUTTON HELPER
// =========================
async function sendSingleSelect(alip, m, { caption, buttonText, title, sectionTitle, rows, mentions = [] }) {
  return alip.sendMessage(
    m.chat,
    {
      text: caption || "",
      footer: "LYU AI",
      buttons: [
        {
          buttonId: "select_menu",
          buttonText: { displayText: buttonText || "Pilih" },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: title || "Pilih",
              sections: [
                {
                  title: sectionTitle || "LIST",
                  rows,
                },
              ],
            }),
          },
        },
      ],
      headerType: 1,
      viewOnce: true,
      mentions,
      contextInfo: {
        mentionedJid: mentions,
      },
    },
    { quoted: m }
  )
}

// =========================
// GROUP / ADMIN HELPER
// =========================
async function getGroupMetadataSafe(alip, chat) {
  try {
    if (!chat || !String(chat).endsWith("@g.us")) return null
    return await alip.groupMetadata(chat)
  } catch {
    return null
  }
}

async function getParticipants(alip, m) {
  if (Array.isArray(m?.metadata?.participants)) return m.metadata.participants
  const meta = await getGroupMetadataSafe(alip, m.chat)
  return meta?.participants || []
}

async function getAdminJids(alip, m) {
  const participants = await getParticipants(alip, m)

  return participants
    .filter(p => p?.admin === "admin" || p?.admin === "superadmin")
    .map(p => norm(p.id || p.jid || p))
    .filter(isValidJid)
}

async function getAllParticipantJids(alip, m) {
  const participants = await getParticipants(alip, m)

  return participants
    .map(p => norm(p.id || p.jid || p))
    .filter(isValidJid)
}

async function getGroupName(alip, m) {
  const meta = await getGroupMetadataSafe(alip, m.chat)
  return meta?.subject || "GRUP INI"
}

// =========================
// DATA / ROLE
// =========================
function listEntries(group) {
  return Object.entries(group.data || {})
    .map(([jid, d]) => ({
      jid: norm(jid),
      d,
    }))
    .filter(v => isValidJid(v.jid))
}

function isKapten(group, jid) {
  jid = norm(jid)
  return (group.roles?.kapten || []).map(norm).includes(jid)
}

function isPengurus(group, jid, adminJids = []) {
  jid = norm(jid)
  return (
    (group.roles?.pengurus || []).map(norm).includes(jid) ||
    adminJids.map(norm).includes(jid)
  )
}

function addRole(group, role, jid) {
  jid = norm(jid)

  if (!group.roles) group.roles = { kapten: [], pengurus: [] }
  if (!Array.isArray(group.roles.kapten)) group.roles.kapten = []
  if (!Array.isArray(group.roles.pengurus)) group.roles.pengurus = []

  if (role === "kapten") {
    group.roles.kapten = group.roles.kapten.filter(v => norm(v) !== jid)
    group.roles.kapten.push(jid)
    group.roles.pengurus = group.roles.pengurus.filter(v => norm(v) !== jid)
  }

  if (role === "pengurus") {
    if (!group.roles.pengurus.map(norm).includes(jid)) group.roles.pengurus.push(jid)
    group.roles.kapten = group.roles.kapten.filter(v => norm(v) !== jid)
  }
}

function removeRole(group, jid) {
  jid = norm(jid)
  if (!group.roles) return
  group.roles.kapten = (group.roles.kapten || []).filter(v => norm(v) !== jid)
  group.roles.pengurus = (group.roles.pengurus || []).filter(v => norm(v) !== jid)
}

function roleText(group, jid, adminJids = []) {
  if (isKapten(group, jid)) return "KETUA/KAPTEN"
  if (isPengurus(group, jid, adminJids)) return "PENGURUS/ADMIN"
  return "MEMBER"
}

function splitEntriesByRole(group, entries, adminJids = []) {
  const kapten = []
  const pengurus = []
  const member = []

  for (const item of entries) {
    if (isKapten(group, item.jid)) kapten.push(item)
    else if (isPengurus(group, item.jid, adminJids)) pengurus.push(item)
    else member.push(item)
  }

  return { kapten, pengurus, member }
}

function orderedEntries(group, entries, adminJids = []) {
  const { kapten, pengurus, member } = splitEntriesByRole(group, entries, adminJids)
  return [...kapten, ...pengurus, ...member]
}

function parseAbsenFields(text = "") {
  const [nama, nick, umur, alamat, gender] = String(text || "")
    .trim()
    .split("|")
    .map(v => String(v || "").trim())

  return { nama, nick, umur, alamat, gender }
}

function validFields(f) {
  return f.nama && f.nick && f.umur && f.alamat && f.gender
}

function saveAbsenData(group, jid, f) {
  group.data[norm(jid)] = {
    nama: f.nama,
    nick: f.nick,
    umur: f.umur,
    alamat: f.alamat,
    gender: f.gender,
  }
}

// =========================
// TARGET RESOLVER
// =========================
function getMentionedJids(m) {
  return (
    m?.mentionedJid ||
    m?.msg?.contextInfo?.mentionedJid ||
    m?.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    []
  ).map(norm).filter(Boolean)
}

async function resolveTarget(alip, m, group, entries, adminJids, input = "") {
  const raw = String(input || "").trim()
  const ordered = orderedEntries(group, entries, adminJids)

  if (/^\d+$/.test(raw)) {
    const no = parseInt(raw, 10)
    return ordered[no - 1]?.jid || null
  }

  const mentioned = getMentionedJids(m)
  if (mentioned.length) {
    const target = norm(mentioned[0])
    if (group.data[target]) return target

    const num = target.split("@")[0].replace(/\D/g, "")
    const found = Object.keys(group.data || {}).find(j => j.split("@")[0].replace(/\D/g, "") === num)
    if (found) return norm(found)

    return target
  }

  if (raw.includes("@")) {
    const target = norm(raw)
    if (group.data[target]) return target
  }

  const num = raw.replace(/\D/g, "")
  if (num) {
    const found = Object.keys(group.data || {}).find(j => j.split("@")[0].replace(/\D/g, "") === num)
    if (found) return norm(found)
    return `${num}@s.whatsapp.net`
  }

  return null
}

// =========================
// TEXT BUILDER
// =========================
function buildAbsenTemplate(command = "absen") {
  const template = `${PREFIX}${command} Nama|Nick|Umur|Alamat|Gender`
  const contoh = `${PREFIX}${command} Tabayyuna|Lyu FS✨|20|Banda Aceh|Perempuan`

  return (
    `📌 *FORMAT ABSEN DI BAWAH INI TINGGAL COPY & ISI DENGAN BENAR!*\n\n` +
    `⚠️ *JANGAN PAKE SPASI DI AWAL/AKHIR, PAKE TANDA "|" SESUAI TEMPLATE*\n\n` +
    `📋 *TEMPLATE:*\n` +
    "```\n" +
    `${template}\n` +
    "```\n\n" +
    `✅ *CONTOH:*\n` +
    "```\n" +
    `${contoh}\n` +
    "```"
  )
}

function editHelp() {
  return (
    `✏️ *FORMAT EDIT ABSEN*\n\n` +
    `Pakai:\n` +
    `• *${PREFIX}editabsen @tag nama|nama baru*\n` +
    `• *${PREFIX}editabsen @tag nick|nick baru*\n` +
    `• *${PREFIX}editabsen @tag umur|umur baru*\n` +
    `• *${PREFIX}editabsen @tag alamat|alamat baru*\n` +
    `• *${PREFIX}editabsen @tag gender|gender baru*\n\n` +
    `Bisa juga pakai nomor urutan dari *${PREFIX}listabsen*:\n` +
    `• *${PREFIX}editabsen 1 nama|nama baru*\n` +
    `• *${PREFIX}editabsen 3 umur|18*\n\n` +
    `⚠️ Edit data *tidak akan mengubah role*.\n` +
    `Kalau dia member, tetap member. Kalau ketua/pengurus, tetap sesuai role.`
  )
}

function hapusHelp() {
  return (
    `🗑️ *FORMAT HAPUS ABSEN*\n\n` +
    `• *${PREFIX}hapusabsen @tag*\n` +
    `• *${PREFIX}hapusabsen 1*\n\n` +
    `Nomor ambil dari *${PREFIX}listabsen*.`
  )
}

function formatPerson(style, item, no) {
  const s = style.side
  const d = item.d || {}

  return (
    `${s} *${no}.* ${mentionTag(item.jid)}\n` +
    `${s}    👤 Nama   : *${d.nama || "-"}*\n` +
    `${s}    📛 Nick   : *${d.nick || "-"}*\n` +
    `${s}    🎂 Umur   : *${d.umur || "-"}*\n` +
    `${s}    📍 Alamat : *${d.alamat || "-"}*\n` +
    `${s}    🚻 Gender : *${d.gender || "-"}*`
  )
}

function formatSection(style, title, items, startNo, emptyHelp = "") {
  const s = style.side

  if (!items.length) {
    return (
      `${title}\n` +
      `${s}\n` +
      `${s} _kosong_` +
      `${emptyHelp ? `\n${s} Cara isi: *${emptyHelp}*` : ""}`
    )
  }

  return (
    `${title}\n` +
    `${s}\n` +
    items.map((item, i) => formatPerson(style, item, startNo + i)).join("\n")
  )
}

async function buildListText(alip, m, group, entries, adminJids) {
  const groupName = await getGroupName(alip, m)
  const totalMember = (await getAllParticipantJids(alip, m)).length || "-"
  const style = getListStyle(group)
  const { kapten, pengurus, member } = splitEntriesByRole(group, entries, adminJids)

  let no = 1
  const ketuaText = formatSection(style, style.ketua, kapten, no, `${PREFIX}absenketua Nama|Nick|Umur|Alamat|Gender`)
  no += kapten.length

  const pengurusText = formatSection(style, style.pengurus, pengurus, no, `${PREFIX}absenpengurus Nama|Nick|Umur|Alamat|Gender`)
  no += pengurus.length

  const memberText = formatSection(style, style.member, member, no)

  return (
    `${style.top} *DAFTAR ABSEN ${String(groupName).toUpperCase()}* ${style.top}\n` +
    `${style.side}\n` +
    `${style.side} 📅 Tanggal          : *${tanggalID()}*\n` +
    `${style.side} ⏰ Jam              : *${jamID()}*\n` +
    `${style.side} 📌 Mode Tampilan   : *${style.name}*\n` +
    `${style.side} 🧾 Total All Absen : *${entries.length}*\n` +
    `${style.side} 👥 Total Member GC : *${totalMember}*\n` +
    `${style.mid}\n` +
    `${ketuaText}\n` +
    `${style.mid}\n` +
    `${pengurusText}\n` +
    `${style.mid}\n` +
    `${memberText}\n` +
    `${style.end}\n` +
    `© *LYU STORE* • AutoAbsen ${VERSION}`
  )
}

async function sendDetail(alip, m, group, entries, adminJids, jid, withActions = false) {
  jid = norm(jid)
  const d = group.data[jid]
  if (!d) return alip.sendMessage(m.chat, { text: "❌ Data tidak ditemukan." }, { quoted: m })

  const ordered = orderedEntries(group, entries, adminJids)
  const idx = ordered.findIndex(v => v.jid === jid) + 1
  const role = roleText(group, jid, adminJids)

  const teks =
    `🧾 *DETAIL ABSEN*\n` +
    `━━━━━━━━━━━━\n` +
    `🆔 No     : *${idx || "-"}*\n` +
    `🏷️ Role   : *${role}*\n` +
    `👤 Nama   : *${d.nama || "-"}*\n` +
    `📛 Nick   : *${d.nick || "-"}*\n` +
    `🎂 Umur   : *${d.umur || "-"}*\n` +
    `📍 Alamat : *${d.alamat || "-"}*\n` +
    `🚻 Gender : *${d.gender || "-"}*\n` +
    `👤 User   : ${mentionTag(jid)}`

  if (!withActions || group.setting.mode === "text") {
    return alip.sendMessage(
      m.chat,
      {
        text: teks,
        mentions: [jid],
        contextInfo: { mentionedJid: [jid] },
      },
      { quoted: m }
    )
  }

  const rows = [
    {
      title: "📋 Copy Detail",
      description: "Kirim teks copy data lengkap",
      id: `${PREFIX}absen_manage copy|${jid}`,
    },
    {
      title: "✏️ Edit Data",
      description: "Lihat format edit data",
      id: `${PREFIX}absen_manage edit|${jid}`,
    },
    {
      title: "🗑️ Hapus Data",
      description: "Hapus data absen ini",
      id: `${PREFIX}absen_manage delete|${jid}`,
    },
  ]

  return sendSingleSelect(alip, m, {
    caption: `${teks}\n\nPilih aksi di bawah.`,
    buttonText: "⚙️ Aksi",
    title: "Aksi Absen",
    sectionTitle: "Pilih Aksi",
    rows,
    mentions: [jid],
  })
}

// =========================
// MAIN HANDLER
// =========================
let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  if (!m.isGroup) return Reply("❌ Fitur ini cuma bisa dipakai di grup.")

  const cmd = String(command || "").toLowerCase()
  const db = loadDB()
  const group = ensureGroup(db, m.chat)
  const me = getSenderJid(m)
  const entries = listEntries(group)
  const adminJids = await getAdminJids(alip, m)
  const adminOK = Boolean(isCreator || m.isAdmin || adminJids.includes(me))

  console.log(`[AUTOABSEN ${VERSION}] CMD: ${cmd} | adminOK: ${adminOK} | mode: ${group.setting.mode} | listMode: ${group.setting.listMode} | auto: ${group.setting.auto}`)

  try {
    switch (cmd) {
      case "setautoabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const opt = String(text || "").trim().toLowerCase()

        if (opt === "text" || opt === "button") {
          group.setting.mode = opt
          saveDB(db)

          return Reply(
            `✅ Mode AutoAbsen: *${opt.toUpperCase()}*\n\n` +
              `TEXT: support semua device\n` +
              `BUTTON: tampilan menu tombol/list button`
          )
        }

        return alip.sendMessage(
          m.chat,
          {
            video: { url: AUTO_VIDEO },
            gifPlayback: true,
            caption:
              `⚙️ *SET MODE AUTOABSEN*\n\n` +
              `Mode sekarang: *${String(group.setting.mode || "text").toUpperCase()}*\n\n` +
              `Ketik:\n` +
              `• *${PREFIX}setautoabsen text*\n` +
              `• *${PREFIX}setautoabsen button*`,
          },
          { quoted: m }
        )
      }

      case "setlistabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        return sendSingleSelect(alip, m, {
          caption:
            `🎨 *SET TAMPILAN LIST ABSEN*\n\n` +
            `Mode sekarang: *${getListStyle(group).name}*\n\n` +
            `Pilih style tampilan list absen.`,
          buttonText: "🎨 Pilih Style",
          title: "Style List Absen",
          sectionTitle: "MODE TAMPILAN",
          rows: getListModeRows(),
        })
      }

      case "setlistabsen_mode": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const mode = String(text || "").trim().toLowerCase()
        if (!LIST_STYLE[mode]) return Reply("❌ Mode tampilan tidak valid.")

        group.setting.listMode = mode
        saveDB(db)

        return Reply(`✅ Tampilan list absen diganti ke mode *${LIST_STYLE[mode].name}*.`)
      }

      case "panduanautoabsen": {
        const status = group.setting.auto ? "ON ✅" : "OFF ⛔"

        return alip.sendMessage(
          m.chat,
          {
            video: { url: AUTO_VIDEO },
            gifPlayback: true,
            caption:
              `📌 *PANDUAN AUTOABSEN — LYU STORE*\n` +
              `━━━━━━━━━━━━\n` +
              `Status: *${status}*\n` +
              `Mode: *${String(group.setting.mode).toUpperCase()}*\n` +
              `Tampilan: *${getListStyle(group).name}*\n\n` +
              `✅ Aktif/nonaktif:\n` +
              `• *${PREFIX}autoabsen on*\n` +
              `• *${PREFIX}autoabsen off*\n\n` +
              `🧑‍✈️ Ketua/Kapten:\n` +
              `• *${PREFIX}absenketua Nama|Nick|Umur|Alamat|Gender*\n\n` +
              `👮 Pengurus/Admin:\n` +
              `• *${PREFIX}absenpengurus Nama|Nick|Umur|Alamat|Gender*\n\n` +
              `👥 Member:\n` +
              `• *${PREFIX}absen Nama|Nick|Umur|Alamat|Gender*\n\n` +
              `📋 Data:\n` +
              `• *${PREFIX}listabsen*\n` +
              `• *${PREFIX}myabsen*\n` +
              `• *${PREFIX}cekabsen @tag / nomor*\n` +
              `• *${PREFIX}noabsen*\n\n` +
              `🛠️ Admin tools:\n` +
              `• *${PREFIX}editabsen @tag nama|nama baru*\n` +
              `• *${PREFIX}editabsen 1 umur|18*\n` +
              `• *${PREFIX}hapusabsen @tag / nomor*\n` +
              `• *${PREFIX}clearabsen konfirmasi*\n\n` +
              `🎨 Tampilan:\n` +
              `• *${PREFIX}setlistabsen*\n\n` +
              `© LYU STORE • ${WEBSITE}`,
          },
          { quoted: m }
        )
      }

      case "autoabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const opt = String(text || "").trim().toLowerCase()

        if (opt === "on" || opt === "off") {
          group.setting.auto = opt === "on"
          saveDB(db)
          return Reply(`✅ Autoabsen *${group.setting.auto ? "ON" : "OFF"}* untuk grup ini.`)
        }

        const status = group.setting.auto ? "ON ✅" : "OFF ⛔"

        if (group.setting.mode === "button") {
          return sendSingleSelect(alip, m, {
            caption:
              `⚙️ *AUTOABSEN BUTTON MODE*\n\n` +
              `Status: *${status}*\n\n` +
              `Pilih ON/OFF di bawah.`,
            buttonText: "⚙️ Pilih",
            title: "AutoAbsen",
            sectionTitle: "MODE",
            rows: [
              {
                title: "✅ ON",
                description: "Aktifkan autoabsen",
                id: `${PREFIX}autoabsen on`,
              },
              {
                title: "⛔ OFF",
                description: "Matikan autoabsen",
                id: `${PREFIX}autoabsen off`,
              },
            ],
          })
        }

        return alip.sendMessage(
          m.chat,
          {
            video: { url: AUTO_VIDEO },
            gifPlayback: true,
            caption:
              `⚙️ *AUTOABSEN TEXT MODE*\n\n` +
              `Status: *${status}*\n\n` +
              `Ketik:\n` +
              `• *${PREFIX}autoabsen on*\n` +
              `• *${PREFIX}autoabsen off*\n\n` +
              `Panduan: *${PREFIX}panduanautoabsen*`,
          },
          { quoted: m }
        )
      }

      case "absenketua":
      case "absenkapten": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
        if (!group.setting.auto) return Reply(`❌ Autoabsen belum aktif. Aktifkan: *${PREFIX}autoabsen on*`)

        if (!text) return Reply(buildAbsenTemplate(cmd))

        const f = parseAbsenFields(text)
        if (!validFields(f)) return Reply(`❌ *FORMAT SALAH!*\n\n${buildAbsenTemplate(cmd)}`)

        saveAbsenData(group, me, f)
        addRole(group, "kapten", me)
        saveDB(db)

        return Reply(
          `✅ *ABSEN KETUA/KAPTEN BERHASIL!*\n` +
            `━━━━━━━━━━━━\n` +
            `👤 Nama   : *${f.nama}*\n` +
            `📛 Nick   : *${f.nick}*\n` +
            `🎂 Umur   : *${f.umur}*\n` +
            `📍 Alamat : *${f.alamat}*\n` +
            `🚻 Gender : *${f.gender}*`
        )
      }

      case "absenpengurus": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
        if (!group.setting.auto) return Reply(`❌ Autoabsen belum aktif. Aktifkan: *${PREFIX}autoabsen on*`)

        if (!text) return Reply(buildAbsenTemplate("absenpengurus"))

        const f = parseAbsenFields(text)
        if (!validFields(f)) return Reply(`❌ *FORMAT SALAH!*\n\n${buildAbsenTemplate("absenpengurus")}`)

        saveAbsenData(group, me, f)
        addRole(group, "pengurus", me)
        saveDB(db)

        return Reply(
          `✅ *ABSEN PENGURUS/ADMIN BERHASIL!*\n` +
            `━━━━━━━━━━━━\n` +
            `👤 Nama   : *${f.nama}*\n` +
            `📛 Nick   : *${f.nick}*\n` +
            `🎂 Umur   : *${f.umur}*\n` +
            `📍 Alamat : *${f.alamat}*\n` +
            `🚻 Gender : *${f.gender}*`
        )
      }

      case "absen": {
        if (!group.setting.auto) {
          return Reply(`❌ Autoabsen belum aktif.\nMinta admin aktifkan: *${PREFIX}autoabsen on*`)
        }

        if (adminOK) {
          return Reply(
            `❌ Kamu admin grup, jangan absen jadi member.\n\n` +
              `Kalau ketua/kapten pakai:\n` +
              `*${PREFIX}absenketua Nama|Nick|Umur|Alamat|Gender*\n\n` +
              `Kalau pengurus/admin pakai:\n` +
              `*${PREFIX}absenpengurus Nama|Nick|Umur|Alamat|Gender*`
          )
        }

        if (!text) return Reply(buildAbsenTemplate("absen"))

        if (group.data[me]) {
          return Reply(`⚠️ Kamu sudah pernah absen.\nMinta admin hapus dulu kalau mau isi ulang.`)
        }

        const f = parseAbsenFields(text)
        if (!validFields(f)) return Reply(`❌ *FORMAT SALAH!*\n\n${buildAbsenTemplate("absen")}`)

        saveAbsenData(group, me, f)
        removeRole(group, me)
        saveDB(db)

        return Reply(
          `✅ *ABSEN MEMBER BERHASIL!*\n` +
            `━━━━━━━━━━━━\n` +
            `👤 Nama   : *${f.nama}*\n` +
            `📛 Nick   : *${f.nick}*\n` +
            `🎂 Umur   : *${f.umur}*\n` +
            `📍 Alamat : *${f.alamat}*\n` +
            `🚻 Gender : *${f.gender}*`
        )
      }

      case "myabsen": {
        const d = group.data[me]
        if (!d) return Reply("❌ Kamu belum mengisi absen.")

        return Reply(
          `📌 *DATA KAMU*\n` +
            `━━━━━━━━━━━━\n` +
            `🏷️ Role   : *${roleText(group, me, adminJids)}*\n` +
            `👤 Nama   : *${d.nama || "-"}*\n` +
            `📛 Nick   : *${d.nick || "-"}*\n` +
            `🎂 Umur   : *${d.umur || "-"}*\n` +
            `📍 Alamat : *${d.alamat || "-"}*\n` +
            `🚻 Gender : *${d.gender || "-"}*`
        )
      }

      case "listabsen": {
        const freshEntries = listEntries(group)

        if (group.setting.mode === "button") {
          if (!freshEntries.length) return Reply("📭 Belum ada data absen.")

          const ordered = orderedEntries(group, freshEntries, adminJids)
          const rows = ordered.map((item, i) => ({
            title: `${i + 1}. ${item.d?.nama || "Tanpa Nama"}`,
            description: `${roleText(group, item.jid, adminJids)} • ${item.jid.split("@")[0]}`,
            id: `${PREFIX}absen_detail ${item.jid}`,
          }))

          return sendSingleSelect(alip, m, {
            caption:
              `📋 *DAFTAR ABSEN BUTTON MODE*\n\n` +
              `📅 Tanggal: *${tanggalID()}*\n` +
              `⏰ Jam: *${jamID()}*\n` +
              `🧾 Total Absen: *${freshEntries.length}*\n\n` +
              `Pilih member di bawah untuk lihat detail.`,
            buttonText: "📋 Pilih Member",
            title: "Daftar Absen",
            sectionTitle: "LIST MEMBER",
            rows,
            mentions: ordered.map(v => v.jid),
          })
        }

        const listText = await buildListText(alip, m, group, freshEntries, adminJids)
        const mentions = freshEntries.map(v => v.jid)

        return alip.sendMessage(
          m.chat,
          {
            text: listText,
            mentions,
            contextInfo: { mentionedJid: mentions },
          },
          { quoted: m }
        )
      }

      case "absen_detail": {
        const jid = norm(String(text || "").trim())
        return sendDetail(alip, m, group, entries, adminJids, jid, false)
      }

      case "cekabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
        if (!entries.length) return Reply("📭 Belum ada data absen.")

        if (text || getMentionedJids(m).length) {
          const target = await resolveTarget(alip, m, group, entries, adminJids, text)
          if (!target || !group.data[target]) {
            return Reply(
              `❌ Data tidak ditemukan.\n\n` +
                `Coba pakai nomor urutan dari *.listabsen*:\n` +
                `*${PREFIX}cekabsen 1*`
            )
          }

          return sendDetail(alip, m, group, entries, adminJids, target, true)
        }

        if (group.setting.mode === "button") {
          const ordered = orderedEntries(group, entries, adminJids)
          const rows = ordered.map((item, i) => ({
            title: `${i + 1}. ${item.d?.nama || "Tanpa Nama"}`,
            description: `${roleText(group, item.jid, adminJids)} • ${item.jid.split("@")[0]}`,
            id: `${PREFIX}cekabsen ${i + 1}`,
          }))

          return sendSingleSelect(alip, m, {
            caption: `🔎 *CEK ABSEN MEMBER*\n\nPilih member untuk lihat detail.`,
            buttonText: "🔎 Pilih",
            title: "Cek Absen",
            sectionTitle: "LIST MEMBER",
            rows,
          })
        }

        return Reply(
          `Format:\n` +
            `• *${PREFIX}cekabsen @tag*\n` +
            `• *${PREFIX}cekabsen 1*\n` +
            `• *${PREFIX}cekabsen 62xxxxxxxxxxx*`
        )
      }

      case "absen_manage": {
        const raw = String(text || "").trim()
        const [action, jidRaw] = raw.split("|")
        const actionLow = String(action || "").toLowerCase().trim()
        const jid = norm(String(jidRaw || "").trim())

        if (!isValidJid(jid) || !group.data[jid]) return Reply("❌ Data tidak ditemukan.")

        const d = group.data[jid]

        if (actionLow === "copy") {
          return Reply(
            `📋 *COPY DETAIL ABSEN*\n` +
              `━━━━━━━━━━━━\n` +
              `👤 User: ${mentionTag(jid)}\n\n` +
              "```\n" +
              `${PREFIX}absen ${d.nama}|${d.nick}|${d.umur}|${d.alamat}|${d.gender}\n` +
              "```"
          )
        }

        if (actionLow === "edit") {
          if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
          return Reply(editHelp())
        }

        if (actionLow === "delete") {
          if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
          delete group.data[jid]
          removeRole(group, jid)
          saveDB(db)
          return Reply(`✅ Data absen ${mentionTag(jid)} berhasil dihapus.`)
        }

        return sendDetail(alip, m, group, entries, adminJids, jid, true)
      }

      case "editabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
        if (!text) return Reply(editHelp())

        const parts = String(text).trim().split(/\s+/)
        const first = parts.shift()
        const rest = parts.join(" ")

        const who = await resolveTarget(alip, m, group, entries, adminJids, first)
        if (!who || !group.data[who]) {
          return Reply(
            `❌ Data tidak ditemukan.\n\n` +
              `Paling aman edit pakai nomor urutan dari *.listabsen*:\n` +
              `*${PREFIX}editabsen 1 nama|nama baru*`
          )
        }

        const [fieldRaw, valueRaw] = String(rest || "").split("|")
        const field = String(fieldRaw || "").trim().toLowerCase()
        const value = String(valueRaw || "").trim()

        if (!field || !value) return Reply(editHelp())

        if (!["nama", "nick", "umur", "alamat", "gender"].includes(field)) {
          return Reply(
            `❌ Bagian yang bisa diedit cuma:\n` +
              `• nama\n• nick\n• umur\n• alamat\n• gender\n\n` +
              `Contoh:\n` +
              `*${PREFIX}editabsen 1 nama|LYU STORE*`
          )
        }

        group.data[who][field] = value
        saveDB(db)

        return alip.sendMessage(
          m.chat,
          {
            text:
              `✅ *DATA BERHASIL DIEDIT!*\n` +
              `━━━━━━━━━━━━\n` +
              `👤 User   : ${mentionTag(who)}\n` +
              `🏷️ Role   : *${roleText(group, who, adminJids)}*\n` +
              `✏️ Bagian : *${field}*\n` +
              `📌 Jadi   : *${value}*\n\n` +
              `⚠️ Role dan urutan list tidak berubah.`,
            mentions: [who],
            contextInfo: { mentionedJid: [who] },
          },
          { quoted: m }
        )
      }

      case "hapusabsen":
      case "hapusbsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")
        if (!entries.length) return Reply("📭 Belum ada data absen.")

        if (text || getMentionedJids(m).length) {
          const target = await resolveTarget(alip, m, group, entries, adminJids, text)

          if (!target || !group.data[target]) {
            return Reply(
              `❌ Data tidak ditemukan.\n\n` +
                `Pakai nomor urutan dari *.listabsen*:\n` +
                `*${PREFIX}hapusabsen 1*`
            )
          }

          delete group.data[target]
          removeRole(group, target)
          saveDB(db)

          return Reply(`✅ Data absen ${mentionTag(target)} berhasil dihapus.\nNomor list otomatis dirapikan.`)
        }

        if (group.setting.mode === "button") {
          const ordered = orderedEntries(group, entries, adminJids)

          const rows = ordered.map((item, i) => ({
            title: `${i + 1}. ${item.d?.nama || "Tanpa Nama"}`,
            description: `${roleText(group, item.jid, adminJids)} • hapus data`,
            id: `${PREFIX}hapusabsen_id ${item.jid}`,
          }))

          return sendSingleSelect(alip, m, {
            caption: `🗑️ *HAPUS ABSEN*\n\nPilih member yang mau dihapus.`,
            buttonText: "🗑️ Pilih",
            title: "Hapus Absen",
            sectionTitle: "LIST MEMBER",
            rows,
          })
        }

        return Reply(hapusHelp())
      }

      case "hapusabsen_id": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const jid = norm(String(text || "").trim())
        if (!isValidJid(jid) || !group.data[jid]) return Reply("❌ Data tidak ditemukan.")

        delete group.data[jid]
        removeRole(group, jid)
        saveDB(db)

        return Reply(`✅ Data absen ${mentionTag(jid)} berhasil dihapus.`)
      }

      case "noabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const all = await getAllParticipantJids(alip, m)
        const absenList = Object.keys(group.data || {}).map(norm)
        const noAbsen = all.filter(jid => !absenList.includes(jid))

        if (!noAbsen.length) return Reply("🎉 Semua member sudah absen!")

        return alip.sendMessage(
          m.chat,
          {
            text:
              `📋 *MEMBER BELUM ABSEN*\n` +
              `━━━━━━━━━━━━\n` +
              noAbsen.map(j => `• ${mentionTag(j)}`).join("\n"),
            mentions: noAbsen,
            contextInfo: { mentionedJid: noAbsen },
          },
          { quoted: m }
        )
      }

      case "clearabsen": {
        if (!adminOK) return Reply("❌ Khusus admin/owner grup.")

        const raw = String(text || "").trim().toLowerCase()

        if (!["ya", "yes", "konfirmasi", "confirm"].includes(raw)) {
          return Reply(
            `⚠️ *KONFIRMASI HAPUS SEMUA DATA ABSEN GRUP INI*\n` +
              `━━━━━━━━━━━━\n` +
              `Total data: *${Object.keys(group.data || {}).length}*\n\n` +
              `Kalau yakin ketik:\n` +
              "```\n" +
              `${PREFIX}clearabsen konfirmasi\n` +
              "```"
          )
        }

        group.data = {}
        group.roles = { kapten: [], pengurus: [] }
        saveDB(db)

        return Reply(
          `✅ *CLEAR ABSEN BERHASIL!*\n\n` +
            `Setting tetap: *${group.setting.auto ? "ON" : "OFF"}*\n` +
            `Mode tetap: *${String(group.setting.mode).toUpperCase()}*\n` +
            `List mode tetap: *${getListStyle(group).name}*`
        )
      }
    }
  } catch (e) {
    console.error("[AUTOABSEN ERROR]", e)
    return safeReply(alip, m, Reply, `❌ Error autoabsen:\n${e.message || e}`)
  }
}

handler.command = [
  "autoabsen",
  "setautoabsen",
  "panduanautoabsen",
  "setlistabsen",
  "setlistabsen_mode",

  "absen",
  "absenkapten",
  "absenketua",
  "absenpengurus",

  "myabsen",
  "cekabsen",
  "listabsen",
  "noabsen",
  "editabsen",
  "hapusabsen",
  "hapusbsen",
  "clearabsen",

  "absen_detail",
  "absen_manage",
  "hapusabsen_id",
]

handler.group = true

module.exports = handler