const { startGame } = require('../../lib/game.js');

module.exports = async (m, { alip, lyu, Reply, isRegistered, isCreator }) => {
    const sock = lyu || alip;
    await startGame('caklontong', m, sock, Reply, isRegistered, isCreator);
};

module.exports.command = ['caklontong', 'quiz'];
