const fs = require('fs');
const { getWIBTime, safeReadJSON, limitBonusPath } = require('../../lib/game.js');

module.exports = async (m, { Reply, command }) => {
    if (command === "surrender" || command === "nyerah" || command === "menyerah") {
        if (global.gameSessions && global.gameSessions[m.chat]) {
            let session = global.gameSessions[m.chat];
            clearTimeout(session.timeout);
            let displayAnswer = Array.isArray(session.jawaban) ? session.jawaban.join(" / ") : session.jawaban;
            Reply(`🏳️ You surrendered!\nThe answer was: *${displayAnswer}*`);
            delete global.gameSessions[m.chat];
        } else {
            Reply("❌ There is no active game session to surrender.");
        }
    }
};

module.exports.command = ["surrender", "nyerah", "menyerah"];

module.exports.before = async (m, { Reply, isCmd, botNumber }) => {
    global.gameSessions = global.gameSessions || {};
    if (!isCmd && m.isGroup && global.gameSessions[m.chat]) {
        const session = global.gameSessions[m.chat];
        const quotedMsg = m.quoted ? m.quoted : false;
        if (quotedMsg && quotedMsg.id === session.messageId) {
            if (m.sender === botNumber) return;
            const correctAnswer = session.jawaban;
            const userText = (m.text || "").toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

            let isCorrect = false;
            if (Array.isArray(correctAnswer)) {
                isCorrect = correctAnswer.some(j => userText.includes(j.toLowerCase()));
            } else {
                isCorrect = userText === correctAnswer.toLowerCase();
            }

            if (isCorrect) {
                clearTimeout(session.timeout);
                let displayAnswer = Array.isArray(correctAnswer) ? correctAnswer.join(" / ") : correctAnswer;
                const limitReward = Math.floor(Math.random() * 5) + 1;

                const bonusDB = safeReadJSON(limitBonusPath, {});
                const today = getWIBTime().toISOString().split('T')[0];

                if (!bonusDB[m.sender] || bonusDB[m.sender].date !== today) {
                    bonusDB[m.sender] = { bonus: 0, date: today };
                }

                bonusDB[m.sender].bonus += limitReward;
                fs.writeFileSync(limitBonusPath, JSON.stringify(bonusDB, null, 2));

                Reply(`✅ *Correct Answer!*\nThe answer is: *${displayAnswer}*\n\nCongratulations @${m.sender.split('@')[0]}! 🎉\n🎁 You earned a reward of *+${limitReward} Bot Limit!*`, [m.sender]);

                delete global.gameSessions[m.chat];
            } else {
                Reply(`❌ *Incorrect Answer* for this riddle. Try again!`);
            }
        }
    }
};
