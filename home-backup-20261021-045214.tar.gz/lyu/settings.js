// SC ampas kena kretek ujung" nya😹
// tele ku ada di @aboutsahril2nd semua

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// custom info bot
global.owner = '6285181833750'
global.versi = version
global.namaOwner = "LYU STORE"
global.packname = 'LYU AI'
global.botname = "LYU AI"
global.botname2 = 'LYU AI'

// gausah di ubah
global.tempatDB = 'database.json'
global.botSecretKey = "lyu-ai"


global.custompairing = "LYUSTORE"; /* gsh ubah-ubah! */

// Ganti dengan API key mu
global.ramsapikey = 'your_rams_api_key_here' 

// Harga Buy Prem & Sewa Bot 
global.harga = {
    prem: "5000",
    sewa: "10000"
}


// settings apk prem
// apikey premku
global.premku = '75cb35b900aae8e977efe3da52c40b50'
global.profit = 25 // profit

// harga sewa 
global.sewa = {
    bulan1: 15000,
    bulan3: 35000, 
    bulan6: 55000,
    bulan12: 120000
}

// limit harian bot
global.limitHarian = 10; // Ganti sesuai keinginan

// Batas peringatan (warn) grup sebelum kick (fitur anti-toxic, anti-bot, anti-link, anti-spam, dll.)
global.warnGrup = 3;

// SUBDO CF
global.cloudflareZoneId = 'zode token'
global.cloudflareApiToken = 'token cf'
global.cloudflareDomain = 'domain.com'

// Lyu rest api
global.apilyu = "https://api.clutch.web.id"
global.apikeylyu = "alipaiapikeybaru"
global.apialip = global.apilyu
global.apikeyalip = global.apikeylyu
global.btc = "https://api.botcahx.eu.org"
global.apibotcahx = "alipai-botcahx"
global.termai = "https://api.termai.cc"
global.apitermai = "alipai-termai404"
global.amPremApikey = "lyustore-key"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://lyustore.com" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6283173403262"
global.linkGrup = "https://chat.whatsapp.com/JnEsjUVqh70Ad5wh8chrBr"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 6000
global.delayPushkontak = 8000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VbCg3k3G8l5MfuPyhb1K"
global.idSaluran = "120363419259331878@newsletter"
global.namaSaluran = "Lucy : The Unknown"


// Settings All Payment
global.dana = " blm tersedia " // ubah jadi nomor dana kalian 
global.gopay = " blm tersedia " // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "https://cdn.phototourl.com/free/2026-07-10-63f95284-0049-4c58-85d8-0a477f07c4b2.png",
// menu v3
menuv3: "https://cdn.phototourl.com/free/2026-07-10-63f95284-0049-4c58-85d8-0a477f07c4b2.png",
//banner welcome 
welcome: "https://cdn-alip.clutch.web.id/api/u/mpw2f68i.jpg", 
//banner left 
left: "https://cdn-alip.clutch.web.id/api/u/mpw2f68i.jpg", 
// logo saat bot reply pesan
reply: "https://cdn.phototourl.com/free/2026-07-10-63f95284-0049-4c58-85d8-0a477f07c4b2.png", 
canvas: "https://cdn-alip.clutch.web.id/api/u/mpw2f68i.jpg", 
// ubah jadi qris kalian
qris: "https://cdn.phototourl.com/free/2026-07-10-63f95284-0049-4c58-85d8-0a477f07c4b2.png"
}

// Message Command 
global.mess = {
    limit: `🎀 *Limit reached*\nPlease type *.claim* to claim your limit bonus\nOr *.buyprem* to upgrade to Premium.`,
    owner: `🎀 *Access denied*\nThis feature is only available for the *Bot Owner*.`,
    verifikasi: `🎀 *Access denied*\nPlease type *.daftar name,age* to access all bot features.`,
    admin: `🎀 *Access denied*\nThis feature is specifically for *Group Admins*.`,
    botAdmin: `🎀 *Access denied*\nThe bot must be a *Group Admin* to use this feature.`,
    group: `🎀 *Access denied*\nThis feature can only be used in *Groups*.`,
    private: `🎀 *Access denied*\nThis feature can only be used in *Private Chat*.`,
    prem: `🎀 *Access denied*\nThis feature is only available for *Premium Users*.\nType *.prem* for upgrade information.`,
    wait: `🎀 *Please wait...*\nYour request is being processed.`,
    error: `🎀 *An error occurred*\nPlease try again in a few moments.`,
    done: `🎀 *Success*\nThe process has been completed.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
