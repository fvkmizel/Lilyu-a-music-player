// SC ampas kena kretek ujung" nya😹
// tele ku ada di @aboutsahril2nd semua

// --- MODULE SHIM / ALIAS BAILEYS-MBUILDER LENGKAP ---
const Module = require("module");
const originalRequire = Module.prototype.require;
const baileysInstance = require("@whiskeysockets/baileys");

class AIRichBuilder {
  constructor(sock) {
    this.sock = sock;
    this.sections = [];
  }

  addTable(rows) {
    if (!Array.isArray(rows) || rows.length === 0) return this;
    
    // Hitung lebar maksimal tiap kolom
    const colWidths = [];
    rows.forEach(row => {
      row.forEach((cell, idx) => {
        const len = String(cell).length;
        colWidths[idx] = Math.max(colWidths[idx] || 0, len);
      });
    });

    // Format tabel ASCII monospaced
    const formatted = rows.map((row, rIdx) => {
      const line = row.map((cell, cIdx) => String(cell).padEnd(colWidths[cIdx])).join(" | ");
      if (rIdx === 0) {
        const sep = colWidths.map(w => "-".repeat(w)).join("-|-");
        return `${line}\n${sep}`;
      }
      return line;
    }).join("\n");

    this.sections.push(`\`\`\`\n${formatted}\n\`\`\``);
    return this;
  }

  async send(jid, options = {}) {
    const textMessage = this.sections.join("\n\n");
    return this.sock.sendMessage(jid, {
      text: textMessage,
      contextInfo: {
        isForwarded: !!options.forwarded,
        forwardingScore: options.forwarded ? 999 : 0
      }
    });
  }
}

Module.prototype.require = function (request) {
  if (request === "baileys-mbuilder") {
    return {
      ...baileysInstance,
      AIRich: AIRichBuilder
    };
  }
  return originalRequire.apply(this, arguments);
};

require("./settings");
global.bypassCheck = true;
global.licenseTicket = global.internalValidationKey;

const fs = require("fs");
const pino = require("pino");
const path = require("path");
const axios = require("axios");
const chalk = require("chalk");
const readline = require("readline");
const fileType = require("file-type");
const { exec } = require("child_process");
const { say } = require("cfonts");
const { Boom } = require("@hapi/boom");
const NodeCache = require("node-cache");
const fetch = require("node-fetch");
const {
  default: makeWASocket,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  useMultiFileAuthState,
  Browsers,
  DisconnectReason,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion,
  proto,
  PHONENUMBER_MCC,
  getAggregateVotesInPollMessage,
  delay
} = require("@whiskeysockets/baileys");

const Database = require("./source/database");
const dbInstance = new Database();
const { MessagesUpset, SolvingHendler } = require("./source/message");
const { initializerHandler } = require("./handler.js");
const {
  isUrl,
  generateMessageTeg,
  getBuffer,
  getSizeMedia,
  fetchJson,
  sleep
} = require("./library/function");

const isPairingCode = global.pairing_code || process.argv.includes("--pairing-code");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const question = (query) => new Promise((resolve) => rl.question(query, resolve));

// Error handling global
process.on("uncaughtException", (err, origin) => {
  console.error(chalk.red("[ERROR FATAL TIDAK TERDUGA]"), err, origin);
});

process.on("unhandledRejection", (reason, promise) => {
  console.error(chalk.red("[PROMISE ERROR TIDAK TERDUGA]"), reason, promise);
});

// Inisialisasi Database Lokal Bot
(async () => {
  try {
    const data = await dbInstance.read();
    global.db = {
      users: {},
      groups: {},
      database: {},
      settings: {},
      ...(data || {})
    };
    if (Object.keys(data || {}).length === 0) {
      await dbInstance.write(global.db);
    }

    let isWriting = false;
    let pendingWrite = false;
    const saveDatabase = async () => {
      if (isWriting) {
        pendingWrite = true;
        return;
      }
      isWriting = true;
      try {
        await dbInstance.write(global.db);
      } catch (e) {
        console.error(chalk.red("Error simpan database:"), e.message);
      } finally {
        isWriting = false;
        if (pendingWrite) {
          pendingWrite = false;
          setTimeout(saveDatabase, 1000);
        }
      }
    };
    setInterval(saveDatabase, 30000);
  } catch (e) {
    console.error(chalk.red("Gagal inisialisasi database:"), e.message);
    process.exit(1);
  }
})();

let isReconnecting = false;
let reconnectAttempts = 0;
const INITIAL_RECONNECT_DELAY = 5000;

async function startBot() {
  const store = makeInMemoryStore({
    logger: pino().child({ level: "silent", stream: "store" })
  });

  const { state, saveCreds } = await useMultiFileAuthState("session");
  const { version, isLatest } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    printQRInTerminal: !isPairingCode,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Ubuntu", "Chrome", "22.04.2"],
    generateHighQualityLinkPreview: true,
    getMessage: async (key) => store.loadMessage(key.remoteJid, key.id, undefined)?.message,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 30000,
    maxIdleTimeMs: 60000,
    emitOwnEvents: true,
    defaultQueryTimeoutMs: 60000,
    retryRequestDelayMs: 2000,
    syncFullHistory: false,
    markOnlineOnConnect: true,
    fireInitQueries: true,
    shouldIgnoreJid: (jid) => jid?.includes("broadcast"),
    patchMessageBeforeSending: (message) => {
      const isInteractive = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
      if (isInteractive) {
        return {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadataVersion: 2,
                deviceListMetadata: {}
              },
              ...message
            }
          }
        };
      }
      return message;
    }
  });

  const groupMetaCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
  const msgDuplicateCache = new NodeCache({ stdTTL: 60, checkperiod: 30 });
  const miscCache = new NodeCache({ stdTTL: 120, checkperiod: 60 });

  sock.safeGroupMetadata = async (jid) => {
    if (groupMetaCache.has(jid)) return groupMetaCache.get(jid);
    try {
      const meta = await Promise.race([
        sock.groupMetadata(jid),
        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout meta")), 10000))
      ]);
      groupMetaCache.set(jid, meta);
      return meta;
    } catch (err) {
      console.error(chalk.red(` Error ambil metadata grup ${jid}:`), err.message);
      return { id: jid, subject: "Unknown", participants: [] };
    }
  };

  // Alur Input Nomor & Pairing Code
  if (isPairingCode && !sock.authState.creds.registered) {
    console.clear();
    console.log(chalk.cyanBright.bold("PENGATURAN NOMOR WHATSAPP BOT\n"));

    let phoneNumber = "";
    while (!phoneNumber) {
      phoneNumber = await question(
        chalk.cyanBright.bold("# Masukkan Nomor WhatsApp Bot\nContoh : 62812XXX\n") +
        chalk.white("➤ ")
      );
      phoneNumber = phoneNumber.replace(/[^0-9]/g, "");
      if (!phoneNumber) {
        console.log(chalk.red("Nomor tidak boleh kosong!\n"));
      }
    }

    let pairingCode = await sock.requestPairingCode(phoneNumber, global.custompairing);
    pairingCode = pairingCode.match(/.{1,4}/g)?.join(" - ") || pairingCode;
    console.log(chalk.green.bold("\nPairing code berhasil dibuat: ") + chalk.white.bold(pairingCode) + "\n");
  }

  // Handle Event Koneksi
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      console.log(chalk.yellow("📱 Scan QR / Masukan pairing code untuk melanjutkan..."));
    }
    if (connection === "close") {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      if (statusCode === DisconnectReason.loggedOut) {
        console.log(chalk.red("PERANGKAT KELUAR, SILAKAN HAPUS FOLDER SESSION DAN PAIRING ULANG!"));
        process.exit(0);
      }
      if (!isReconnecting) {
        isReconnecting = true;
        reconnectAttempts++;
        const delayMs = Math.min(INITIAL_RECONNECT_DELAY * Math.pow(1.5, reconnectAttempts), 60000) + Math.random() * 2000;
        setTimeout(async () => {
          try {
            await startBot();
          } catch (e) {
            console.error("Reconnect gagal:", e.message);
          } finally {
            isReconnecting = false;
          }
        }, delayMs);
      }
    }
    if (connection === "open") {
      reconnectAttempts = 0;
      console.log(chalk.cyanBright.bold("BOT BERHASIL TERHUBUNG"));
    }
  });

  await store.bind(sock.ev);
  await SolvingHendler(sock, store);
  initializerHandler(sock, store);

  // Message Upsert Handler & Queue
  const queueMap = new Map();
  const activeQueues = new Set();

  const processQueue = async () => {
    for (const [key, tasks] of queueMap.entries()) {
      if (tasks.length === 0) {
        queueMap.delete(key);
        continue;
      }
      if (activeQueues.has(key)) continue;

      activeQueues.add(key);
      const currentTask = tasks.shift();
      try {
        await currentTask();
      } catch (e) {
        console.error(chalk.red("[Queue Task Error]:"), e);
      }
      activeQueues.delete(key);
    }
    setTimeout(processQueue, 50);
  };
  processQueue();

  const enqueueMessage = (key, task) => {
    if (!queueMap.has(key)) queueMap.set(key, []);
    queueMap.get(key).push(task);
  };

  sock.ev.on("messages.upsert", async (chatUpdate) => {
    const msg = chatUpdate.messages?.[0];
    const msgId = msg?.key?.id || Date.now().toString();
    if (msgDuplicateCache.has(msgId)) return;
    msgDuplicateCache.set(msgId, true);

    enqueueMessage(msg?.key?.remoteJid || "global", async () => {
      try {
        await MessagesUpset(sock, chatUpdate, store);
      } catch (err) {
        console.error(chalk.red("Error di messages.upsert:"), err);
      }
    });
  });

  // Antrian & Rate Limit SendMessage
  const sendPromises = {};
  const lastSendTimes = new Map();
  const rateLimits = new Map();
  const originalSendMessage = sock.sendMessage.bind(sock);

  sock.sendMessage = async (jid, content, options) => {
    if (!sendPromises[jid]) sendPromises[jid] = Promise.resolve();

    return (sendPromises[jid] = sendPromises[jid].then(async () => {
      const now = Date.now();
      const lastSend = lastSendTimes.get(jid) || 0;
      const rate = rateLimits.get(jid) || { count: 0, resetTime: now + 60000 };

      if (now > rate.resetTime) {
        rate.count = 0;
        rate.resetTime = now + 60000;
      }
      rate.count++;
      rateLimits.set(jid, rate);

      const throttleDelay = rate.count > 30 ? 2000 : rate.count > 15 ? 1000 : 800;
      if (now - lastSend < throttleDelay) {
        await delay(throttleDelay - (now - lastSend));
      }

      let retry = 0;
      while (retry < 3) {
        try {
          const res = await Promise.race([
            originalSendMessage(jid, content, options),
            new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout sendMessage")), 20000))
          ]);
          lastSendTimes.set(jid, Date.now());
          return res;
        } catch (err) {
          const msg = err.message || "";
          if (
            msg.includes("rate-overlimit") ||
            msg.includes("ConnectionClosed") ||
            msg.includes("close") ||
            msg.includes("ECONNRESET") ||
            msg.includes("ETIMEDOUT")
          ) {
            if (++retry < 3) {
              await delay(Math.min(Math.pow(2, retry) * 3000, 15000));
              continue;
            }
            return null;
          }
          if (msg.includes("not-authorized") || msg.includes("401") || msg.includes("403")) {
            return null;
          }
          break;
        }
      }
      return null;
    }).catch(() => null));
  };

  sock.safeSendText = async (jid, text, options = {}) => {
    return sock.sendMessage(jid, { text: text.toString().substring(0, 4096) }, options);
  };

  sock.safeSendImage = async (jid, image, caption = "", options = {}) => {
    if (!image) return null;
    try {
      return sock.sendMessage(jid, { image, caption: caption.substring(0, 4096) }, options);
    } catch (e) {
      return null;
    }
  };

  // Cache Flusher tiap 5 Menit
  setInterval(() => {
    const now = Date.now();
    for (const [jid, time] of lastSendTimes.entries()) {
      if (now - time > 300000) lastSendTimes.delete(jid);
    }
    for (const [jid, data] of rateLimits.entries()) {
      if (now > data.resetTime) rateLimits.delete(jid);
    }
    groupMetaCache.flushAll();
    msgDuplicateCache.flushAll();
    miscCache.flushAll();
  }, 300000);

  // Watcher reload otomatis file saat diedit
  const currentFile = require.resolve(__filename);
  fs.watchFile(currentFile, () => {
    fs.unwatchFile(currentFile);
    console.log(chalk.redBright(`Update ${__filename}`));
    delete require.cache[currentFile];
    require(currentFile);
  });

  return sock;
}

startBot().catch((err) => {
  console.error(chalk.red("Gagal memulai bot:"), err);
  setTimeout(startBot, 10000);
});
