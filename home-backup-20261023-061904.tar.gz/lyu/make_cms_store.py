import json

with open('/root/lyu/peka/posts/blog/all_blog_posts.json', 'r', encoding='utf-8') as f:
    posts = json.load(f)

with open('/root/lyu/peka/menus_and_structure/menus.json', 'r', encoding='utf-8') as f:
    menus = json.load(f)

posts_json = json.dumps(posts, ensure_ascii=False, indent=2)
menus_json = json.dumps(menus, ensure_ascii=False, indent=2)

js_content = """// CMS Core Storage & State Engine
// Preloaded with scraped Peka AI data

const SEED_POSTS = """ + posts_json + """;

const SEED_MENUS = """ + menus_json + """;

const SEED_SETTINGS = {
  siteTitle: "Peka AI",
  siteTagline: "AI that gets what Indonesia is saying.",
  siteDescription: "Kumpulan produk dan tool AI untuk memahami percakapan publik Indonesia: Warganet AI, Kata Wowo, dan MBG Watch.",
  siteUrl: "https://peka.ai.id",
  logoUrl: "/static/icon-512.png",
  accentColor: "#ffd60a",
  theme: "light",
  postsPerPage: 10,
  enableComments: true,
  socialLinks: {
    instagram: "https://www.instagram.com/peka.ai.id",
    threads: "https://www.threads.com/@peka.ai.id",
    facebook: "https://www.facebook.com/peka.ai.id",
    telegram: "https://t.me/peka_aichannel",
    whatsapp: "https://chat.whatsapp.com/GLRMuZBICZg2636lVPj6NL?s=cl&p=i&mlu=4&ilr=4"
  }
};

class PekaCMS {
  constructor() {
    this.init();
  }

  init() {
    if (!localStorage.getItem('peka_cms_posts')) {
      localStorage.setItem('peka_cms_posts', JSON.stringify(SEED_POSTS));
    }
    if (!localStorage.getItem('peka_cms_menus')) {
      localStorage.setItem('peka_cms_menus', JSON.stringify(SEED_MENUS));
    }
    if (!localStorage.getItem('peka_cms_settings')) {
      localStorage.setItem('peka_cms_settings', JSON.stringify(SEED_SETTINGS));
    }
    if (!localStorage.getItem('peka_cms_stats')) {
      this.refreshStats();
    }
  }

  getPosts() {
    try {
      return JSON.parse(localStorage.getItem('peka_cms_posts')) || SEED_POSTS;
    } catch(e) {
      return SEED_POSTS;
    }
  }

  savePosts(posts) {
    localStorage.setItem('peka_cms_posts', JSON.stringify(posts));
    this.refreshStats();
  }

  getPostBySlug(slug) {
    const posts = this.getPosts();
    return posts.find(p => p.slug === slug || String(p.id) === String(slug));
  }

  savePost(postData) {
    const posts = this.getPosts();
    const index = posts.findIndex(p => p.slug === postData.slug || (postData.id && p.id === postData.id));

    if (!postData.id) {
      postData.id = 'post_' + Date.now();
    }
    if (!postData.date) {
      postData.date = new Date().toISOString().split('T')[0];
    }

    if (index >= 0) {
      posts[index] = { ...posts[index], ...postData };
    } else {
      posts.unshift(postData);
    }

    this.savePosts(posts);
    this.logActivity('Post tersimpan: ' + postData.title);
    return postData;
  }

  deletePost(slugOrId) {
    let posts = this.getPosts();
    const target = posts.find(p => p.slug === slugOrId || p.id === slugOrId);
    posts = posts.filter(p => p.slug !== slugOrId && p.id !== slugOrId);
    this.savePosts(posts);
    if (target) {
      this.logActivity('Post dihapus: ' + target.title);
    }
    return true;
  }

  getMenus() {
    try {
      return JSON.parse(localStorage.getItem('peka_cms_menus')) || SEED_MENUS;
    } catch(e) {
      return SEED_MENUS;
    }
  }

  saveMenus(menus) {
    localStorage.setItem('peka_cms_menus', JSON.stringify(menus));
    this.logActivity('Menu navigasi diperbarui');
  }

  getSettings() {
    try {
      return JSON.parse(localStorage.getItem('peka_cms_settings')) || SEED_SETTINGS;
    } catch(e) {
      return SEED_SETTINGS;
    }
  }

  saveSettings(settings) {
    localStorage.setItem('peka_cms_settings', JSON.stringify(settings));
    this.logActivity('Pengaturan web diperbarui');
  }

  getStats() {
    const posts = this.getPosts();
    const published = posts.filter(p => p.status !== 'draft').length;
    const drafts = posts.filter(p => p.status === 'draft').length;
    const categories = new Set();
    posts.forEach(p => {
      (p.categories || []).forEach(c => categories.add(c));
    });

    return {
      totalPosts: posts.length,
      publishedPosts: published,
      draftPosts: drafts,
      totalCategories: Math.max(categories.size, 6),
      totalViews: 14280 + posts.length * 150,
      activeAgents: 36
    };
  }

  refreshStats() {
    const stats = this.getStats();
    localStorage.setItem('peka_cms_stats', JSON.stringify(stats));
  }

  logActivity(action) {
    const logs = JSON.parse(localStorage.getItem('peka_cms_logs') || '[]');
    const now = new Date();
    logs.unshift({
      action: action,
      time: now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      date: now.toLocaleDateString('id-ID')
    });
    localStorage.setItem('peka_cms_logs', JSON.stringify(logs.slice(0, 30)));
  }

  getLogs() {
    return JSON.parse(localStorage.getItem('peka_cms_logs') || '[]');
  }

  resetToDefault() {
    localStorage.setItem('peka_cms_posts', JSON.stringify(SEED_POSTS));
    localStorage.setItem('peka_cms_menus', JSON.stringify(SEED_MENUS));
    localStorage.setItem('peka_cms_settings', JSON.stringify(SEED_SETTINGS));
    this.refreshStats();
  }
}

window.cms = new PekaCMS();
window.DEFAULT_PEKA_POSTS = SEED_POSTS;
"""

with open('/root/lyu/peka/template/dashboard-cms/js/cms-store.js', 'w', encoding='utf-8') as f:
    f.write(js_content)

# Also copy to template/assets/js/cms-store.js so frontend pages can also access it
with open('/root/lyu/peka/template/assets/js/cms-store.js', 'w', encoding='utf-8') as f:
    f.write(js_content)

print(f"cms-store.js written! Size: {len(js_content)} bytes")
