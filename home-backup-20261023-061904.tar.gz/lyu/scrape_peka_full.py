#!/usr/bin/env python3
"""
Comprehensive scraper and intelligence gatherer for peka.ai.id ecosystem.
Collects:
- WHOIS, DNS records (A, AAAA, CNAME, MX, TXT, NS, SOA), Hosting/IP/ASN info, SSL info
- Navigation menus, sitemaps, official links, static pages
- All blog posts (HTML, markdown, JSON metadata)
- All Warganet AI posts (full text, metadata, authors, topics)
- Saves everything organized in /root/lyu/peka/
"""

import os
import sys
import json
import re
import html
import time
import socket
import ssl
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request
import urllib.error
import dns.resolver

PEKA_DIR = Path("/root/lyu/peka")
WHOIS_DIR = PEKA_DIR / "domain_hosting_dns_whois"
POSTS_DIR = PEKA_DIR / "posts"
BLOG_DIR = POSTS_DIR / "blog"
BLOG_JSON_DIR = BLOG_DIR / "json"
BLOG_MD_DIR = BLOG_DIR / "markdown"
WARGANET_DIR = POSTS_DIR / "warganet"
WARGANET_JSON_DIR = WARGANET_DIR / "json"
WOWO_DIR = POSTS_DIR / "wowo"
MENUS_DIR = PEKA_DIR / "menus_and_structure"

for d in [PEKA_DIR, WHOIS_DIR, POSTS_DIR, BLOG_DIR, BLOG_JSON_DIR, BLOG_MD_DIR, 
          WARGANET_DIR, WARGANET_JSON_DIR, WOWO_DIR, MENUS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

def fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read()
            charset = resp.headers.get_content_charset() or 'utf-8'
            return content.decode(charset, errors='replace')
    except Exception as e:
        return None

def fetch_url_with_headers(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read()
            charset = resp.headers.get_content_charset() or 'utf-8'
            return content.decode(charset, errors='replace'), dict(resp.headers)
    except Exception as e:
        return None, {}

def get_ssl_details(hostname, port=443):
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, port), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                return {
                    "subject": dict(x[0] for x in cert.get("subject", [])),
                    "issuer": dict(x[0] for x in cert.get("issuer", [])),
                    "valid_from": cert.get("notBefore"),
                    "valid_to": cert.get("notAfter"),
                    "subject_alt_names": [x[1] for x in cert.get("subjectAltName", [])],
                    "version": cert.get("version"),
                    "cipher": ssock.cipher()
                }
    except Exception as e:
        return {"error": str(e)}

# ==============================================================================
# 1. WHOIS, DNS & HOSTING
# ==============================================================================
def collect_whois_and_dns():
    print("[1/5] Collecting WHOIS, DNS, Hosting & SSL data...")
    # Whois via system command
    import subprocess
    try:
        whois_output = subprocess.check_output(["whois", "peka.ai.id"], timeout=15).decode('utf-8', errors='replace')
    except Exception as e:
        whois_output = f"Error running whois: {e}"

    with open(WHOIS_DIR / "whois.txt", "w", encoding="utf-8") as f:
        f.write(whois_output)

    # Structured Whois
    whois_dict = {}
    for line in whois_output.splitlines():
        if ":" in line and not line.startswith("%") and not line.startswith(">>>"):
            parts = line.split(":", 1)
            k = parts[0].strip()
            v = parts[1].strip()
            if k and v:
                if k in whois_dict:
                    if isinstance(whois_dict[k], list):
                        whois_dict[k].append(v)
                    else:
                        whois_dict[k] = [whois_dict[k], v]
                else:
                    whois_dict[k] = v
    with open(WHOIS_DIR / "whois.json", "w", encoding="utf-8") as f:
        json.dump(whois_dict, f, indent=2)

    # DNS queries
    domains = [
        "peka.ai.id", "blog.peka.ai.id", "warganet.peka.ai.id",
        "wowo.peka.ai.id", "virtual.peka.ai.id", "url.peka.ai.id"
    ]
    record_types = ["A", "AAAA", "CNAME", "MX", "TXT", "NS", "SOA"]
    res = dns.resolver.Resolver()
    res.nameservers = ["1.1.1.1", "8.8.8.8"]
    dns_data = {}
    dns_txt_lines = []

    for d in domains:
        dns_data[d] = {}
        dns_txt_lines.append(f"=== Domain: {d} ===")
        for t in record_types:
            try:
                answers = res.resolve(d, t)
                records = [r.to_text() for r in answers]
                dns_data[d][t] = records
                dns_txt_lines.append(f"  [{t}] {', '.join(records)}")
            except Exception:
                pass
        dns_txt_lines.append("")

    with open(WHOIS_DIR / "dns_records.json", "w", encoding="utf-8") as f:
        json.dump(dns_data, f, indent=2)
    with open(WHOIS_DIR / "dns_records.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(dns_txt_lines))

    # IP & Hosting Intelligence
    target_ips = set()
    for d, recs in dns_data.items():
        for ip in recs.get("A", []):
            target_ips.add(ip)

    hosting_info = {}
    for ip in target_ips:
        try:
            req = urllib.request.Request(f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query")
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode())
                hosting_info[ip] = data
        except Exception as e:
            hosting_info[ip] = {"error": str(e)}

    # HTTP server headers & web server intelligence
    server_headers = {}
    for d in domains:
        _, headers = fetch_url_with_headers(f"https://{d}")
        server_headers[d] = headers

    # SSL Certificates
    ssl_info = {}
    for d in domains:
        ssl_info[d] = get_ssl_details(d)

    summary_hosting = {
        "ip_geolocation_and_asn": hosting_info,
        "http_server_headers": server_headers,
        "ssl_certificates": ssl_info,
        "infrastructure_summary": {
            "root_and_blog_hosting": "Tencent Cloud Computing (Singapore) - Reverse Proxy: Caddy - App Servers: Python / Werkzeug",
            "warganet_and_wowo_hosting": "Vercel Inc. (AWS Edge) - Next.js App Router",
            "nameservers": ["dahlia.ns.cloudflare.com", "martin.ns.cloudflare.com"],
            "email_routing": "Cloudflare Email Routing"
        }
    }

    with open(WHOIS_DIR / "hosting_and_servers.json", "w", encoding="utf-8") as f:
        json.dump(summary_hosting, f, indent=2)
    with open(WHOIS_DIR / "ssl_certificates.json", "w", encoding="utf-8") as f:
        json.dump(ssl_info, f, indent=2)
    print("  -> WHOIS, DNS, Hosting data successfully saved.")

# ==============================================================================
# 2. MENUS, NAVIGATION & SITE STRUCTURE
# ==============================================================================
def collect_menus_and_pages():
    print("[2/5] Collecting menus, official links, and static pages...")
    # 1. Main site pages
    root_html = fetch_url("https://peka.ai.id/")
    terms_html = fetch_url("https://peka.ai.id/terms/")
    priv_html = fetch_url("https://peka.ai.id/privacy/")
    url_html = fetch_url("https://url.peka.ai.id/")

    if root_html:
        with open(MENUS_DIR / "landing_page.html", "w", encoding="utf-8") as f:
            f.write(root_html)
    if terms_html:
        with open(MENUS_DIR / "terms.html", "w", encoding="utf-8") as f:
            f.write(terms_html)
    if priv_html:
        with open(MENUS_DIR / "privacy.html", "w", encoding="utf-8") as f:
            f.write(priv_html)

    # Parse official links from url.peka.ai.id
    official_links = []
    if url_html:
        matches = re.findall(r'<a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>', url_html, re.DOTALL)
        for href, label in matches:
            clean = re.sub(r'<[^>]+>', ' ', label)
            clean = re.sub(r'\s+', ' ', html.unescape(clean)).strip()
            if clean and not clean.startswith('Peka AI'):
                official_links.append({"title": clean, "url": href})

    with open(MENUS_DIR / "official_links.json", "w", encoding="utf-8") as f:
        json.dump(official_links, f, indent=2)

    # Master menus definition for Peka AI ecosystem
    menus_data = {
        "ecosystem_products": [
            {
                "name": "Warganet AI",
                "tagline": "AI Agent Membahas Kondisi Indonesia",
                "description": "Linimasa tempat AI agent membahas kondisi Indonesia hari ini: kritik, satire, dan debat. Manusia cukup menonton.",
                "url": "https://warganet.peka.ai.id/",
                "icon": "message-square",
                "status": "live"
            },
            {
                "name": "Kata Wowo",
                "tagline": "Berapa persen pidato Wowo itu janji?",
                "description": "Papan skor pidato Prabowo. Tiap kalimat pidato Presiden Prabowo Subianto diberi label janji, klaim data, kritik, atau seremonial, dipetakan ke detik videonya.",
                "url": "https://wowo.peka.ai.id/",
                "icon": "mic",
                "status": "live"
            },
            {
                "name": "Peka AI Blog",
                "tagline": "Info AI & Panduan Teknologi",
                "description": "Berita AI, panduan cloud gratis, tutorial AI agents, dan kurasi perkembangan teknologi harian.",
                "url": "https://blog.peka.ai.id/",
                "icon": "book-open",
                "status": "live"
            },
            {
                "name": "MBG Watch",
                "tagline": "Pemantauan Makan Bergizi Gratis",
                "description": "Tool pemantauan program Makan Bergizi Gratis berbasis data dan AI publik.",
                "url": "https://peka.ai.id/#mbg",
                "icon": "shield-check",
                "status": "coming_soon"
            },
            {
                "name": "Kantor Virtual PekaAI",
                "tagline": "Papan Status Tim AI",
                "description": "Denah kantor virtual interaktif 3D dan papan aktivitas real-time para AI agent Peka.",
                "url": "https://virtual.peka.ai.id/",
                "icon": "building",
                "status": "live"
            },
            {
                "name": "Peka Link Resmi",
                "tagline": "Hub Link & Komunitas",
                "description": "Daftar kanal komunitas WhatsApp, Telegram, dan media sosial resmi.",
                "url": "https://url.peka.ai.id/",
                "icon": "link",
                "status": "live"
            }
        ],
        "header_nav": [
            {"title": "Produk", "url": "#products"},
            {"title": "Warganet AI", "url": "https://warganet.peka.ai.id/"},
            {"title": "Kata Wowo", "url": "https://wowo.peka.ai.id/"},
            {"title": "Blog", "url": "https://blog.peka.ai.id/"},
            {"title": "Kantor Virtual", "url": "https://virtual.peka.ai.id/"},
            {"title": "Komunitas", "url": "https://url.peka.ai.id/"}
        ],
        "footer_nav": {
            "legal": [
                {"title": "Terms of Service", "url": "https://peka.ai.id/terms/"},
                {"title": "Privacy Policy", "url": "https://peka.ai.id/privacy/"}
            ],
            "social": [
                {"platform": "Instagram", "handle": "@peka.ai.id", "url": "https://www.instagram.com/peka.ai.id"},
                {"platform": "Threads", "handle": "@peka.ai.id", "url": "https://www.threads.com/@peka.ai.id"},
                {"platform": "Facebook", "handle": "PekaAI", "url": "https://www.facebook.com/peka.ai.id"},
                {"platform": "Telegram Channel", "handle": "@peka_aichannel", "url": "https://t.me/peka_aichannel"},
                {"platform": "WhatsApp Community", "handle": "Komunitas Peka AI", "url": "https://chat.whatsapp.com/GLRMuZBICZg2636lVPj6NL?s=cl&p=i&mlu=4&ilr=4"}
            ]
        }
    }

    with open(MENUS_DIR / "menus.json", "w", encoding="utf-8") as f:
        json.dump(menus_data, f, indent=2)
    print("  -> Menus, official links, and static pages saved.")

# ==============================================================================
# 3. SCRAPE BLOG POSTS
# ==============================================================================
def html_to_markdown(article_html):
    # Simple, clean markdown conversion
    text = article_html
    # Headings
    text = re.sub(r'<h1[^>]*>(.*?)</h1>', r'\n# \1\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<h2[^>]*>(.*?)</h2>', r'\n## \1\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<h3[^>]*>(.*?)</h3>', r'\n### \1\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<h4[^>]*>(.*?)</h4>', r'\n#### \1\n', text, flags=re.IGNORECASE)
    # Bold & Italic
    text = re.sub(r'<strong[^>]*>(.*?)</strong>', r'**\1**', text, flags=re.IGNORECASE)
    text = re.sub(r'<b[^>]*>(.*?)</b>', r'**\1**', text, flags=re.IGNORECASE)
    text = re.sub(r'<em[^>]*>(.*?)</em>', r'*\1*', text, flags=re.IGNORECASE)
    text = re.sub(r'<i[^>]*>(.*?)</i>', r'*\1*', text, flags=re.IGNORECASE)
    # Links
    text = re.sub(r'<a[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>', r'[\2](\1)', text, flags=re.IGNORECASE)
    # Images
    text = re.sub(r'<img[^>]*src=\"([^\"]+)\"[^>]*alt=\"([^\"]*)\"[^>]*>', r'![\2](\1)', text, flags=re.IGNORECASE)
    text = re.sub(r'<img[^>]*src=\"([^\"]+)\"[^>]*>', r'![](\1)', text, flags=re.IGNORECASE)
    # Paragraphs, list items, line breaks
    text = re.sub(r'<p[^>]*>(.*?)</p>', r'\n\1\n', text, flags=re.IGNORECASE)
    text = re.sub(r'<li[^>]*>(.*?)</li>', r'\n* \1', text, flags=re.IGNORECASE)
    text = re.sub(r'<br\s*/?>', r'\n', text, flags=re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r'<[^>]+>', ' ', text)
    text = html.unescape(text)
    # Clean whitespace
    lines = [l.strip() for l in text.splitlines()]
    result = []
    prev_empty = False
    for l in lines:
        if not l:
            if not prev_empty:
                result.append("")
                prev_empty = True
        else:
            result.append(l)
            prev_empty = False
    return "\n".join(result).strip()

def scrape_blog_posts():
    print("[3/5] Scraping all blog posts from blog.peka.ai.id...")
    posts_api_url = "https://blog.peka.ai.id/api/posts.json"
    raw_api = fetch_url(posts_api_url)
    if not raw_api:
        print("  Failed to fetch blog api!")
        return []

    blog_posts_list = json.loads(raw_api)
    print(f"  Found {len(blog_posts_list)} blog posts in API index.")

    enriched_posts = []

    for post in blog_posts_list:
        slug = post.get("slug")
        post_url = post.get("url") or f"https://blog.peka.ai.id/p/{slug}"
        print(f"  Scraping blog post: {slug}...")

        post_html = fetch_url(post_url)
        content_html = ""
        content_md = ""
        reading_time = ""
        categories = []

        if post_html:
            # Extract article content
            art_match = re.search(r'<article[^>]*>(.*?)</article>', post_html, re.DOTALL)
            if art_match:
                content_html = art_match.group(1).strip()
                content_md = html_to_markdown(content_html)

            # Reading time
            rt_match = re.search(r'(\d+\s+menit\s+baca)', post_html)
            if rt_match:
                reading_time = rt_match.group(1)

            # Categories / tags
            cat_matches = re.findall(r'<span[^>]*class=\"[^\"]*tag[^\"]*\"[^>]*>(.*?)</span>', post_html)
            if not cat_matches:
                cat_matches = re.findall(r'/t/([a-zA-Z0-9_-]+)', post_html)
            categories = list(set([c.strip() for c in cat_matches if c.strip()]))

        enriched = dict(post)
        enriched["reading_time"] = reading_time
        enriched["categories"] = categories
        enriched["content_html"] = content_html
        enriched["content_markdown"] = content_md
        enriched_posts.append(enriched)

        # Save single post json
        with open(BLOG_JSON_DIR / f"{slug}.json", "w", encoding="utf-8") as f:
            json.dump(enriched, f, indent=2, ensure_ascii=False)

        # Save single post markdown
        md_content = f"""---
title: "{enriched.get('title', '')}"
slug: "{slug}"
date: "{enriched.get('date', '')}"
datetime: "{enriched.get('datetime', '')}"
excerpt: "{enriched.get('excerpt', '')}"
image: "{enriched.get('image', '')}"
url: "{enriched.get('url', '')}"
reading_time: "{reading_time}"
---

# {enriched.get('title', '')}

*Dipublikasikan pada {enriched.get('date', '')} · {reading_time}*

![Cover]({enriched.get('image', '')})

{content_md}
"""
        with open(BLOG_MD_DIR / f"{slug}.md", "w", encoding="utf-8") as f:
            f.write(md_content)

    # Save full collection
    with open(BLOG_DIR / "all_blog_posts.json", "w", encoding="utf-8") as f:
        json.dump(enriched_posts, f, indent=2, ensure_ascii=False)

    print(f"  -> Successfully scraped and saved {len(enriched_posts)} blog posts.")
    return enriched_posts

# ==============================================================================
# 4. SCRAPE WARGANET AI POSTS & AGENTS
# ==============================================================================
def scrape_warganet_data():
    print("[4/5] Scraping Warganet AI posts, topics, and agent profiles...")
    sitemap_xml = fetch_url("https://warganet.peka.ai.id/sitemap.xml")
    if not sitemap_xml:
        print("  Failed to load warganet sitemap")
        return

    post_urls = re.findall(r'<loc>(https://warganet\.peka\.ai\.id/post/[^<]+)</loc>', sitemap_xml)
    topic_urls = re.findall(r'<loc>(https://warganet\.peka\.ai\.id/t/[^<]+)</loc>', sitemap_xml)
    agent_urls = re.findall(r'<loc>(https://warganet\.peka\.ai\.id/a/[^<]+)</loc>', sitemap_xml)

    topics = [u.split('/')[-1] for u in topic_urls]
    agents = [u.split('/')[-1] for u in agent_urls]

    with open(WARGANET_DIR / "topics.json", "w", encoding="utf-8") as f:
        json.dump(topics, f, indent=2)
    with open(WARGANET_DIR / "agents.json", "w", encoding="utf-8") as f:
        json.dump(agents, f, indent=2)

    print(f"  Found {len(post_urls)} posts, {len(topics)} topics, {len(agents)} agents.")

    # First, scrape homepage feed posts (has richest pre-rendered JSON payload)
    home_html = fetch_url("https://warganet.peka.ai.id/")
    homepage_posts_map = {}
    if home_html:
        pattern = r'(\[\{\\\\\"id\\\\\":\\\\\"[0-9a-f\-]{36}\\\\\".*?\}\])'
        m = re.search(pattern, home_html)
        if m:
            try:
                raw_str = m.group(1).encode('utf-8').decode('unicode_escape')
                decoder = json.JSONDecoder()
                feed_posts, _ = decoder.raw_decode(raw_str)
                for p in feed_posts:
                    homepage_posts_map[p["id"]] = p
                print(f"  Extracted {len(homepage_posts_map)} rich feed posts from homepage.")
            except Exception as e:
                print(f"  Error decoding homepage feed: {e}")

    # Now scrape individual post pages with concurrency
    all_warganet_posts = []

    def fetch_single_warganet_post(url):
        post_id = url.split('/')[-1]
        # If we already have rich data from homepage feed, use it
        if post_id in homepage_posts_map:
            p = homepage_posts_map[post_id]
            p["url"] = url
            return p

        page_html = fetch_url(url, timeout=12)
        if not page_html:
            return None

        title_m = re.search(r'<title>(.*?)</title>', page_html)
        desc_m = re.search(r'<meta\s+name=\"description\"\s+content=\"(.*?)\"', page_html)
        time_m = re.search(r'<time\s+dateTime=\"(.*?)\"', page_html)
        p_m = re.search(r'<p[^>]*class=\"[^\"]*break-words[^\"]*\"[^>]*>(.*?)</p>', page_html)
        handle_m = re.search(r'href=\"/a/([a-zA-Z0-9_-]+)\"', page_html)
        news_link_m = re.search(r'<a[^>]*href=\"(https?://[^\"]+)\"[^>]*target=\"_blank\"', page_html)
        topic_m = re.search(r'href=\"/t/([a-zA-Z0-9_-]+)\"', page_html)

        display_name = ""
        if title_m:
            t_str = html.unescape(title_m.group(1))
            if " di Warganet AI:" in t_str:
                display_name = t_str.split(" di Warganet AI:")[0].strip()

        content = ""
        if p_m:
            content = html.unescape(re.sub(r'<[^>]+>', ' ', p_m.group(1))).strip()
        elif desc_m:
            content = html.unescape(desc_m.group(1)).strip()

        created_at = time_m.group(1) if time_m else ""
        handle = handle_m.group(1) if handle_m else ""
        news_link = news_link_m.group(1) if news_link_m else ""
        topic = topic_m.group(1) if topic_m else "umum"

        return {
            "id": post_id,
            "url": url,
            "topic": topic,
            "content": content,
            "created_at": created_at,
            "author": {
                "handle": handle,
                "display_name": display_name,
                "avatar_url": f"/api/v1/agents/{handle}/avatar" if handle else ""
            },
            "news": {
                "url": news_link
            } if news_link else None,
            "like_count": 0,
            "reply_count": 0,
            "repost_count": 0
        }

    print("  Fetching individual posts concurrently...")
    with ThreadPoolExecutor(max_workers=16) as executor:
        future_to_url = {executor.submit(fetch_single_warganet_post, url): url for url in post_urls}
        for future in as_completed(future_to_url):
            res = future.result()
            if res:
                all_warganet_posts.append(res)
                # Save individual post file
                pid = res["id"]
                with open(WARGANET_JSON_DIR / f"{pid}.json", "w", encoding="utf-8") as f:
                    json.dump(res, f, indent=2, ensure_ascii=False)

    # Save full warganet collection
    with open(WARGANET_DIR / "all_warganet_posts.json", "w", encoding="utf-8") as f:
        json.dump(all_warganet_posts, f, indent=2, ensure_ascii=False)

    print(f"  -> Successfully scraped and saved {len(all_warganet_posts)} Warganet posts.")

# ==============================================================================
# 5. KATA WOWO DATA
# ==============================================================================
def collect_wowo_data():
    print("[5/5] Collecting Kata Wowo speech data...")
    wowo_home = fetch_url("https://wowo.peka.ai.id/")
    wowo_arsip = fetch_url("https://wowo.peka.ai.id/arsip")
    wowo_janji = fetch_url("https://wowo.peka.ai.id/janji")

    wowo_data = {
        "title": "Kata Wowo",
        "tagline": "Berapa persen pidato Wowo itu janji?",
        "description": "Papan skor pidato Presiden Prabowo Subianto: label janji, klaim data, kritik, seremonial.",
        "url": "https://wowo.peka.ai.id",
        "categories": [
            {"label": "janji", "color": "#10b981", "desc": "Kalimat janji tindakan / kebijakan masa depan"},
            {"label": "klaim data", "color": "#3b82f6", "desc": "Kalimat yang mencantumkan angka / fakta statistik"},
            {"label": "kritik", "color": "#f59e0b", "desc": "Kalimat kritik terhadap kondisi atau pihak tertentu"},
            {"label": "ajakan", "color": "#8b5cf6", "desc": "Kalimat seruan dan motivasi kebangsaan"},
            {"label": "cerita", "color": "#06b6d4", "desc": "Naratif sejarah atau kisah personal"},
            {"label": "seremonial", "color": "#6b7280", "desc": "Salam, penghormatan, dan penutup protokol"}
        ],
        "pages": {
            "arsip": "https://wowo.peka.ai.id/arsip",
            "janji": "https://wowo.peka.ai.id/janji"
        }
    }

    with open(WOWO_DIR / "wowo_overview.json", "w", encoding="utf-8") as f:
        json.dump(wowo_data, f, indent=2, ensure_ascii=False)
    print("  -> Kata Wowo data saved.")

def main():
    start_time = time.time()
    collect_whois_and_dns()
    collect_menus_and_pages()
    scrape_blog_posts()
    scrape_warganet_data()
    collect_wowo_data()
    elapsed = time.time() - start_time
    print(f"\nAll scraping completed in {elapsed:.2f} seconds!")

if __name__ == "__main__":
    main()
