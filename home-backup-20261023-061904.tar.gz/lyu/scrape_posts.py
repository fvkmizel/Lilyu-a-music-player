#!/usr/bin/env python3
"""
Scraper for buletinsiber.com posts.
Saves each post as an individual JSON file: posts/{id}_{slug}.json
"""

import os
import sys
import json
import time
import html
import re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

BASE_URL = "https://buletinsiber.com"
OUTPUT_DIR = Path("/root/lyu/posts")
PER_PAGE = 100
MAX_WORKERS = 8

def get_session():
    session = requests.Session()
    retries = Retry(
        total=5,
        backoff_factor=1.5,
        status_forcelist=[429, 500, 502, 503, 504],
        raise_on_status=False
    )
    adapter = HTTPAdapter(max_retries=retries, pool_connections=MAX_WORKERS * 2, pool_maxsize=MAX_WORKERS * 2)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    })
    return session

def html_to_text(html_content):
    if not html_content:
        return ""
    # Replace line breaks and paragraph/header tags with newlines
    text = re.sub(r'<(br|p|div|h[1-6]|li|tr)[^>]*>', '\n', html_content, flags=re.IGNORECASE)
    # Strip all remaining tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Decode HTML entities
    text = html.unescape(text)
    # Clean up whitespace
    lines = [line.strip() for line in text.splitlines()]
    return '\n'.join(line for line in lines if line)

def sanitize_filename(name):
    # Keep alphanumeric, hyphen, underscore
    clean = re.sub(r'[^a-zA-Z0-9_\-]', '_', name)
    clean = re.sub(r'_+', '_', clean).strip('_')
    return clean[:100]

def fetch_all_categories(session):
    print("Fetching categories...")
    categories = {}
    page = 1
    while True:
        url = f"{BASE_URL}/wp-json/wp/v2/categories?per_page=100&page={page}"
        res = session.get(url, timeout=30)
        if res.status_code != 200:
            break
        items = res.json()
        if not items:
            break
        for item in items:
            categories[item["id"]] = html.unescape(item.get("name", ""))
        page += 1
    print(f"Loaded {len(categories)} categories.")
    return categories

def fetch_all_users(session):
    print("Fetching authors...")
    users = {}
    page = 1
    while True:
        url = f"{BASE_URL}/wp-json/wp/v2/users?per_page=100&page={page}"
        res = session.get(url, timeout=30)
        if res.status_code != 200:
            break
        items = res.json()
        if not items:
            break
        for item in items:
            users[item["id"]] = html.unescape(item.get("name", ""))
        page += 1
    print(f"Loaded {len(users)} authors.")
    return users

def extract_featured_image(post):
    yoast = post.get("yoast_head_json") or {}
    og_images = yoast.get("og_image") or []
    if isinstance(og_images, list) and len(og_images) > 0 and isinstance(og_images[0], dict):
        return og_images[0].get("url", "")
    return ""

def process_and_save_post(post, categories_map, users_map):
    post_id = post["id"]
    slug = post.get("slug", "")
    safe_slug = sanitize_filename(slug)
    filename = f"{post_id}_{safe_slug}.json" if safe_slug else f"{post_id}.json"
    filepath = OUTPUT_DIR / filename

    raw_title = post.get("title", {}).get("rendered", "")
    clean_title = html.unescape(re.sub(r'<[^>]+>', '', raw_title)).strip()

    raw_excerpt = post.get("excerpt", {}).get("rendered", "")
    clean_excerpt = html.unescape(re.sub(r'<[^>]+>', '', raw_excerpt)).strip()

    content_html = post.get("content", {}).get("rendered", "")
    content_text = html_to_text(content_html)

    author_id = post.get("author")
    author_name = users_map.get(author_id, "")

    cat_ids = post.get("categories", [])
    post_categories = [
        {"id": cid, "name": categories_map.get(cid, "")}
        for cid in cat_ids
    ]

    featured_image = extract_featured_image(post)

    data = {
        "id": post_id,
        "title": clean_title,
        "slug": slug,
        "url": post.get("link", ""),
        "date": post.get("date", ""),
        "date_gmt": post.get("date_gmt", ""),
        "modified": post.get("modified", ""),
        "modified_gmt": post.get("modified_gmt", ""),
        "author": {
            "id": author_id,
            "name": author_name
        },
        "categories": post_categories,
        "tags": post.get("tags", []),
        "featured_image": featured_image,
        "excerpt": clean_excerpt,
        "content_html": content_html,
        "content_text": content_text,
        "raw": post
    }

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return post_id

def fetch_page(page_num, categories_map, users_map):
    session = get_session()
    url = f"{BASE_URL}/wp-json/wp/v2/posts?per_page={PER_PAGE}&page={page_num}"
    for attempt in range(1, 6):
        try:
            res = session.get(url, timeout=45)
            if res.status_code == 200:
                posts = res.json()
                saved_count = 0
                for post in posts:
                    process_and_save_post(post, categories_map, users_map)
                    saved_count += 1
                return page_num, saved_count, None
            elif res.status_code == 400:
                # Page out of bounds
                return page_num, 0, None
            else:
                time.sleep(attempt * 2)
        except Exception as e:
            if attempt == 5:
                return page_num, 0, str(e)
            time.sleep(attempt * 2)
    return page_num, 0, "Max retries exceeded"

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    session = get_session()

    print("Checking total posts and pages...")
    resp = session.get(f"{BASE_URL}/wp-json/wp/v2/posts?per_page={PER_PAGE}&page=1", timeout=30)
    if resp.status_code != 200:
        print(f"Failed to connect to API: status {resp.status_code}")
        sys.exit(1)

    total_posts = int(resp.headers.get("X-WP-Total", 0))
    total_pages = int(resp.headers.get("X-WP-TotalPages", 0))
    print(f"Total posts: {total_posts}, Total pages: {total_pages} (per_page={PER_PAGE})")

    categories_map = fetch_all_categories(session)
    users_map = fetch_all_users(session)

    start_time = time.time()
    completed_pages = 0
    total_saved = 0
    errors = []

    print(f"Starting scraping with {MAX_WORKERS} workers...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_page = {
            executor.submit(fetch_page, page, categories_map, users_map): page
            for page in range(1, total_pages + 1)
        }

        for future in as_completed(future_to_page):
            page_num = future_to_page[future]
            try:
                page, saved, err = future.result()
                completed_pages += 1
                if err:
                    errors.append((page, err))
                    print(f"[{completed_pages}/{total_pages}] Page {page} ERROR: {err}", flush=True)
                else:
                    total_saved += saved
                    elapsed = time.time() - start_time
                    print(f"[{completed_pages}/{total_pages}] Page {page} completed (+{saved} posts). Total saved: {total_saved} ({elapsed:.1f}s)", flush=True)
            except Exception as e:
                completed_pages += 1
                errors.append((page_num, str(e)))
                print(f"[{completed_pages}/{total_pages}] Page {page_num} EXCEPTION: {e}", flush=True)

    elapsed_total = time.time() - start_time
    print("\n" + "="*50)
    print(f"Scraping completed in {elapsed_total:.2f} seconds.")
    print(f"Total posts saved: {total_saved} / {total_posts}")

    if errors:
        print(f"Encountered errors on {len(errors)} pages:")
        for p, err in errors:
            print(f"  Page {p}: {err}")
    else:
        print("All pages fetched successfully!")

    actual_files = len(list(OUTPUT_DIR.glob("*.json")))
    print(f"Files currently in {OUTPUT_DIR}: {actual_files}")
    print("="*50)

if __name__ == "__main__":
    main()
