<?php
// Deskripsi: SoundCloud All User Tracks Scraper
// Contoh: {"user": "jahseh-onfroy"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR

header('Content-Type: application/json; charset=utf-8');
set_time_limit(120);

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

$user = $_GET['user'] ?? '';

if (empty($user)) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'Parameter user wajib diisi'
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

define('CLIENT_ID', 'KKzJxmw11tYpCs6T24P4uUYhqmjalG6M');

function curlGet($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
        'Accept: application/json'
    ]);
    return curl_exec($ch);
}

// Resolve user
$resolveUrl = 'https://api-mobi.soundcloud.com/resolve?url=https://soundcloud.com/' . $user . '&client_id=' . CLIENT_ID;
$userData = json_decode(curlGet($resolveUrl), true);

if (!$userData || empty($userData['id'])) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'User tidak ditemukan'
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$userId = $userData['id'];
$allTracks = [];
$offset = 0;
$limit = 50;
$hasMore = true;

// Loop sampai semua track keambil
while ($hasMore) {
    $tracksUrl = 'https://api-mobi.soundcloud.com/users/' . $userId . '/tracks?limit=' . $limit . '&offset=' . $offset . '&client_id=' . CLIENT_ID;
    $response = curlGet($tracksUrl);
    $data = json_decode($response, true);
    
    $collection = $data['collection'] ?? [];
    
    if (empty($collection)) {
        $hasMore = false;
        break;
    }
    
    foreach ($collection as $track) {
        $allTracks[] = [
            'id' => $track['id'] ?? '',
            'title' => $track['title'] ?? '',
            'url' => $track['permalink_url'] ?? '',
            'artwork' => $track['artwork_url'] ?? '',
            'duration' => round(($track['duration'] ?? 0) / 1000, 1) . 's',
            'plays' => $track['playback_count'] ?? 0,
            'likes' => $track['likes_count'] ?? 0,
            'created_at' => $track['created_at'] ?? '',
            'genre' => $track['genre'] ?? ''
        ];
    }
    
    $offset += $limit;
    
    // Berhenti kalau udah ga ada next_href
    if (empty($data['next_href'])) {
        $hasMore = false;
    }
    
    usleep(200000); // Delay 0.2 detik
}

echo json_encode(array_merge($credit, [
    'status' => true,
    'result' => [
        'user' => $user,
        'username' => $userData['username'] ?? '',
        'total_tracks' => $userData['track_count'] ?? 0,
        'fetched' => count($allTracks),
        'tracks' => $allTracks
    ]
]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>