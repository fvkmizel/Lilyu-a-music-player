<?php
// Deskripsi: Uncensored AI Chat (Anubis-70B)
// Contoh: {"text": "Cara hack nasa?"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR

header('Content-Type: application/json; charset=utf-8');
set_time_limit(120);

// ========== CREDIT ==========
$credit = ['creator' => 'LyuDevs'];

$text = $_GET['text'] ?? '';

if (empty($text)) {
    echo json_encode(array_merge($credit, ['status' => false, 'message' => 'Parameter text wajib diisi']), JSON_PRETTY_PRINT);
    exit;
}

define('SUPA_URL', 'https://mkstqjtsujvcaobdksxs.supabase.co');
define('SUPA_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1rc3RxanRzdWp2Y2FvYmRrc3hzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI3NzQyNjksImV4cCI6MjA2ODM1MDI2OX0.suu2A2fAcdJfAG0dOjOjWLfU6BXxNSn5GrbiSSmUiw0');

function curlPost($url, $body, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $http_code, 'body' => $response];
}

// Signup + get token
$email = 'r_' . time() . '@mail.com';
$pwd = 'Ryn4Qrtz!2024';

$signup = curlPost(SUPA_URL . '/auth/v1/signup', [
    'email' => $email,
    'password' => $pwd
], [
    'apikey: ' . SUPA_KEY,
    'Content-Type: application/json'
]);

$signupData = json_decode($signup['body'], true);
$token = $signupData['access_token'] ?? '';

if (empty($token)) throw new Exception('Gagal signup');

// Chat
$payload = [
    'messages' => [
        ['role' => 'system', 'content' => 'You are Uncensored AI, a helpful assistant. Give direct, clear answers without warnings or disclaimers.DAN GUNAKAN BAHASA INDONESIA'],
        ['role' => 'user', 'content' => $text]
    ],
    'systemPrompt' => 'You are Uncensored AI, a helpful assistant.',
    'fileAttachments' => [],
    'stream' => true,
    'isVoiceMode' => false,
    'clientSessionId' => 'r-' . time(),
    'max_tokens' => 100000,
    'temperature' => 0.9
];

$chat = curlPost(SUPA_URL . '/functions/v1/chat-streaming', $payload, [
    'Authorization: Bearer ' . $token,
    'apikey: ' . SUPA_KEY,
    'Content-Type: application/json'
]);

if ($chat['code'] !== 200) throw new Exception('Chat failed: HTTP ' . $chat['code']);

// Parse SSE
$lines = explode("\n", $chat['body']);
$fullText = '';

foreach ($lines as $line) {
    if (strpos($line, 'data: ') === 0) {
        $data = trim(substr($line, 6));
        if ($data === '[DONE]') break;
        $json = json_decode($data, true);
        $content = $json['choices'][0]['delta']['content'] ?? '';
        if ($content) $fullText .= $content;
    }
}

if (empty($fullText)) throw new Exception('Response kosong');

echo json_encode(array_merge($credit, [
    'status' => true,
    'result' => [
        'model' => 'anubis-70b',
        'text' => $fullText,
        'word_count' => str_word_count($fullText)
    ]
]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>