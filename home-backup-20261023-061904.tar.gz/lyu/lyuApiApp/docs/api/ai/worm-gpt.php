<?php
// Deskripsi: WormGPT AI Chat Wrapper
// Contoh: {"prompt": "cara hek nasa"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs', 
    'name' => 'LyuDevsGpt'
];

// ========== KEY YANG DIHAPUS DARI API TARGET ==========
$keysToRemove = [
    'creator', 'Creator', 'Creathor',
    'author', 'Author',
    'apikey', 'APIKey', 'api_key',
    'status', 'Status', 'name'// bakal diganti punya kita
];

$prompt = $_GET['prompt'] ?? '';

if (empty($prompt)) {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => 'Parameter prompt wajib diisi']
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$url = 'https://apiz.xhclinton.me/api/ai/wormgpt?apikey=toxicapis&prompt=' . urlencode($prompt);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36',
    'Accept: application/json'
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => 'CURL Error: ' . $error]
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($http_code === 200 && !empty($response)) {
    $data = json_decode($response, true);
    
    // Hapus key dari API target
    $data = removeKeysRecursive($data, $keysToRemove);
    
    echo json_encode(array_merge(
        $credit,
        [
            'status' => true,
            'result' => $data
        ]
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
} else {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => 'API request gagal (HTTP ' . $http_code . ')']
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}

function removeKeysRecursive($array, $keysToRemove) {
    if (!is_array($array)) return $array;
    
    foreach ($keysToRemove as $key) {
        unset($array[$key]);
    }
    
    foreach ($array as &$value) {
        if (is_array($value)) {
            $value = removeKeysRecursive($value, $keysToRemove);
        }
    }
    
    return $array;
}
?>