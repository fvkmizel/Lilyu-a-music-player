<?php
// Deskripsi: Suno AI Music Downloader (Alias Usesuno)
// Contoh: {"url": "https://suno.com/song/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00", "format": "both", "action": "info", "apikey": "lyu"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param url URL lagu Suno (https://suno.com/song/<id>, https://suno.com/s/<token>) atau UUID
// @param format (both|mp3|mp4) Format media yang diinginkan
// @param action (info|download) Mode output (info metadata atau direct download file)
// @param apikey Kunci API Lyu (default: lyu)

$url = $_GET['url'] ?? '';
$format = $_GET['format'] ?? 'both';
$action = $_GET['action'] ?? 'info';
$apikey = $_GET['apikey'] ?? 'lyu';

require_once __DIR__ . '/usesuno.php';
