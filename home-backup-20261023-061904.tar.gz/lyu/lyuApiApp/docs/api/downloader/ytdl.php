<?php
// Deskripsi: YouTube Downloader (MP3/MP4)
// Contoh: {"url": "https://youtu.be/n7IUUho7s9M", "type": "mp4"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param type (mp4|mp3) Tipe download

header('Content-Type: application/json; charset=utf-8');
set_time_limit(120);

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

$url = $_GET['url'] ?? '';
$type = $_GET['type'] ?? 'mp4';

$allowedTypes = ['mp4', 'mp3'];
if (!in_array($type, $allowedTypes)) $type = 'mp4';

if (empty($url)) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'Parameter url wajib diisi'
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

define('AUTH', '20250901majwlqo');

function curlPost($url, $body, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($body) ? http_build_query($body) : $body);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

try {
    $data = curlPost('https://api.vidssave.com/api/contentsite_api/media/parse', [
        'auth' => AUTH,
        'domain' => 'api-ak.vidssave.com',
        'origin' => 'source',
        'link' => $url
    ], [
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0'
    ]);
    
    if (!($data['status'] ?? false) || empty($data['data'])) {
        throw new Exception($data['message'] ?? 'Gagal get video info');
    }
    
    $info = $data['data'];
    $resources = $info['resources'] ?? [];
    
    $selected = null;
    
    if ($type === 'mp3') {
        // Cari audio apapun
        foreach ($resources as $r) {
            if (($r['type'] ?? '') === 'audio') {
                $selected = $r;
                break;
            }
        }
        // Fallback: ambil video kualitas rendah
        if (!$selected) {
            foreach ($resources as $r) {
                if (($r['type'] ?? '') === 'video' && ($r['quality'] ?? '') === '360P') {
                    $selected = $r;
                    break;
                }
            }
        }
        if (!$selected) $selected = $resources[0] ?? null;
    } else {
        foreach ($resources as $r) {
            if (($r['type'] ?? '') === 'video' && ($r['format'] ?? '') === 'MP4' && ($r['quality'] ?? '') === '480P') {
                $selected = $r;
                break;
            }
        }
        if (!$selected) {
            foreach ($resources as $r) {
                if (($r['type'] ?? '') === 'video' && ($r['format'] ?? '') === 'MP4') {
                    $selected = $r;
                    break;
                }
            }
        }
    }
    
    if (!$selected || empty($selected['download_url'])) {
        throw new Exception('No resource found');
    }
    
    $downloadUrl = $selected['download_url'];
    $size = ($selected['size'] ?? 0) / 1024 / 1024;
    $quality = $selected['quality'] ?? 'Unknown';
    $title = $info['title'] ?? 'YouTube Video';
    
    echo json_encode(array_merge($credit, [
        'status' => true,
        'result' => [
            'title' => $title,
            'download_url' => $downloadUrl,
            'type' => $type,
            'size' => round($size, 2) . ' MB',
            'quality' => $quality
        ]
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    
} catch (Exception $e) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => $e->getMessage()
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
?>