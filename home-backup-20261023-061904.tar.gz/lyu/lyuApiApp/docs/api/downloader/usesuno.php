<?php
// Deskripsi: Suno AI Music Downloader (MP3, MP4 & Full Metadata)
// Contoh: {"url": "https://suno.com/song/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00", "format": "both", "action": "info", "apikey": "lyu"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param url URL lagu Suno (https://suno.com/song/<id>, https://suno.com/s/<token>) atau UUID
// @param format (both|mp3|mp4) Format media yang diinginkan
// @param action (info|download) Mode output (info metadata atau direct download file)
// @param apikey Kunci API Lyu (default: lyu)

header('Content-Type: application/json; charset=utf-8');
set_time_limit(60);

// Load Security Module
require_once __DIR__ . '/../config/security.php';

// Rate Limiting: 60 requests per minute
lyu_check_rate_limit(60, 60);

// Parameters (supporting both GET and POST requests)
$isPost = (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST');
$postData = $isPost ? $_POST : [];
$url = lyu_sanitize_input($_GET['url'] ?? ($postData['url'] ?? ''));
$format = strtolower(lyu_sanitize_input($_GET['format'] ?? ($postData['format'] ?? 'both')));
$apikey = lyu_sanitize_input($_GET['apikey'] ?? ($postData['apikey'] ?? ''));
$action = strtolower(lyu_sanitize_input($_GET['action'] ?? ($postData['action'] ?? 'info')));

// Verify API Key
lyu_verify_apikey(true);

$credit = ['creator' => 'LyuDevs'];

if (empty($url)) {
    echo json_encode(array_merge($credit, [
        'status'  => false,
        'message' => 'Parameter "url" wajib diisi. Contoh: https://suno.com/song/<uuid> atau https://suno.com/s/<token>'
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// UUID pattern
$uuidRegex = '/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i';

/**
 * Resolve input into valid Suno Song UUID
 */
function resolveSunoSongId(string $input): string {
    global $uuidRegex;

    // Check direct UUID
    if (preg_match($uuidRegex, $input, $m)) {
        return strtolower($m[0]);
    }

    // Check short link: suno.com/s/<token>
    if (preg_match('/suno\.com\/s\/([A-Za-z0-9_-]+)/i', $input, $shortMatch)) {
        $shortUrl = 'https://suno.com/s/' . $shortMatch[1];
        $ch = curl_init($shortUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        ]);
        $html = curl_exec($ch);
        $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);

        if (preg_match($uuidRegex, $finalUrl, $m)) {
            return strtolower($m[0]);
        }
        if (preg_match($uuidRegex, $html, $m)) {
            return strtolower($m[0]);
        }
        throw new Exception('Gagal mendapatkan ID lagu dari short link Suno.');
    }

    // SSRF Check if an external URL was passed
    if (filter_var($input, FILTER_VALIDATE_URL)) {
        $host = parse_url($input, PHP_URL_HOST);
        if (!preg_match('/(^|\.)suno\.(com|ai)$/i', (string)$host)) {
            throw new Exception('Domain tidak diizinkan. Hanya URL suno.com atau suno.ai yang valid.');
        }
    }

    throw new Exception('Format URL Suno tidak valid. Masukkan URL suno.com/song/<id>, suno.com/s/<token>, atau UUID.');
}

/**
 * Extract Next.js payload chunks without PCRE backtrack limits
 */
function extractNextFlightChunks(string $html): string {
    $chunks = [];
    $offset = 0;
    $target = 'self.__next_f.push([';
    $htmlLen = strlen($html);

    while (($p = strpos($html, $target, $offset)) !== false) {
        $pStart = strpos($html, '"', $p);
        if ($pStart === false) break;

        $i = $pStart + 1;
        $escaped = false;
        $foundEnd = false;

        while ($i < $htmlLen) {
            $char = $html[$i];
            if ($escaped) {
                $escaped = false;
            } elseif ($char === '\\') {
                $escaped = true;
            } elseif ($char === '"') {
                $foundEnd = true;
                break;
            }
            $i++;
        }

        if ($foundEnd) {
            $strContent = substr($html, $pStart + 1, $i - ($pStart + 1));
            $decoded = json_decode('"' . $strContent . '"');
            $chunks[] = ($decoded !== null) ? $decoded : $strContent;
            $offset = $i + 1;
        } else {
            $offset = $pStart + 1;
        }
    }

    return implode('', $chunks);
}

try {
    $songId = resolveSunoSongId($url);
    $songPageUrl = 'https://suno.com/song/' . $songId;

    // Fetch song page HTML
    $ch = curl_init($songPageUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9'
        ]
    ]);
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 404 || empty($html)) {
        throw new Exception("Lagu Suno dengan ID {$songId} tidak ditemukan (HTTP {$httpCode}).");
    }

    $payload = extractNextFlightChunks($html);
    $clipData = null;

    $needle = '"id":"' . $songId . '"';
    $pos = strpos($payload, $needle);
    if ($pos !== false) {
        $start = strrpos(substr($payload, 0, $pos), '{');
        if ($start !== false) {
            $depth = 0;
            $end = -1;
            $len = strlen($payload);
            for ($i = $start; $i < $len; $i++) {
                $c = $payload[$i];
                if ($c === '{') $depth++;
                elseif ($c === '}') {
                    $depth--;
                    if ($depth === 0) {
                        $end = $i + 1;
                        break;
                    }
                }
            }
            if ($end !== -1) {
                $jsonStr = substr($payload, $start, $end - $start);
                $clipData = json_decode($jsonStr, true);
            }
        }
    }

    // Title & Artist Fallbacks
    $title = $clipData['title'] ?? '';
    if (empty($title) && preg_match('/<title>([^<]+)<\/title>/i', $html, $tm)) {
        $rawTitle = preg_replace('/\s*\|\s*Suno\s*$/i', '', trim($tm[1]));
        if (str_contains($rawTitle, ' by ')) {
            $parts = explode(' by ', $rawTitle, 2);
            $title = trim($parts[0]);
        } else {
            $title = $rawTitle;
        }
    }
    if (empty($title)) {
        $title = 'Suno Song ' . substr($songId, 0, 8);
    }

    $artist = $clipData['display_name'] ?? $clipData['handle'] ?? 'Suno Artist';
    $handle = $clipData['handle'] ?? '';
    $duration = (int)round($clipData['metadata']['duration'] ?? 0);
    $tags = $clipData['metadata']['tags'] ?? $clipData['display_tags'] ?? '';
    $prompt = $clipData['metadata']['prompt'] ?? $clipData['caption'] ?? '';
    $model = $clipData['model_name'] ?? $clipData['major_model_version'] ?? 'v3/v4';
    $createdAt = $clipData['created_at'] ?? date('c');

    // Media URLs
    $mp3Url = "https://cdn1.suno.ai/{$songId}.mp3";
    $mp4Url = $clipData['video_url'] ?? "https://cdn1.suno.ai/{$songId}.mp4";
    $imageUrl = $clipData['image_large_url'] ?? $clipData['image_url'] ?? "https://cdn2.suno.ai/image_{$songId}.jpeg";

    $m4aUrl = null;
    if (!empty($clipData['media_urls']) && is_array($clipData['media_urls'])) {
        foreach ($clipData['media_urls'] as $m) {
            if (!empty($m['url']) && (str_ends_with($m['url'], '.m4a') || str_contains($m['url'], '/clip/'))) {
                $m4aUrl = $m['url'];
                break;
            }
        }
    }

    // Direct stream download mode
    if ($action === 'download') {
        $streamUrl = ($format === 'mp4') ? $mp4Url : $mp3Url;
        $safeName = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', "{$title} - {$artist}") . '.' . ($format === 'mp4' ? 'mp4' : 'mp3');
        $mimeType = ($format === 'mp4') ? 'video/mp4' : 'audio/mpeg';

        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: attachment; filename="' . rawurlencode($safeName) . '"');
        readfile($streamUrl);
        exit;
    }

    // Choose primary download link according to requested format
    $primaryDownload = $mp3Url;
    if ($format === 'mp4') {
        $primaryDownload = $mp4Url;
    }

    $result = [
        'id'            => $songId,
        'title'         => trim($title),
        'artist'        => trim($artist),
        'handle'        => trim($handle),
        'duration'      => $duration,
        'duration_fmt'  => sprintf('%02d:%02d', floor($duration / 60), $duration % 60),
        'tags'          => $tags,
        'prompt'        => $prompt,
        'model'         => $model,
        'created_at'    => $createdAt,
        'stats'         => [
            'play_count'   => (int)($clipData['play_count'] ?? 0),
            'upvote_count' => (int)($clipData['upvote_count'] ?? 0),
            'comments'     => (int)($clipData['comment_count'] ?? 0)
        ],
        'thumbnail'     => $imageUrl,
        'download_url'  => $primaryDownload,
        'media'         => [
            'mp3' => $mp3Url,
            'mp4' => $mp4Url,
            'm4a' => $m4aUrl
        ]
    ];

    echo json_encode(array_merge($credit, [
        'status' => true,
        'result' => $result
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(array_merge($credit, [
        'status'  => false,
        'message' => $e->getMessage()
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
