<?php
// Deskripsi: LyuDevs API - YouTube Play Audio Premium MP3 Stream
// Contoh: {"q": ""}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param q Judul Lagu / Query YouTube

$query = $_GET['q'] ?? 'mienteme';

if (empty($query)) {
    header('Content-Type: application/json');
    echo json_encode(['status' => false, 'creator' => 'LyuDevs', 'message' => 'Parameter q wajib diisi']);
    exit;
}

// ========== CREDIT ==========
$credit = ['creator' => 'LyuDevs'];
set_time_limit(60);

// Fetch dari API upstream
$apiUrl = 'https://api.lexcode.biz.id/api/dwn/ytplay?q=' . urlencode($query);

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT => 40,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149.0.0.0 Safari/537.36',
]);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (!$data || (!empty($data['status']) && $data['status'] === false)) {
    header('Content-Type: application/json');
    echo json_encode(['status' => false, 'creator' => 'LyuDevs', 'message' => 'Gagal fetch audio']);
    exit;
}

// Cari URL download
$result = $data['result'] ?? $data['data'] ?? $data;
$audioUrl = '';

// Cari URL audio dari response
function findAudioUrl($arr) {
    if (!is_array($arr)) return '';
    foreach ($arr as $key => $val) {
        if (is_string($val) && (stripos($val, '.mp3') !== false || stripos($val, 'audio') !== false) && filter_var($val, FILTER_VALIDATE_URL)) {
            return $val;
        }
        if (is_array($val)) {
            $found = findAudioUrl($val);
            if ($found) return $found;
        }
    }
    return '';
}

$audioUrl = findAudioUrl($result);

// Fallback: coba ambil dari key umum
if (empty($audioUrl)) {
    $audioUrl = $result['download'] ?? $result['url'] ?? $result['audio'] ?? $result['audio_url'] ?? $result['link'] ?? '';
}

if (empty($audioUrl) || !filter_var($audioUrl, FILTER_VALIDATE_URL)) {
    header('Content-Type: application/json');
    echo json_encode(['status' => false, 'creator' => 'LyuDevs', 'message' => 'URL audio tidak ditemukan']);
    exit;
}

// Stream MP3 langsung
header('Content-Type: audio/mpeg');
header('Content-Disposition: inline; filename="' . urlencode($query) . '.mp3"');
header('Accept-Ranges: bytes');

$ch = curl_init($audioUrl);
curl_setopt_array($ch, [
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    CURLOPT_WRITEFUNCTION => function($ch, $data) {
        echo $data;
        return strlen($data);
    },
]);
curl_exec($ch);
curl_close($ch);
?>