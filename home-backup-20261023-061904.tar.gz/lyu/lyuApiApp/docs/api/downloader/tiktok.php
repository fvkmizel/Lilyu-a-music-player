<?php
// Deskripsi: TikTok Downloader (via ssstik.io)
// Contoh: {"url":"https://vt.tiktok.com/ZSHfmQhYe/"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param url URL Video TikTok

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

set_time_limit(30);

$url = $_GET['url'] ?? '';

if (!$url) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'Masukkan URL TikTok'
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function generateTT() {
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $result = '';
    for ($i = 0; $i < 8; $i++) {
        $result .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $result;
}

function extractData($html) {
    $data = [];
    
    // Video tanpa watermark
    if (preg_match('/href="(https:\/\/tikcdn\.io\/ssstik\/\d+[^"]+)"\s+class="[^"]*without_watermark[^"]*vignette_active[^"]*"/', $html, $match)) {
        $data['video_tanpa_watermark'] = $match[1];
    }
    
    // Audio MP3
    if (preg_match('/href="(https:\/\/tikcdn\.io\/ssstik\/m\/[^"]+)"\s+class="[^"]*music[^"]*"/', $html, $match)) {
        $data['audio_mp3'] = $match[1];
    }
    
    // Caption
    if (preg_match('/<p class="maintext">([^<]+)<\/p>/', $html, $match)) {
        $data['caption'] = $match[1];
    }
    
    // Author
    if (preg_match('/<h2>([^<]+)<\/h2>/', $html, $match)) {
        $data['author'] = $match[1];
    }
    
    return $data;
}

try {
    $tt = generateTT();
    
    $ch = curl_init('https://ssstik.io/abc?url=dl');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'id' => $url,
            'locale' => 'en',
            'tt' => $tt
        ]),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            'Type-Content: application/x-www-form-urlencoded',
            'HX-Request: true',
            'HX-Trigger: _gcaptcha_pt',
            'HX-Target: target',
            'HX-Current-URL: https://ssstik.io/en',
            'User-Agent: Mozilla/5.0 (Linux; Android 11; Termux) AppleWebKit/537.36',
            'Referer: https://ssstik.io/en'
        ]
    ]);
    
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200 || !$html) {
        throw new Exception('Gagal fetch ssstik.io');
    }
    
    $hasil = extractData($html);
    
    if (empty($hasil['video_tanpa_watermark'])) {
        throw new Exception('Gagal mendapatkan link. Cek URL atau coba lagi.');
    }
    
    echo json_encode(array_merge($credit, [
        'status' => true,
        'data' => $hasil
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => $e->getMessage()
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
?>