<?php
// Deskripsi: IP Lookup Info
// Contoh: {"ip": "1.1.1.1"}

/**
 * NANAS MAH BOCIL — IP Lookup
 * Creator: LyuDevs
 * * Usage: ipinfo.php?ip=1.1.1.1
 * Docs: https://lo-domain.com/docs
 */

// --------------------------
// SECURITY & CORS HEADERS
// --------------------------
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Origin");
header("Access-Control-Max-Age: 86400");
header("Access-Control-Allow-Credentials: true");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: no-referrer-when-downgrade");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --------------------------
// CONFIG
// --------------------------
$BASE_URL = "https://apiz.xhclinton.me/api/tools/ipinfo"; 
$APIKEY   = "toxicapis"; 

$OVERRIDES = [
    "creator"     => "LyuDevs",
    "author"      => "LyuDevs",
    "attribution" => "LyuDevs"
];

// --------------------------
// AMBIL PARAMETER & VALIDASI
// --------------------------
$ip = $_GET['ip'] ?? '';

if (empty($ip)) {
    header("Content-Type: application/json; charset=UTF-8");
    die(json_encode(array_merge([
        "status" => false,
        "message" => "parameter ip wajib diisi"
    ], $OVERRIDES), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
}

// Susun query parameter ke API tujuan secara aman
$queryParams = [
    'apikey' => $APIKEY,
    'ip'     => $ip
];

$finalUrl = $BASE_URL . '?' . http_build_query($queryParams);

// --------------------------
// CURL
// --------------------------
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $finalUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 60,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HEADER         => true,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    CURLOPT_HTTPHEADER     => [
        'Accept: application/json',
        'Accept-Language: id-ID,id;q=0.9',
        'Connection: keep-alive',
    ],
]);

$raw         = curl_exec($ch);
$curlError   = curl_error($ch);
$httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$headerSize  = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'application/json';
curl_close($ch);

// --------------------------
// ERROR HANDLING
// --------------------------
if (!$raw || $curlError) {
    http_response_code(503);
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode(array_merge([
        "status" => false,
        "code"   => 503,
        "msg"    => "❌ Service Unavailable: " . ($curlError ?: "no response")
    ], $OVERRIDES), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

if ($httpCode >= 400) {
    http_response_code($httpCode);
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode(array_merge([
        "status" => false,
        "code"   => $httpCode,
        "msg"    => "❌ Upstream Error (HTTP {$httpCode})"
    ], $OVERRIDES), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

// --------------------------
// OUTPUT JSON RESPONSES
// --------------------------
$body = substr($raw, $headerSize);

header("Content-Type: application/json; charset=UTF-8");
header("X-Response-Time: " . round(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"], 3) . "s");
header("X-Powered-By: NANAS MAH BOCIL v2.0");

$data = json_decode($body, true);
if ($data) {
    echo json_encode(array_merge($data, $OVERRIDES), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
} else {
    echo $body;
}
exit;
