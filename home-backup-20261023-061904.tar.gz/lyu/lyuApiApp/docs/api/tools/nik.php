<?php

$nik = $_GET['nik'] ?? '';

$url = "https://nik.zakiego.com/api/trpc/nik.read?batch=1";

$data = [
    0 => [
        "json" => [
            "nik" => $nik
        ]
    ]
];

$headers = [
    "Origin: https://nik.zakiego.com",
    "Referer: https://nik.zakiego.com/",
    "Content-Type: application/json",
    "User-Agent: Mozilla/5.0"
];

$ch = curl_init($url);

curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_POSTFIELDS => json_encode($data, JSON_FORCE_OBJECT)
]);

$response = curl_exec($ch);

curl_close($ch);

$res = json_decode($response, true);

$output = [
    "creator" => "LyuDevs",
    "success" => true,
    "result" => $res
];

header('Content-Type: application/json');

echo json_encode($output, JSON_PRETTY_PRINT);
?>