<?php
// Deskripsi: TikTok Like Booster
// Contoh: {"url": "https://vt.tiktok.com/ZSxGhy4pD/", "target": 50}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param target (10|20|30|50|100) Jumlah likes/views

header('Content-Type: application/json; charset=utf-8');
set_time_limit(120);

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

$tiktokUrl = $_GET['url'] ?? '';
$targetLikes = intval($_GET['target'] ?? 0);

$allowedTargets = [10, 20, 30, 50, 100];
if (!in_array($targetLikes, $allowedTargets)) $targetLikes = 50;

if (empty($tiktokUrl)) {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => 'Parameter url wajib diisi']
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

define('BASE_URL', 'https://tiksta.com/action/');

function sendRequest($tiktokUrl, $quantity, $token = '') {
    $data = http_build_query([
        'ns_action' => 'freetool_start',
        'freetool[id]' => 3,
        'freetool[token]' => $token,
        'freetool[process_item]' => $tiktokUrl,
        'freetool[quantity]' => $quantity
    ]);
    
    $ch = curl_init(BASE_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Accept: application/json, text/javascript, */*; q=0.01',
        'X-Requested-With: XMLHttpRequest',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

$maxPerDevice = 20;
$minPerDevice = 10;
$remaining = $targetLikes;
$devices = [];

while ($remaining > 0) {
    if ($remaining >= $maxPerDevice) {
        $devices[] = $maxPerDevice;
        $remaining -= $maxPerDevice;
    } elseif ($remaining >= $minPerDevice) {
        $devices[] = $remaining;
        $remaining = 0;
    } else {
        if (count($devices) > 0 && end($devices) < $maxPerDevice) {
            $devices[count($devices) - 1] += $remaining;
        } else {
            $devices[] = $remaining;
        }
        $remaining = 0;
    }
}

$success = 0;
$failed = 0;

foreach ($devices as $i => $qty) {
    $startRes = sendRequest($tiktokUrl, $qty, '');
    
    if (!($startRes['statu'] ?? false)) {
        $failed++;
        continue;
    }
    
    $token = $startRes['freetool_process_token'] ?? '';
    sendRequest($tiktokUrl, $qty, $token);
    $success++;
    
    usleep(500000);
}

echo json_encode(array_merge(
    $credit,
    [
        'status' => true,
        'result' => [
            'target' => $targetLikes,
            'sessions' => count($devices),
            'success' => $success,
            'failed' => $failed,
            'message' => "{$targetLikes} likes/views akan masuk dalam 5 menit"
        ]
    ]
), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>