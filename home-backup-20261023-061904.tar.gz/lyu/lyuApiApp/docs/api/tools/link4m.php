<?php
header('Content-Type: application/json');

$ts = bin2hex(random_bytes(12));
$cid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
$key = '5vpVLXyw';
$targetUrl = 'https://link4m.net/go/bvv0BX';

// Test 1: CF Solver buat dapetin cookies + bypass Cloudflare dulu
$cfSolve = json_decode(file_get_contents('https://cf-solver-renofc.my.id/api/solvebeta'), true);
// Atau pake curl
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://cf-solver-renofc.my.id/api/solvebeta',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode([
        'mode' => 'waf-session',
        'url' => $targetUrl
    ])
]);
$cfResult = json_decode(curl_exec($ch), true);
curl_close($ch);

// Test 2: Langsung client.js
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://s1.what-on.com/widget/client.js',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_HTTPHEADER => ['User-Agent: Mozilla/5.0 (Linux; Android 10; K)'],
    CURLOPT_POSTFIELDS => http_build_query([
        'traffic_session' => $ts, 'key' => $key,
        'screen' => '363 x 785', 'browser' => 'Chrome',
        'browserVersion' => '149.0.0.0', 'browserMajorVersion' => '149',
        'mobile' => 'true', 'os' => 'Android', 'osVersion' => '10',
        'cookies' => 'true', 'flashVersion' => 'no check', 'lang' => 'id-ID',
        'client_id' => $cid, 'pathname' => '/',
        'href' => $targetUrl, 'hostname' => 'link4m.net'
    ])
]);
$js = curl_exec($ch);
curl_close($ch);

// Extract code
preg_match('/"([a-f0-9]{32})"/', $js, $m);
$code = $m[1] ?? 'NOT FOUND';

// Test 3: get_quest_code
$hash = hash('sha256', $ts . $code . $key . time());
$params = http_build_query([
    'id' => $ts, 'code' => $code, 'traffic_session' => $ts, 'key' => $key,
    'screen' => '363 x 785', 'browser' => 'Chrome', 'browserVersion' => '149.0.0.0',
    'browserMajorVersion' => '149', 'mobile' => 'true', 'os' => 'Android', 'osVersion' => '10',
    'cookies' => 'true', 'flashVersion' => 'no check', 'lang' => 'id-ID',
    'client_id' => $cid, 'pathname' => '/', 'href' => $targetUrl, 'hostname' => 'link4m.net',
    'request' => $hash
]);

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => 'https://s1.what-on.com/widget/get_quest_code.html?' . $params,
    CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 10,
    CURLOPT_HTTPHEADER => ['User-Agent: Mozilla/5.0 (Linux; Android 10; K)']
]);
$step2 = json_decode(curl_exec($ch), true);
curl_close($ch);

echo json_encode([
    'cf_solver' => $cfResult,
    'js_length' => strlen($js),
    'code' => $code,
    'step2' => $step2,
    'password' => $step2['html'] ?? 'NOT FOUND',
], JSON_PRETTY_PRINT);