<?php
// Deskripsi: izen.lol Link Bypasser
// Contoh: {"url":"https://izen.lol/xxxx"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param url URL izen.lol

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = ['creator' => 'LyuDevs'];
set_time_limit(30);

$url = $_GET['url'] ?? '';

if (!$url) {
    $data = array_merge($credit, ['status' => false, 'message' => 'Parameter url diperlukan']);
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $data = removeKeysRecursive($data, $keysToRemove);
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

define('SOLVER', 'https://cf-solver-renofc.my.id/api/solvebeta');
define('IZEN', 'https://izen.lol/api/bypass');
define('TARGET', 'https://izen.lol');
define('SITEKEY', '0x4AAAAAADNEi_2N24gpQqY0');

function curlPost($url, $data, $headers = []) {
    $ch = curl_init($url);
    $defaultHeaders = ['Content-Type: application/json', 'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data), CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers)
    ]);
    $res = curl_exec($ch); curl_close($ch);
    return json_decode($res, true);
}

// Step 1: Solve Turnstile
$captcha = curlPost(SOLVER, ['mode' => 'turnstile-min', 'url' => TARGET, 'siteKey' => SITEKEY]);
$token = $captcha['token']['result']['token'] ?? null;

if (!$token) {
    echo json_encode(array_merge($credit, ['status' => false, 'message' => 'Gagal solve captcha']), JSON_PRETTY_PRINT);
    exit;
}

// Step 2: Bypass
$result = curlPost(IZEN, ['url' => $url, 'captchaToken' => $token], ['Referer: ' . TARGET . '/']);

$data = array_merge($credit, [
    'status' => !empty($result['result']),
    'result' => $result
]);

$keysToRemove = ['creator', 'Creator', 'author', 'Author'];
$data = removeKeysRecursive($data, $keysToRemove);

echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

function removeKeysRecursive($array, $keysToRemove) {
    if (!is_array($array)) return $array;
    foreach ($keysToRemove as $key) unset($array[$key]);
    foreach ($array as &$value) {
        if (is_array($value)) $value = removeKeysRecursive($value, $keysToRemove);
    }
    return $array;
}
?>