<?php
/**
 * Lyu-Api Security Module
 * Provides Rate Limiting, API Key Verification, SSRF Protection, and Security Headers.
 */

if (!defined('LYU_SEC_INIT')) {
    define('LYU_SEC_INIT', true);
}

// 1. Send Security Headers
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-API-KEY');
}

// Handle preflight OPTIONS
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// 2. Allowed API Keys
define('LYU_VALID_API_KEYS', [
    'lyu',
    'lyudevs',
    'lyu-vip',
    'lyu-free',
    'admin'
]);

/**
 * Get Client IP Address safely
 */
function lyu_get_client_ip(): string {
    $headers = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR'
    ];
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ipList = explode(',', $_SERVER[$header]);
            $ip = trim($ipList[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '127.0.0.1';
}

/**
 * Rate Limiter per Client IP
 * @param int $maxRequests Max requests allowed within the window
 * @param int $windowSeconds Window in seconds (default 60s)
 */
function lyu_check_rate_limit(int $maxRequests = 60, int $windowSeconds = 60): bool {
    $ip = lyu_get_client_ip();
    $cacheDir = __DIR__ . '/../cache/ratelimit';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0755, true);
    }

    $ipHash = md5($ip);
    $file = $cacheDir . '/' . $ipHash . '.json';
    $now = time();

    $data = ['start' => $now, 'count' => 0];
    if (file_exists($file)) {
        $content = @file_get_contents($file);
        if ($content) {
            $parsed = json_decode($content, true);
            if (is_array($parsed) && isset($parsed['start'], $parsed['count'])) {
                if ($now - $parsed['start'] < $windowSeconds) {
                    $data = $parsed;
                }
            }
        }
    }

    $data['count']++;
    @file_put_contents($file, json_encode($data), LOCK_EX);

    if ($data['count'] > $maxRequests) {
        http_response_code(429);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'creator' => 'LyuDevs',
            'status'  => false,
            'message' => 'Rate limit tercapai. Maksimal ' . $maxRequests . ' request per ' . $windowSeconds . ' detik. Coba lagi beberapa saat.'
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    return true;
}

/**
 * Validate API Key from Request
 * Accepts key via ?apikey=, POST apikey, or Header X-API-KEY / Authorization Bearer
 */
function lyu_verify_apikey(bool $required = false): bool {
    $key = $_GET['apikey'] ?? $_GET['api_key'] ?? $_POST['apikey'] ?? $_POST['api_key'] ?? '';
    if (empty($key)) {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $key = $headers['X-API-KEY'] ?? $headers['x-api-key'] ?? '';
        if (empty($key) && !empty($headers['Authorization'])) {
            if (preg_match('/Bearer\s+(\S+)/i', $headers['Authorization'], $m)) {
                $key = $m[1];
            }
        }
    }

    $isValid = in_array(trim($key), LYU_VALID_API_KEYS, true);

    if ($required && !$isValid) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'creator' => 'LyuDevs',
            'status'  => false,
            'message' => empty($key) 
                ? 'Parameter "apikey" diperlukan untuk mengakses endpoint ini. Gunakan apikey="lyu" atau hubungi admin.' 
                : 'Apikey "' . htmlspecialchars($key) . '" tidak valid.'
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    return $isValid;
}

/**
 * SSRF Protection: verify if target URL is safe and public
 */
function lyu_is_safe_url(string $url): bool {
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }

    $parts = parse_url($url);
    if (!isset($parts['scheme'], $parts['host'])) {
        return false;
    }

    // Only allow HTTP/HTTPS
    if (!in_array(strtolower($parts['scheme']), ['http', 'https'], true)) {
        return false;
    }

    $host = strtolower($parts['host']);

    // Disallow loopback / local names
    if (in_array($host, ['localhost', '127.0.0.1', '::1', '0.0.0.0', 'broadcast'], true) ||
        str_ends_with($host, '.local') || str_ends_with($host, '.internal') || str_ends_with($host, '.lan')) {
        return false;
    }

    // Resolve IP address
    $ips = @dns_get_record($host, DNS_A + DNS_AAAA);
    $ipList = [];
    if (!empty($ips)) {
        foreach ($ips as $record) {
            if (!empty($record['ip'])) $ipList[] = $record['ip'];
            if (!empty($record['ipv6'])) $ipList[] = $record['ipv6'];
        }
    } else {
        $ip = gethostbyname($host);
        if ($ip !== $host) $ipList[] = $ip;
    }

    if (empty($ipList)) {
        return false;
    }

    // Check each resolved IP
    foreach ($ipList as $ip) {
        // FILTER_FLAG_NO_PRIV_RANGE: reject 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16
        // FILTER_FLAG_NO_RES_RANGE: reject 0.0.0.0/8, 169.254.0.0/16, etc.
        $flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
        if (!filter_var($ip, FILTER_VALIDATE_IP, $flags)) {
            return false;
        }
    }

    return true;
}

/**
 * Sanitize string input to prevent null byte attacks and malicious control characters
 */
function lyu_sanitize_input(string $str): string {
    return trim(str_replace("\0", '', $str));
}
