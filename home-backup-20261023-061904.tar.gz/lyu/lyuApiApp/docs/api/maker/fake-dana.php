<?php
// Deskripsi: Fake DANA Balance Generator
// Contoh: {"text":"150000"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param text Jumlah Saldo

header('Content-Type: image/png');

$credit = ['creator' => 'LyuDevs'];
set_time_limit(30);

$angka = $_GET['text'] ?? '150000';
if (!$angka) { header('Content-Type: application/json'); echo json_encode(array_merge($credit, ['status' => false, 'message' => 'Parameter text diperlukan']), JSON_PRETTY_PRINT); exit; }

$raw = (int)preg_replace('/[^\d]/', '', $angka);
$formatted = number_format($raw, 0, ',', '.');

// ==================== SHORTCUT ====================
$bgUrl = 'https://nanzzcode.my.id/cdn/dana.jpg';
$fontUrl = 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Font/f5803c-1772975107907.ttf';
$eyeIconUrl = 'https://nanzzcode.my.id/cdn/eye.png';

$textX1 = 184; $textY1 = 67; $textX2 = 244; $textY2 = 114;
$eyeX1 = 246; $eyeY1 = 70; $eyeX2 = 285; $eyeY2 = 104;

$fontSize = 40;
$textOffsetX = 0; $textOffsetY = 0;
$eyeOffsetX = 0; $eyeOffsetY = 0;
$iconGap = 5;
// ==================================================

function downloadBuffer($url) { $ch = curl_init(); curl_setopt_array($ch, [CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 30]); $res = curl_exec($ch); curl_close($ch); return $res; }

try {
    $bg = imagecreatefromstring(downloadBuffer($bgUrl));
    if (!$bg) throw new Exception('Gagal load background');
    
    $w = imagesx($bg); $h = imagesy($bg);
    $canvas = imagecreatetruecolor($w, $h);
    imagecopy($canvas, $bg, 0, 0, 0, 0, $w, $h);
    imagedestroy($bg);

    $fontFile = sys_get_temp_dir() . '/dana_' . uniqid() . '.ttf';
    file_put_contents($fontFile, downloadBuffer($fontUrl));

    $textCenterY = ($textY1 + $textY2) / 2;
    $iconW = $eyeX2 - $eyeX1; $iconH = $eyeY2 - $eyeY1;
    $white = imagecolorallocate($canvas, 255, 255, 255);

    $box = imagettfbbox($fontSize, 0, $fontFile, $formatted);
    $textW = abs($box[2] - $box[0]); $th = abs($box[7] - $box[1]);

    imagettftext($canvas, $fontSize, 0, $textX1 + $textOffsetX, (int)($textCenterY + $th/2 + $textOffsetY), $white, $fontFile, $formatted);

    $iconX = $textX1 + $textW + $iconGap + $eyeOffsetX;
    $iconY = $eyeY1 + $eyeOffsetY;
    
    $eyeImg = @imagecreatefromstring(downloadBuffer($eyeIconUrl));
    if ($eyeImg) {
        $eyeResized = imagecreatetruecolor($iconW, $iconH);
        imagealphablending($eyeResized, false); imagesavealpha($eyeResized, true);
        $trans = imagecolorallocatealpha($eyeResized, 0, 0, 0, 127);
        imagefill($eyeResized, 0, 0, $trans);
        imagecopyresampled($eyeResized, $eyeImg, 0, 0, 0, 0, $iconW, $iconH, imagesx($eyeImg), imagesy($eyeImg));
        imagecopy($canvas, $eyeResized, (int)$iconX, (int)$iconY, 0, 0, $iconW, $iconH);
        imagedestroy($eyeImg); imagedestroy($eyeResized);
    }

    @unlink($fontFile);
    imagepng($canvas);
    imagedestroy($canvas);

} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(array_merge($credit, ['status' => false, 'message' => $e->getMessage()]), JSON_PRETTY_PRINT);
}
?>