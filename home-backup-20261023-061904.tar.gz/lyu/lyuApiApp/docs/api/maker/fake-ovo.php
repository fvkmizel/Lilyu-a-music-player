<?php
// Deskripsi: Fake OVO Generator
// Contoh: {"text":"500000"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param text Jumlah Uang

header('Content-Type: image/png');

// ========== CREDIT ==========
$credit = ['creator' => 'LyuDevs'];
set_time_limit(30);

$amountInput = $_GET['text'] ?? $_GET['amount'] ?? $_GET['query'] ?? $_GET['q'] ?? '';

if (!$amountInput) {
    header('Content-Type: application/json');
    echo json_encode(array_merge($credit, ['status' => false, 'message' => 'Parameter text diperlukan']), JSON_PRETTY_PRINT);
    exit;
}

function formatAmount($input) {
    $digits = preg_replace('/[^\d]/', '', strval($input)) ?: '0';
    $numeric = min((int)$digits, 10000000);
    $normalized = ltrim(strval($numeric), '0') ?: '0';
    return number_format((float)$normalized, 0, ',', '.');
}

$imageUrl = 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Image/file_0000000078bc71fa87da5cf26dc6c008.jpeg';
$fontUrl = 'https://raw.githubusercontent.com/SaurusAraAra/mentahan/main/font/Poppins.ttf';

function downloadBuffer($url) {
    $ch = curl_init(); curl_setopt_array($ch, [CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 30]); 
    $res = curl_exec($ch); curl_close($ch); return $res;
}

try {
    $bgBuffer = downloadBuffer($imageUrl);
    $fontBuffer = downloadBuffer($fontUrl);
    if (!$bgBuffer || !$fontBuffer) throw new Exception('Gagal download asset');

    $bg = imagecreatefromstring($bgBuffer);
    if (!$bg) throw new Exception('Gagal load template');

    $width = imagesx($bg); $height = imagesy($bg);
    $canvas = imagecreatetruecolor($width, $height);
    imagecopy($canvas, $bg, 0, 0, 0, 0, $width, $height);
    imagedestroy($bg);

    $fontFile = sys_get_temp_dir() . '/ovo_' . uniqid() . '.ttf';
    file_put_contents($fontFile, $fontBuffer);

    $white = imagecolorallocate($canvas, 255, 255, 255);
    $amountText = formatAmount($amountInput);

    // "Rp" di x=61, y=368
    imagettftext($canvas, 20, 0, 61, 368, $white, $fontFile, 'Rp');
    // Nominal di x=94, y=371
    imagettftext($canvas, 28, 0, 94, 371, $white, $fontFile, $amountText);

    @unlink($fontFile);
    imagepng($canvas);
    imagedestroy($canvas);

} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(array_merge($credit, ['status' => false, 'message' => $e->getMessage()]), JSON_PRETTY_PRINT);
}
?>