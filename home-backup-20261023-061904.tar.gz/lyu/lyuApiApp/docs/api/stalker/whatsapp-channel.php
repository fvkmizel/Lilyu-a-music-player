<?php
// Deskripsi: WhatsApp Channel Info Scraper
// Contoh: {"url": "https://whatsapp.com/channel/0029Vb8cslf8aKvEpFOaMC0m"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

$url = $_GET['url'] ?? '';

if (empty($url)) {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => 'Parameter url wajib diisi']
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

function cleanText($text = "") {
    $text = str_replace("\r", "", $text);
    $text = preg_replace('/\n+/', "\n", $text);
    $text = preg_replace('/[ \t]+/', " ", $text);
    return trim($text);
}

try {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/139 Mobile Safari/537.36'
    ]);
    
    $html = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200 || empty($html)) {
        throw new Exception('Gagal fetch URL (HTTP ' . $http_code . ')');
    }
    
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    libxml_clear_errors();
    
    $xpath = new DOMXPath($dom);
    
    // Title
    $titleNode = $xpath->query('//title')->item(0);
    $rawTitle = $titleNode ? trim($titleNode->textContent) : '';
    
    // Description
    $descNode = $xpath->query('//meta[@name="description"]')->item(0);
    $rawDesc = $descNode ? $descNode->getAttribute('content') : '';
    
    // Image
    $imageNode = $xpath->query('//meta[@property="og:image"]')->item(0);
    $image = $imageNode ? $imageNode->getAttribute('content') : '';
    
    // Name (remove WhatsApp channel suffix)
    $name = preg_replace('/\s*-\s*WhatsApp channel/i', '', $rawTitle);
    $name = trim($name);
    
    // Clean description
    $desc = $rawDesc;
    $desc = preg_replace('/Follow\s+' . preg_quote($name, '/') . "'?s?\s+WhatsApp Channel\./i", '', $desc);
    $desc = preg_replace('/Join\s+\d+\s+followers?.*/i', '', $desc);
    $desc = cleanText($desc);
    
    echo json_encode(array_merge(
        $credit,
        [
            'status' => true,
            'result' => [
                'name' => $name,
                'desc' => $desc,
                'image' => $image
            ]
        ]
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    
} catch (Exception $e) {
    echo json_encode(array_merge(
        $credit,
        ['status' => false, 'message' => $e->getMessage()]
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
?>