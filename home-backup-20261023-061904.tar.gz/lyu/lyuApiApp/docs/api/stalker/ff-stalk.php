<?php
// Deskripsi: Free Fire Stalk
// Contoh: {"uid":"87980657"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param uid UID Free Fire

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = ['creator' => 'LyuDevs'];
set_time_limit(15);

$uid = $_GET['uid'] ?? '';

if (!$uid) {
    $data = array_merge($credit, ['status' => false, 'message' => 'Parameter uid diperlukan']);
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $data = removeKeysRecursive($data, $keysToRemove);
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

$ch = curl_init('https://www.00cc.eu.cc/freefire-stalk?uid=' . urlencode($uid));
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36', 'Accept: application/json']
]);
$raw = json_decode(curl_exec($ch), true); curl_close($ch);

if (empty($raw['success'])) {
    echo json_encode(array_merge($credit, ['status' => false, 'message' => 'UID tidak ditemukan']), JSON_PRETTY_PRINT);
    exit;
}

$r = $raw['result'];

$data = array_merge($credit, [
    'status' => true,
    'data' => [
        'basic' => [
            'uid' => $r['account_basic_info']['uid'],
            'name' => $r['account_basic_info']['name'],
            'level' => $r['account_basic_info']['level'],
            'exp' => $r['account_basic_info']['exp'],
            'region' => $r['account_basic_info']['region'],
            'likes' => $r['account_basic_info']['likes'],
            'honor_score' => $r['account_basic_info']['honor_score'],
            'title' => $r['account_basic_info']['title_name'],
            'bio' => $r['account_basic_info']['bio'],
            'has_elite_pass' => $r['account_basic_info']['has_elite_pass']
        ],
        'activity' => [
            'created_at' => $r['account_activity']['created_at'],
            'last_login' => $r['account_activity']['last_login'],
            'br_rank' => $r['account_activity']['br_rank'],
            'cs_rank' => $r['account_activity']['cs_rank']
        ],
        'social' => [
            'gender' => str_replace('Gender_', '', $r['social_info']['gender']),
            'language' => str_replace('Language_', '', $r['social_info']['language']),
            'signature' => $r['social_info']['signature']
        ],
        'overview' => [
            'avatar' => $r['account_overview']['avatar_name'],
            'banner' => $r['account_overview']['banner_name'],
            'title' => $r['account_overview']['title_name']
        ],
        'guild' => [
            'name' => $r['guild_info']['guild_name'],
            'id' => $r['guild_info']['guild_id'],
            'level' => $r['guild_info']['guild_level'],
            'members' => $r['guild_info']['live_members']
        ],
        'misc' => [
            'profile_image' => $r['profile_image']
        ]
    ]
]);

$keysToRemove = ['creator', 'Creator', 'author', 'Author'];
$data = removeKeysRecursive($data, $keysToRemove);

echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

function removeKeysRecursive($array, $keysToRemove) {
    if (!is_array($array)) return $array;
    foreach ($keysToRemove as $key) unset($array[$key]);
    foreach ($array as &$value) {
        if (is_array($value)) $value = removeKeysRecursive($value, $keysToRemove);
    }
    return $array;
}
?>