<?php
// Deskripsi: LyuDevs API - TikTok Profile & Videos Scraper via TikViewr (support URL/username/@)
// Contoh: {"action": "profile", "username": "xyyzn_505"}
// @param action (profile|videos) Pilih Mode
// @param username Username TikTok (bisa username, @username, atau URL TikTok)

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { 
    http_response_code(200); 
    exit; 
}

// ========== CREDIT ==========
$credit = [
    'creator' => 'LyuDevs'
];

// ========== KONFIGURASI ==========
define('BASE_URL', 'https://tools.xrespond.com/api/tiktok');
define('MAX_RETRIES', 3);

$USER_AGENTS = [
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/119.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1',
];

// ========== FUNCTIONS ==========
function generateFakeIP() {
    return rand(1, 255) . '.' . rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255);
}

function getRandomUserAgent() {
    global $USER_AGENTS;
    return $USER_AGENTS[array_rand($USER_AGENTS)];
}

function extractUsername($input) {
    $input = trim($input);
    
    // Case 1: https://vt.tiktok.com/ZSQ9uj3rW/ atau https://www.tiktok.com/@username/video/123
    if (preg_match('/^https?:\/\//', $input)) {
        // Follow redirect untuk shortlink
        if (preg_match('/vt\.tiktok\.com/', $input)) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $input,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_HEADER => true,
                CURLOPT_USERAGENT => getRandomUserAgent(),
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $redirectUrl = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
            curl_close($ch);
            
            // Cek header Location
            if (preg_match('/Location:\s*(.+)/i', $response, $locMatch)) {
                $redirectUrl = trim($locMatch[1]);
            }
            
            if ($redirectUrl && preg_match('/tiktok\.com\/@([^\/\?]+)/', $redirectUrl, $userMatch)) {
                return $userMatch[1];
            }
            
            // Fallback: coba fetch ulang dengan follow redirect
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $input,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HEADER => false,
                CURLOPT_USERAGENT => getRandomUserAgent(),
            ]);
            $finalHtml = curl_exec($ch);
            $finalUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            curl_close($ch);
            
            if ($finalUrl && preg_match('/tiktok\.com\/@([^\/\?]+)/', $finalUrl, $userMatch)) {
                return $userMatch[1];
            }
            
            // Coba scrape dari meta tag di HTML
            if (preg_match('/"@([^"]+)"/', $finalHtml, $metaMatch)) {
                return $metaMatch[1];
            }
            if (preg_match('/authorId.*?"([^"]+)"/', $finalHtml, $idMatch)) {
                return $idMatch[1];
            }
            
            return null; // Gagal extract
        }
        
        // Case 2: https://www.tiktok.com/@username
        if (preg_match('/tiktok\.com\/@([^\/\?]+)/', $input, $userMatch)) {
            return $userMatch[1];
        }
        
        return null;
    }
    
    // Case 3: @username
    if (preg_match('/^@(.+)$/', $input, $userMatch)) {
        return $userMatch[1];
    }
    
    // Case 4: username biasa
    return ltrim($input, '@');
}

function apiRequest($endpoint, $body, $maxRetries = 3) {
    $retries = 0;
    $lastError = null;
    
    while ($retries < $maxRetries) {
        $ch = curl_init();
        $payload = json_encode($body);
        
        curl_setopt_array($ch, [
            CURLOPT_URL => BASE_URL . $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Content-Type: application/json',
                'Origin: https://tikviewr.com',
                'Referer: https://tikviewr.com/',
                'User-Agent: ' . getRandomUserAgent(),
                'X-Requested-With: XMLHttpRequest',
                'Sec-Fetch-Site: same-site',
                'Sec-Fetch-Mode: cors',
                'Sec-Fetch-Dest: empty',
                'X-Forwarded-For: ' . generateFakeIP(),
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if (!$error && $httpCode >= 200 && $httpCode < 400) {
            return ['success' => true, 'data' => json_decode($response, true), 'http_code' => $httpCode];
        }
        
        $lastError = $error ?: "HTTP $httpCode";
        $retries++;
        if ($retries < $maxRetries) usleep(rand(500000, 1500000));
    }
    
    return ['success' => false, 'error' => $lastError];
}

function parseProfile($data) {
    $user = $data['data']['data']['user'] ?? [];
    $stats = $data['data']['data']['stats'] ?? [];
    
    return [
        'id' => $user['id'] ?? null,
        'username' => $user['uniqueId'] ?? null,
        'nickname' => $user['nickname'] ?? null,
        'bio' => $user['signature'] ?? null,
        'verified' => $user['verified'] ?? false,
        'private' => $user['privateAccount'] ?? false,
        'avatar' => [
            'thumb' => $user['avatarThumb'] ?? null,
            'medium' => $user['avatarMedium'] ?? null,
            'large' => $user['avatarLarger'] ?? null,
        ],
        'stats' => [
            'followers' => $stats['followerCount'] ?? 0,
            'following' => $stats['followingCount'] ?? 0,
            'likes' => $stats['heartCount'] ?? 0,
            'videos' => $stats['videoCount'] ?? 0,
        ],
        'create_time' => $user['createTime'] ?? null,
    ];
}

function parseVideos($data) {
    $videos = $data['data']['data']['videos'] ?? [];
    $result = [];
    
    foreach ($videos as $video) {
        $result[] = [
            'id' => $video['video_id'] ?? null,
            'aweme_id' => $video['aweme_id'] ?? null,
            'title' => $video['title'] ?? null,
            'duration' => $video['duration'] ?? null,
            'cover' => $video['cover'] ?? null,
            'dynamic_cover' => $video['ai_dynamic_cover'] ?? null,
            'origin_cover' => $video['origin_cover'] ?? null,
            'play_url' => $video['play'] ?? null,
            'wmplay_url' => $video['wmplay'] ?? null,
            'music' => [
                'title' => $video['music_info']['title'] ?? null,
                'author' => $video['music_info']['author'] ?? null,
                'duration' => $video['music_info']['duration'] ?? null,
                'cover' => $video['music_info']['cover'] ?? null,
                'url' => $video['music_info']['play'] ?? null,
            ],
            'stats' => [
                'views' => $video['play_count'] ?? 0,
                'likes' => $video['digg_count'] ?? 0,
                'comments' => $video['comment_count'] ?? 0,
                'shares' => $video['share_count'] ?? 0,
                'favorites' => $video['collect_count'] ?? 0,
                'downloads' => $video['download_count'] ?? 0,
            ],
            'author' => [
                'id' => $video['author']['id'] ?? null,
                'username' => $video['author']['unique_id'] ?? null,
                'nickname' => $video['author']['nickname'] ?? null,
                'avatar' => $video['author']['avatar'] ?? null,
            ],
            'created_at' => $video['create_time'] ?? null,
            'region' => $video['region'] ?? null,
        ];
    }
    
    return $result;
}

function removeKeysRecursive($array, $keysToRemove) {
    if (!is_array($array)) return $array;
    foreach ($keysToRemove as $key) unset($array[$key]);
    foreach ($array as &$value) {
        if (is_array($value)) $value = removeKeysRecursive($value, $keysToRemove);
    }
    return $array;
}

// ========== ANTI-CACHE ==========
opcache_reset();
clearstatcache();
usleep(rand(50000, 200000));

// ========== MAIN ==========
$action = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = file_get_contents('php://input');
    $json = json_decode($body, true) ?? [];
    $action = $json['action'] ?? '';
    $username = $json['username'] ?? '';
}

if (empty($action) && isset($_GET['action'])) $action = $_GET['action'];
if (empty($username) && isset($_GET['username'])) $username = $_GET['username'];

$input = [
    'action' => $action ?: null,
    'username' => $username ?: null,
];

// Validasi action
if (empty($action)) {
    $response = [
        'status' => false,
        'creator' => 'LyuDevs',
        'input' => $input,
        'result' => [
            'msg' => "Parameter 'action' diperlukan. Gunakan 'profile' atau 'videos'.",
            'available_actions' => ['profile', 'videos']
        ]
    ];
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $response = removeKeysRecursive($response, $keysToRemove);
    $response['creator'] = 'LyuDevs';
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Validasi username
if (empty($username)) {
    $response = [
        'status' => false,
        'creator' => 'LyuDevs',
        'input' => $input,
        'result' => ['msg' => "Parameter 'username' diperlukan."]
    ];
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $response = removeKeysRecursive($response, $keysToRemove);
    $response['creator'] = 'LyuDevs';
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Extract username dari URL / @ / teks
$extractedUsername = extractUsername($username);

if (!$extractedUsername) {
    $response = [
        'status' => false,
        'creator' => 'LyuDevs',
        'input' => $input,
        'result' => [
            'msg' => 'Gagal mengekstrak username dari input. Gunakan username TikTok yang valid (contoh: xyyzn_505, @xyyzn_505, atau URL TikTok).',
            'input_raw' => $username
        ]
    ];
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $response = removeKeysRecursive($response, $keysToRemove);
    $response['creator'] = 'LyuDevs';
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Update input dengan username yang sudah diekstrak
$input['username_extracted'] = $extractedUsername;

// Mode PROFILE
if ($action === 'profile') {
    $apiResult = apiRequest('/profile/details', ['profile' => $extractedUsername]);
    
    if (!$apiResult['success']) {
        $response = [
            'status' => false,
            'creator' => 'LyuDevs',
            'input' => $input,
            'result' => ['msg' => 'Gagal fetch profile: ' . $apiResult['error']]
        ];
        $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
        $response = removeKeysRecursive($response, $keysToRemove);
        $response['creator'] = 'LyuDevs';
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    $response = [
        'status' => true,
        'creator' => 'LyuDevs',
        'input' => $input,
        'result' => parseProfile($apiResult['data'])
    ];
    
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $response = removeKeysRecursive($response, $keysToRemove);
    $response['creator'] = 'LyuDevs';
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

// Mode VIDEOS
if ($action === 'videos') {
    $apiResult = apiRequest('/profile/videos', ['profile' => $extractedUsername]);
    
    if (!$apiResult['success']) {
        $response = [
            'status' => false,
            'creator' => 'LyuDevs',
            'input' => $input,
            'result' => ['msg' => 'Gagal fetch videos: ' . $apiResult['error']]
        ];
        $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
        $response = removeKeysRecursive($response, $keysToRemove);
        $response['creator'] = 'LyuDevs';
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
    
    $videosData = parseVideos($apiResult['data']);
    
    $response = [
        'status' => true,
        'creator' => 'LyuDevs',
        'input' => $input,
        'result' => [
            'total' => count($videosData),
            'videos' => $videosData
        ]
    ];
    
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $response = removeKeysRecursive($response, $keysToRemove);
    $response['creator'] = 'LyuDevs';
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

// Action tidak dikenal
$response = [
    'status' => false,
    'creator' => 'LyuDevs',
    'input' => $input,
    'result' => [
        'msg' => "Action '$action' tidak dikenal. Gunakan 'profile' atau 'videos'.",
        'available_actions' => ['profile', 'videos']
    ]
];
$keysToRemove = ['creator', 'Creator', 'author', 'Author'];
$response = removeKeysRecursive($response, $keysToRemove);
$response['creator'] = 'LyuDevs';
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>