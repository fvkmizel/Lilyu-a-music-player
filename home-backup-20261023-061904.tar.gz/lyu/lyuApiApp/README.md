# Lyu-Api Platform

Platform Web REST API generasi berikutnya yang menyediakan puluhan endpoint siap pakai untuk developer, bot automasi, AI, media downloader, tools utilitas, dan generator.

---

## 🌟 Fitur Utama

- **Dashboard Dokumentasi Interaktif**: Tampilan antarmuka modern di `/docs/` dengan live parameter testing, code snippet, dark/light theme, dan auto-discovery endpoint.
- **Suno AI Music Downloader**: Endpoint baru di `/docs/api/downloader/usesuno.php` dan `/docs/api/downloader/suno.php` untuk mengunduh lagu Suno AI (MP3, MP4 video, artwork, metadata lirik/prompt) secara instan.
- **Sistem Keamanan & API Key**:
  - Validasi API Key terpusat (`apikey=lyu` atau header `X-API-KEY`).
  - Rate Limiter per-IP untuk mencegah flooding dan scraping berlebihan.
  - Proteksi SSRF (Server-Side Request Forgery) untuk memblokir IP internal/private.
  - Security Headers lengkap (`X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `X-XSS-Protection`, dll.).
  - Pencegahan Directory Listing & proteksi file sensitif via `.htaccess`.
- **Ratusan Endpoint Aktif**:
  - AI (ChatGPT, DeepSeek, Claude, Gemini, Blackbox, Copilot, Starlabs, Voice TTS, dll.)
  - Downloader (Suno AI, YouTube MP3/MP4, Spotify, TikTok, Instagram, Twitter, SoundCloud, Pinterest, Terabox, dll.)
  - Search (Spotify, YouTube, TikTok, SoundCloud, Wikipedia, AZ-Lyrics, NPM, dll.)
  - Maker & Tools (Canvas maker, Fake chat, SSWeb, Image Enhancer, RemoveBG, HD Image, dll.)
  - Game & Informasi (Kuis, Cerdas cermat, Kisah Nabi, Jadwal TV, MLBB, dll.)

---

## 📁 Struktur Proyek

```
usesuno/
├── index.html                     # Landing page utama Lyu-Api
├── 404.html                       # Halaman kustom Error 404
├── .htaccess                      # Konfigurasi Apache & proteksi keamanan
├── README.md                      # Dokumentasi proyek
└── docs/
    ├── index.php                  # Web UI dokumentasi interaktif
    └── api/                       # Direktori endpoint API
        ├── .htaccess              # Header CORS & pembatasan akses
        ├── .user.ini              # Konfigurasi resource PHP
        ├── config/
        │   └── security.php       # Modul keamanan, API Key & Rate Limiting
        ├── downloader/
        │   ├── usesuno.php        # Endpoint Suno AI Downloader
        │   ├── suno.php           # Alias endpoint Suno AI
        │   ├── ytdl.php
        │   ├── spotify-dl.php
        │   └── ...
        ├── ai/
        ├── ai-image/
        ├── search/
        ├── maker/
        ├── informasi/
        ├── stalker/
        ├── uploader/
        └── tools/
```

---

## 🚀 Cara Menjalankan

Jalankan built-in web server PHP dari direktori `usesuno`:

```bash
cd /root/lyu/usesuno
php -S 0.0.0.0:8000
```

Akses di browser:
- **Landing Page**: `http://localhost:8000/`
- **Interactive API Docs**: `http://localhost:8000/docs/`
- **Usesuno Endpoint**: `http://localhost:8000/docs/api/downloader/usesuno.php?url=<SUNO_URL>&apikey=lyu`

---

## 🎵 Dokumentasi Endpoint Suno AI

### Request:
- **URL**: `/docs/api/downloader/usesuno.php` atau `/docs/api/downloader/suno.php`
- **Method**: `GET` atau `POST`
- **Parameter**:
  - `url` *(wajib)*: URL Suno (`https://suno.com/song/<id>`, short link `https://suno.com/s/<token>`, atau UUID lagu).
  - `apikey` *(wajib)*: API Key Lyu (default: `lyu`, `lyudevs`, `lyu-vip`).
  - `format` *(opsional)*: `both` (default), `mp3`, atau `mp4`.
  - `action` *(opsional)*: `info` (default, respon JSON) atau `download` (stream attachment biner).

### Contoh Response (JSON):
```json
{
  "creator": "LyuDevs",
  "status": true,
  "result": {
    "id": "c1a16429-f3fe-4d99-bdcf-61ee13ed6f00",
    "title": "Together in Respect",
    "artist": "evalena",
    "handle": "artevalena",
    "duration": 210,
    "duration_fmt": "03:30",
    "tags": "Accusatory mid-tempo soul-country blues...",
    "prompt": "$c8",
    "model": "chirp-hawk",
    "created_at": "2026-09-09T16:11:52.835Z",
    "stats": {
      "play_count": 148812,
      "upvote_count": 2076,
      "comments": 167
    },
    "thumbnail": "https://cdn2.suno.ai/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00_22535392.jpeg",
    "download_url": "https://cdn1.suno.ai/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00.mp3",
    "media": {
      "mp3": "https://cdn1.suno.ai/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00.mp3",
      "mp4": "https://cdn1.suno.ai/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00.mp4",
      "m4a": "https://d2lwuy8qc234o3.cloudfront.net/1/clip/c1a16429-f3fe-4d99-bdcf-61ee13ed6f00.m4a"
    }
  }
}
```
